import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  // --- Animation Controller ---
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  final ScrollController _scrollController = ScrollController();

  // --- Theme Colors (Red Predator Theme) ---
  final Color primaryRed = const Color(0xFFD50000);   // Merah Utama
  final Color darkRed = const Color(0xFF8B0000);      // Merah Gelap
  final Color glassBlack = const Color(0xFF050505).withOpacity(0.8); // Hitam Transparan
  final Color borderRed = const Color(0xFFD50000).withOpacity(0.3);

  // --- Data Team Revengers ---
  final List<Map<String, String>> teamMembers = [
    {
      'name': 'Lucient`Kaito',
      'role': 'Developer Base',
      'handle': '@kaitonotdev',
    },
    {
      'name': 'FanTzy',
      'role': 'CEO Revengers',
      'handle': '@fantzy_reals13',
    },
    {
      'name': 'bizz Store',
      'role': 'Petinggi',
      'handle': '@bizzstore225',
    },
    {
      'name': 'Xyroo',
      'role': 'Friends',
      'handle': '@XyrooSolo',
    },
    {
      'name': 'Lenox Official',
      'role': 'Owner',
      'handle': '@LenoxOfficial',
    },
    {
      'name': 'Pall',
      'role': 'Petinggi',
      'handle': '@P4ll_Reals001',
    },
  ];

  @override
  void initState() {
    super.initState();
    // Efek Fade In saat masuk halaman
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020202), // Hitam pekat
      body: Stack(
        children: [
          // 1. Background Grid Pattern (Red)
          Positioned.fill(
            child: CustomPaint(
              painter: GridPatternPainter(color: primaryRed.withOpacity(0.08)),
            ),
          ),

          // 2. Ambient Glow (Efek cahaya merah di pojok)
          Positioned(
            top: -150,
            left: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [primaryRed.withOpacity(0.15), Colors.transparent],
                  radius: 0.7,
                ),
              ),
            ),
          ),

          // 3. Main Content
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // --- HEADER SECTION ---
                    _buildHeaderTitle(),
                    
                    const SizedBox(height: 30),

                    // --- TEAMS GRID SECTION ---
                    Row(
                      children: [
                        Icon(FontAwesomeIcons.users, color: primaryRed, size: 14),
                        const SizedBox(width: 10),
                        const Text(
                          "CORE MEMBERS",
                          style: TextStyle(
                            color: Colors.white54,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2.0,
                            fontSize: 12,
                          ),
                        ),
                        const Expanded(child: Divider(color: Colors.white10, indent: 10)),
                      ],
                    ),
                    
                    const SizedBox(height: 15),
                    
                    _buildTeamsGrid(),
                    
                    const SizedBox(height: 40),
                    
                    // Footer Copyright
                    Text(
                      "© 2024 REVENGERS TEAM. All Rights Reserved.",
                      style: TextStyle(
                        color: Colors.white24,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET BUILDERS ---

  Widget _buildHeaderTitle() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
          decoration: BoxDecoration(
            color: glassBlack,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderRed, width: 1),
            boxShadow: [
              BoxShadow(
                color: primaryRed.withOpacity(0.15),
                blurRadius: 25,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            children: [
              // Icon Mahkota Kecil diatas Judul
              Icon(FontAwesomeIcons.crown, color: primaryRed, size: 24),
              const SizedBox(height: 15),
              
              Text(
                "TEAMS REVENGERS",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani', // Font Keren
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  shadows: [
                    Shadow(color: primaryRed, blurRadius: 20),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: primaryRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: primaryRed.withOpacity(0.3)),
                ),
                child: const Text(
                  "Full Support System By Revengers",
                  style: TextStyle(
                    color: Colors.white70,
                    fontFamily: 'ShareTechMono', // Font Tech
                    fontSize: 11,
                    letterSpacing: 1,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTeamsGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // 2 Kolom
        childAspectRatio: 0.75, // Membuat kotak memanjang ke bawah (Portrait)
        crossAxisSpacing: 15,
        mainAxisSpacing: 15,
      ),
      itemCount: teamMembers.length,
      itemBuilder: (context, index) {
        final member = teamMembers[index];
        return _buildTeamCard(
          name: member['name']!,
          role: member['role']!,
          handle: member['handle']!,
        );
      },
    );
  }

  Widget _buildTeamCard({
    required String name,
    required String role,
    required String handle,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        // Gradient Glass Effect
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.08),
            Colors.black.withOpacity(0.6),
          ],
        ),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Stack(
        children: [
          // Dekorasi Garis Merah Tipis di atas
          Positioned(
            top: 0,
            left: 20,
            right: 20,
            child: Container(
              height: 2,
              decoration: BoxDecoration(
                color: primaryRed.withOpacity(0.5),
                borderRadius: BorderRadius.circular(2),
                boxShadow: [BoxShadow(color: primaryRed, blurRadius: 5)],
              ),
            ),
          ),
          
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // 1. Profile Icon (Bulat & Glowing)
                Container(
                  width: 65,
                  height: 65,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black,
                    border: Border.all(color: primaryRed, width: 2),
                    boxShadow: [
                      BoxShadow(color: primaryRed.withOpacity(0.3), blurRadius: 20),
                    ],
                  ),
                  child: Center(
                    child: Icon(FontAwesomeIcons.userSecret, color: Colors.white, size: 28),
                  ),
                ),
                
                const SizedBox(height: 16),

                // 2. Name
                Text(
                  name,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    letterSpacing: 1,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                
                const SizedBox(height: 8),

                // 3. Role Label (Badge)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: primaryRed.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: primaryRed.withOpacity(0.4)),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white, // Warna Putih agar kontras
                      fontSize: 9,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                
                const SizedBox(height: 10),

                // 4. Handle Text (@...)
                Text(
                  handle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// --- BACKGROUND PAINTER (Grid Tech Pattern) ---
class GridPatternPainter extends CustomPainter {
  final Color color;
  GridPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;
    
    const gridSize = 40.0;
    
    // Garis Vertikal
    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    // Garis Horizontal
    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
