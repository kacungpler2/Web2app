import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  static const String baseUrl = "http://rixzz-privat-panel.sano.biz.id:11490";

  // --- Controllers ---
  late AnimationController _buttonController;
  late VideoPlayerController _bannerVideoController;

  // States
  bool _bannerVideoInitialized = false;
  String selectedBugId = "";
  bool _isSending = false;

  // --- Theme Colors ---
  final Color primaryRed = const Color(0xFFD50000); // Aksen Merah
  final Color darkRed = const Color(0xFF8B0000);
  final Color cleanGlass = const Color(0xFFFFFFFF).withOpacity(0.08); // Blur Putih Halus
  final Color textWhite = const Color(0xFFEEEEEE);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeBannerVideo();
    _setDefaultBug();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
  }

  void _initializeBannerVideo() {
    _bannerVideoController = VideoPlayerController.asset('assets/videos/semuadiamm.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bannerVideoInitialized = true);
          _bannerVideoController.setLooping(true);
          _bannerVideoController.play();
          _bannerVideoController.setVolume(1.0);
        }
      }).catchError((e) => debugPrint("Banner Video Error: $e"));
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _bannerVideoController.dispose();
    targetController.dispose();
    super.dispose();
  }

  // --- LOGIC SENDING ---
  Future<void> _handleSendButton() async {
    if (_isSending) return;

    await _buttonController.forward();
    await _buttonController.reverse();

    final rawInput = targetController.text.trim();
    final target = rawInput.replaceAll(RegExp(r'\s+'), '');
    final key = widget.sessionKey;

    if (target.isEmpty || key.isEmpty) {
      _showPopup("Invalid", "Target Number cannot be empty.", isError: true);
      return;
    }

    setState(() => _isSending = true);

    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showPopup("Cooldown", "Please wait before sending again.", isError: true);
      } else if (data["senderOn"] == false) {
        _showPopup("Failed", "Sender is empty/offline.", isError: true);
      } else if (data["valid"] == false) {
        _showPopup("Invalid Key", "Session key expired.", isError: true);
      } else if (data["sended"] == false) {
        _showPopup("Failed", "Server maintenance or invalid target.", isError: true);
      } else {
        _showPopup("Success", "Bug successfully sent to $target", isError: false);
      }
    } catch (_) {
      _showPopup("Error", "Connection failed.", isError: true);
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
      }
    }
  }

  void _showPopup(String title, String message, {bool isError = false}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF151515),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: isError ? primaryRed : Colors.greenAccent, width: 1)),
          title: Row(
            children: [
              Icon(
                isError ? FontAwesomeIcons.circleExclamation : FontAwesomeIcons.circleCheck,
                color: isError ? primaryRed : Colors.greenAccent,
                size: 20,
              ),
              const SizedBox(width: 10),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      fontFamily: 'Orbitron')),
            ],
          ),
          content: Text(message,
              style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 13)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  // --- UI BUILDER ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          // 1. Background Ambient Glow
          Positioned(
            top: -150,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [primaryRed.withOpacity(0.15), Colors.transparent],
                  radius: 0.6,
                ),
              ),
            ),
          ),

          // 2. Main Content
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildHeaderProfile(),
                    
                    // PERUBAHAN DI SINI: Jarak dirapatkan dari 20 menjadi 8
                    const SizedBox(height: 8),
                    
                    _buildCleanBanner(),
                    const SizedBox(height: 25),
                    _buildInputTarget(),
                    const SizedBox(height: 15),
                    _buildDropdownPayload(),
                    const SizedBox(height: 30),
                    _buildSendButton(),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET COMPONENTS ---

  Widget _buildHeaderProfile() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cleanGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Container(
            width: 55,
            height: 55,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: primaryRed, width: 2),
              image: const DecorationImage(
                image: AssetImage('assets/images/pp.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(FontAwesomeIcons.clock, color: Colors.white54, size: 10),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        "Exp: ${widget.expiredDate}  |  Role: ${widget.role.toUpperCase()}",
                        style: const TextStyle(
                          color: Colors.white70,
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCleanBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 160,
        width: double.infinity,
        color: Colors.black,
        child: Stack(
          children: [
            if (_bannerVideoInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bannerVideoController.value.size.width,
                    height: _bannerVideoController.value.size.height,
                    child: VideoPlayer(_bannerVideoController),
                  ),
                ),
              )
            else
              const Center(child: CircularProgressIndicator(color: Colors.white)),

            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              height: 60,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                  ),
                ),
              ),
            ),

            Positioned(
              bottom: 12,
              left: 15,
              child: Text(
                "REVENGERS",
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                  letterSpacing: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputTarget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 5, bottom: 6),
          child: Text(
            "TARGET NUMBER",
            style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: cleanGlass,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white10),
          ),
          child: TextField(
            controller: targetController,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
            keyboardType: TextInputType.phone,
            cursorColor: primaryRed,
            decoration: InputDecoration(
              hintText: "628xxxxxxxx",
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
              prefixIcon: Icon(FontAwesomeIcons.penToSquare, color: Colors.white70, size: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdownPayload() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 5, bottom: 6),
          child: Text(
            "SELECT PAYLOAD",
            style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
          decoration: BoxDecoration(
            color: cleanGlass,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white10),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: const Color(0xFF1E1E1E),
              value: selectedBugId,
              isExpanded: true,
              icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white70),
              style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
              items: widget.listBug.map((bug) {
                return DropdownMenuItem<String>(
                  value: bug['bug_id'],
                  child: Row(
                    children: [
                      Icon(FontAwesomeIcons.bug, size: 12, color: primaryRed),
                      const SizedBox(width: 10),
                      Text(bug['bug_name']),
                    ],
                  ),
                );
              }).toList(),
              onChanged: (value) {
                if (value != null) setState(() => selectedBugId = value);
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSendButton() {
    return GestureDetector(
      onTap: _isSending ? null : _handleSendButton,
      child: AnimatedBuilder(
        animation: _buttonController,
        builder: (context, child) {
          return Transform.scale(
            scale: 1.0 - (_buttonController.value * 0.05),
            child: Container(
              height: 50,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryRed, darkRed],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: primaryRed.withOpacity(0.4),
                    blurRadius: 15,
                    offset: const Offset(0, 4),
                  )
                ],
              ),
              child: Center(
                child: _isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // PERUBAHAN DI SINI: Icon dipindah ke KIRI
                        const Icon(FontAwesomeIcons.paperPlane, color: Colors.white, size: 16),
                        const SizedBox(width: 10),
                        const Text(
                          "SEND BUG",
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
              ),
            ),
          );
        },
      ),
    );
  }
}
