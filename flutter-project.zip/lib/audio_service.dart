import 'package:audioplayers/audioplayers.dart';

class AudioService {
  static final AudioService _instance = AudioService._internal();
  late AudioPlayer _audioPlayer;

  factory AudioService() {
    return _instance;
  }

  AudioService._internal() {
    _audioPlayer = AudioPlayer();
  }

  Future<void> playBackgroundMusic() async {
    try {
      // Set agar musik mengulang (loop) otomatis
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      
      // Play musik dari assets
      await _audioPlayer.play(AssetSource('bg_music.mp3'));
      print('Background music dimulai...');
    } catch (e) {
      print('Error playing music: $e');
    }
  }

  Future<void> stopMusic() async {
    try {
      await _audioPlayer.stop();
      print('Background music dihentikan.');
    } catch (e) {
      print('Error stopping music: $e');
    }
  }

  Future<void> resumeMusic() async {
    try {
      await _audioPlayer.resume();
      print('Background music dilanjutkan.');
    } catch (e) {
      print('Error resuming music: $e');
    }
  }

  Future<void> pauseMusic() async {
    try {
      await _audioPlayer.pause();
      print('Background music di-pause.');
    } catch (e) {
      print('Error pausing music: $e');
    }
  }

  PlayerState? getPlayerState() {
    return _audioPlayer.state;
  }

  void dispose() {
    _audioPlayer.dispose();
  }
}
