// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;

class ReportBansPage extends StatefulWidget {
  final String sessionKey;
  const ReportBansPage({super.key, required this.sessionKey});

  @override
  State<ReportBansPage> createState() => _ReportBansPageState();
}

class _ReportBansPageState extends State<ReportBansPage> {
  final PageController _pageController = PageController();
  int _currentTab = 0;
  List<dynamic> _sessions = []; 
  final String baseUrl = "http://rixzz-privat-panel.sano.biz.id:11490";

  // Controllers for Report
  final TextEditingController _targetUser = TextEditingController();
  final TextEditingController _targetId = TextEditingController();
  final TextEditingController _reportMsg = TextEditingController();
  String _selectedMethod = "Spam";

  @override
  void initState() {
    super.initState();
    _fetchSessions(); // Ambil list session saat buka halaman
  }

  // --- LOGIC FUNCTIONS (CONNECTED TO BACKEND) ---

  // 1. Ambil List Session dari Server
  Future<void> _fetchSessions() async {
    try {
      final res = await http.get(Uri.parse("$baseUrl/api/telegram/listSessions?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _sessions = data['sessions'] ?? [];
        });
      }
    } catch (e) {
      debugPrint("Error Fetch: $e");
    }
  }

  // 2. Kirim Request Pairing (Minta OTP)
  Future<void> _handlePairing(String phone, String id, String hash, BuildContext dialogCtx) async {
    Navigator.pop(dialogCtx); // Tutup dialog input
    _showLoading();
    
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/api/telegram/getPairing?key=${widget.sessionKey}&number=$phone&apiId=$id&apiHash=$hash"
      ));
      
      Navigator.pop(context); // Tutup loading

      final data = jsonDecode(res.body);
      if (data['valid']) {
        _showOtpDialog(phone, id, hash);
      } else {
        _showError(data['message'] ?? "Gagal mendapatkan kode OTP");
      }
    } catch (e) {
      Navigator.pop(context);
      _showError("Terjadi kesalahan koneksi server.");
    }
  }

  // 3. Verifikasi OTP (Selesaikan Login)
  Future<void> _verifyOtp(String phone, String otp, String id, String hash, BuildContext otpCtx) async {
    Navigator.pop(otpCtx);
    _showLoading();

    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/api/telegram/verifyOtp?key=${widget.sessionKey}&number=$phone&otp=$otp&apiId=$id&apiHash=$hash"
      ));
      
      Navigator.pop(context); // Tutup loading

      final data = jsonDecode(res.body);
      if (data['valid']) {
        _fetchSessions(); // Refresh list
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Session Berhasil Ditambahkan!", style: TextStyle(fontFamily: "Orbitron")), backgroundColor: Colors.green)
        );
      } else {
        _showError(data['error'] ?? "OTP Salah atau Kadaluarsa");
      }
    } catch (e) {
      Navigator.pop(context);
      _showError("Gagal verifikasi OTP.");
    }
  }

  // 4. Kirim Report (Email & Session MTProto)
  void _sendReport() async {
    if (_sessions.isEmpty) {
      _showError("Hubungkan minimal 1 session untuk melakukan report!");
      return;
    }

    _showLoading();

    try {
      // Kita panggil route report ke server
      // Server akan otomatis mengirim ke Gmail Telegram & melakukan report via session
      final res = await http.get(Uri.parse(
        "$baseUrl/api/telegram/sendReport?"
        "key=${widget.sessionKey}&"
        "targetUsername=${_targetUser.text}&"
        "targetId=${_targetId.text}&"
        "method=$_selectedMethod&"
        "message=${_reportMsg.text}"
      ));

      Navigator.pop(context);

      final data = jsonDecode(res.body);
      if (data['valid']) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("REPORT BERHASIL DIKIRIM KE DUROV & GMAIL!", style: TextStyle(fontFamily: "Orbitron")),
            backgroundColor: Colors.redAccent,
            duration: Duration(seconds: 4),
          )
        );
      }
    } catch (e) {
      Navigator.pop(context);
      _showError("Gagal mengirim report ke server.");
    }
  }

  // --- UI HELPERS ---

  void _showLoading() {
    showDialog(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator(color: Colors.red)));
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: Colors.red));
  }

  // --- WIDGETS (SAMA SEPERTI SEBELUMNYA DENGAN PENYESUAIAN) ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("REPORT BANS TELE", style: TextStyle(fontFamily: "Orbitron", fontSize: 16, color: Colors.red)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              children: [
                _buildTabBtn(0, _sessions.isEmpty ? Icons.phonelink_erase : Icons.phonelink_setup, "Sessions"),
                const SizedBox(width: 15),
                _buildTabBtn(1, Icons.report_problem, "Report"),
              ],
            ),
          ),
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (i) => setState(() => _currentTab = i),
              children: [
                _buildSessionsTab(),
                _buildReportTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _currentTab == 0 ? FloatingActionButton(
        backgroundColor: Colors.red,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => _showAddSessionDialog(),
      ) : null,
    );
  }

  Widget _buildTabBtn(int index, IconData icon, String label) {
    bool active = _currentTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => _pageController.animateToPage(index, duration: const Duration(milliseconds: 300), curve: Curves.easeInOut),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: active ? Colors.red.withOpacity(0.2) : const Color(0xFF0F0000),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: active ? Colors.red : Colors.white10),
          ),
          child: Column(
            children: [
              Icon(icon, color: active ? Colors.red : Colors.grey, size: 20),
              const SizedBox(height: 5),
              Text(label, style: TextStyle(color: active ? Colors.white : Colors.grey, fontSize: 10, fontFamily: "Orbitron")),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSessionsTab() {
    if (_sessions.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.mobile_off, color: Colors.red.withOpacity(0.3), size: 80),
            const SizedBox(height: 20),
            const Text("NO SESSIONS CONNECTED", style: TextStyle(color: Colors.white24, fontFamily: "Orbitron")),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: _sessions.length,
      itemBuilder: (context, i) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: const Color(0xFF0F0000), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.red.withOpacity(0.3))),
        child: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 20), // Icon berubah jadi check jika konek
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Session: ${_sessions[i]['phone']}", style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono")),
                  Text("API ID: ${_sessions[i]['apiId']}", style: const TextStyle(color: Colors.white38, fontSize: 10)),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 20),
              onPressed: () { /* Logic Delete Session */ },
            )
          ],
        ),
      ),
    );
  }

  Widget _buildReportTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _buildField("Target Username", _targetUser, "@username"),
          _buildField("Target ID", _targetId, "12345678"),
          _buildMethodSelector(),
          _buildField("Report Message", _reportMsg, "Reason for report...", maxLines: 3),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 10,
                shadowColor: Colors.red.withOpacity(0.5)
              ),
              onPressed: () => _sendReport(),
              child: const Text("SEND REPORT", style: TextStyle(fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
            ),
          )
        ],
      ),
    );
  }

    void _showAddSessionDialog() {
    final TextEditingController phoneC = TextEditingController();
    final TextEditingController apiIdC = TextEditingController();
    final TextEditingController apiHashC = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A0505),
        // PERBAIKAN: Gunakan 'side' bukan 'border'
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: Colors.red.withOpacity(0.5)),
        ),
        title: const Text("Add Session", style: TextStyle(color: Colors.red, fontFamily: "Orbitron")),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDialogField("Phone Number (Intl)", phoneC),
              _buildDialogField("API ID", apiIdC),
              _buildDialogField("API Hash", apiHashC),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel", style: TextStyle(color: Colors.grey))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => _handlePairing(phoneC.text, apiIdC.text, apiHashC.text, ctx),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

    void _showOtpDialog(String phone, String id, String hash) {
    final TextEditingController otpC = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A0505),
        // PERBAIKAN: Gunakan 'side' bukan 'border'
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: const BorderSide(color: Colors.red),
        ),
        title: const Text("Enter OTP", style: TextStyle(color: Colors.red, fontFamily: "Orbitron")),
        content: TextField(
          controller: otpC, 
          keyboardType: TextInputType.number,
          style: const TextStyle(color: Colors.white), 
          decoration: const InputDecoration(
            hintText: "Check Telegram Code", 
            hintStyle: TextStyle(color: Colors.white24),
            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.red)),
          )
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => _verifyOtp(phone, otpC.text, id, hash, ctx), 
            child: const Text("Connect")
          ),
        ],
      ),
    );
  }
  

  // --- REUSABLE UI ---
  Widget _buildField(String label, TextEditingController c, String hint, {int maxLines = 1}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: c,
        maxLines: maxLines,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label, labelStyle: const TextStyle(color: Colors.red, fontSize: 12, fontFamily: "Orbitron"),
          hintText: hint, hintStyle: const TextStyle(color: Colors.white10),
          enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Colors.white10)),
          focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Colors.red)),
        ),
      ),
    );
  }

  Widget _buildMethodSelector() {
    List<String> methods = ["Spam", "Violence", "Child Abuse", "Porn", "Other"];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Select Method", style: TextStyle(color: Colors.red, fontSize: 11, fontFamily: "Orbitron")),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: methods.map((m) => ChoiceChip(
            label: Text(m, style: const TextStyle(fontSize: 10, fontFamily: "ShareTechMono")),
            selected: _selectedMethod == m,
            onSelected: (s) => setState(() => _selectedMethod = m),
            selectedColor: Colors.red,
            backgroundColor: const Color(0xFF1A0505),
            labelStyle: TextStyle(color: _selectedMethod == m ? Colors.white : Colors.grey),
          )).toList(),
        ),
      ],
    );
  }

  Widget _buildDialogField(String label, TextEditingController c) {
    return TextField(
      controller: c, 
      style: const TextStyle(color: Colors.white, fontSize: 13), 
      decoration: InputDecoration(
        labelText: label, 
        labelStyle: const TextStyle(color: Colors.grey, fontSize: 12),
        focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Colors.red)),
      )
    );
  }
}

