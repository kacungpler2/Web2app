// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:async'; // Added for Clock Timer
import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;

// --- IMPORTS HALAMAN ---
// Pastikan path import ini sesuai dengan project Anda
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'chat_ai_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart';
import 'subdomain_finder_page.dart';
import 'anime.dart';
import 'wifi_internal.dart';
import 'instagram.dart';
import 'tiktok.dart';
import 'comic_page.dart';
import 'report_bans_page.dart';
import 'spam_bot_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // Controller Animasi Tools (Init jika perlu di masa depan)
  late AnimationController _toolsAnimController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  // State untuk Sidebar Tools Expandable
  bool _isSidebarToolsExpanded = false;

  // Global key untuk posisi tombol Bug
  final GlobalKey _bugButtonKey = GlobalKey();

  // Controller for news page view
  final PageController _pageController = PageController(viewportFraction: 0.95);
  int _currentNewsIndex = 0;

  // --- CLOCK VARIABLE ---
  String _timeString = "00:00";
  Timer? _timer;

  // --- STYLE CONSTANTS (RED & PURE BLACK THEME) ---
  final Color _primaryBackground = const Color(0xFF000000); // Pure Black
  final Color _accentRed = const Color(0xFFB00000); // Strong Red
  final Color _glowColor = const Color(0xFFFF0000); // Bright Red for Glows

  final TextStyle _glowTextSmall = TextStyle(
    fontFamily: "Orbitron",
    fontWeight: FontWeight.bold,
    fontSize: 16,
    color: Colors.white,
    shadows: [
      BoxShadow(
        color: Colors.red.withOpacity(0.8),
        blurRadius: 10,
        offset: const Offset(0, 0),
      ),
    ],
  );

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
    _controller.forward();

    _toolsAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    ); 

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _startClock(); // Start Jam
  }

  void _startClock() {
    _updateTime();
    _timer = Timer.periodic(const Duration(seconds: 1), (Timer t) => _updateTime());
  }

  void _updateTime() {
    final DateTime now = DateTime.now();
    final String formattedDateTime = _formatTime(now);
    if (mounted) {
      setState(() {
        _timeString = formattedDateTime;
      });
    }
  }

  String _formatTime(DateTime time) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    return "${twoDigits(time.hour)}:${twoDigits(time.minute)}";
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('http://rixzz-privat-panel.sano.biz.id:11490'));
      channel.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo') {
          if (data['valid'] == false) {
             // Handle Logout logic here if needed
          }
        }
      }, onError: (e) {});
    } catch (e) {
      // Handle Error
    }
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();

      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        if (!["vip", "owner"].contains(role.toLowerCase())) {
          _selectedPage = AttackPage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
        } else {
          _showBugMenu();
        }
      } else if (index == 2) {
        _selectedPage = AttackPanel(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          listDDoS: listDDoS,
        );
      } else if (index == 3) {
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role);
      }
    });
  }

  void _showBugMenu() {
    final RenderBox renderBox = _bugButtonKey.currentContext?.findRenderObject() as RenderBox;
    final Offset offset = renderBox.localToGlobal(Offset.zero);
    final Size size = renderBox.size;

    List<Map<String, dynamic>> options = [];
    if (["vip", "owner"].contains(role.toLowerCase())) {
      options = [
        {'title': 'Custom Bug', 'icon': FontAwesomeIcons.squareWhatsapp},
        {'title': 'Group Bug', 'icon': FontAwesomeIcons.users},
        {'title': 'Bug', 'icon': FontAwesomeIcons.whatsapp},
      ];
    }

    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(
        offset.dx,
        offset.dy - size.height * 2.5,
        offset.dx + size.width,
        offset.dy,
      ),
      items: options.map((option) {
        return PopupMenuItem(
          value: option['title'],
          child: Row(
            children: [
              Icon(option['icon'], color: _glowColor, size: 20),
              const SizedBox(width: 10),
              Text(option['title'], style: const TextStyle(color: Colors.white, fontFamily: "Orbitron")),
            ],
          ),
        );
      }).toList(),
      color: const Color(0xFF1A0505).withOpacity(0.95),
      elevation: 10,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: _glowColor.withOpacity(0.4), width: 1),
      ),
    ).then((value) {
      if (value != null) {
        setState(() {
          if (value == 'Custom Bug') {
            _selectedPage = CustomAttackPage(
              username: username, password: password, listPayload: listPayload, role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            );
          } else if (value == 'Group Bug') {
            _selectedPage = GroupBugPage(
              username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            );
          } else if (value == 'Bug') {
            _selectedPage = AttackPage(
              username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            );
          }
        });
      }
    });
  }

  void _navigateToPage(Widget page) {
    Navigator.pop(context); // Close Drawer
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  // --- WIDGET BUILDERS ---

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Text(
        title,
        style: _glowTextSmall.copyWith(fontSize: 18, color: Colors.white),
      ),
    );
  }

  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: _glowColor,
      backgroundColor: Colors.black,
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 100),

            // --- HEADER BOX ---
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              padding: const EdgeInsets.fromLTRB(10, 15, 10, 20),
              decoration: BoxDecoration(
                color: const Color(0xFF0F0000),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accentRed.withOpacity(0.4), width: 1),
                boxShadow: [
                  BoxShadow(color: _accentRed.withOpacity(0.1), blurRadius: 15, offset: const Offset(0, 0))
                ]
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, bottom: 10),
                    child: Text(
                      "Revengers Dashboard",
                      style: TextStyle(
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: _accentRed,
                        shadows: [BoxShadow(color: Colors.black.withOpacity(0.8), blurRadius: 2)]
                      ),
                    ),
                  ),
                  _buildNewsCarousel(),
                ],
              ),
            ),
            
            const SizedBox(height: 30),

            // --- LATEST NEWS ---
            _buildSectionTitle("Latest News"),
            const SizedBox(height: 5),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                   _buildHorizontalCard(
                    icon: FontAwesomeIcons.userShield,
                    title: "Update Security",
                    subtitle: "Security Update, Death to the intruders.",
                    color: Colors.redAccent,
                  ),
                  _buildHorizontalCard(
                    icon: FontAwesomeIcons.eye,
                    title: "New Engine",
                    subtitle: "New Engine System, Bug Optimal, Function Fix.",
                    color: Colors.amberAccent,
                  ),
                  _buildHorizontalCard(
                    icon: FontAwesomeIcons.bug,
                    title: "New Metode Bug",
                    subtitle: "New Metode Bug, Select Bug, Group Bug, Bug Global.",
                    color: Colors.greenAccent,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // --- WORDS FROM HUTAO ---
            _buildSectionTitle("Words From Hutao"),
            const SizedBox(height: 5),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                   _buildHutaoCard(
                    imagePath: 'assets/images/foto1.png',
                    mainText: "Revengers wa mou V6 dake da yoッ",
                    subText: "Revengers Udah V6 Aja Nihッ",
                  ),
                  _buildHutaoCard(
                    imagePath: 'assets/images/foto2.png',
                    mainText: "Modotta ga, mou onaji ja nai",
                    subText: "Saya Kembali Tapi Berbeda",
                  ),
                   _buildHutaoCard(
                    imagePath: 'assets/images/foto3.png',
                    mainText: "Tsukatte ne, sayang",
                    subText: "Selamat Menggunakan Sayang",
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // --- ACCOUNT STATISTICS (FIXED LAYOUT) ---
            _buildSectionTitle("Account Stastik"),
            const SizedBox(height: 5),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  // Box 1: Expired (Full Width)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F0000),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: _accentRed.withOpacity(0.5)),
                      boxShadow: [
                        BoxShadow(color: Colors.red.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _accentRed.withOpacity(0.1),
                          ),
                          child: Icon(FontAwesomeIcons.calendarCheck, color: _glowColor, size: 22),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Account Expired", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: "Orbitron")),
                              const SizedBox(height: 4),
                              Text(expiredDate, style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: "ShareTechMono")),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Row: Role & Runtime
                  Row(
                    children: [
                      // Box 2: Role
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0F0000),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: _accentRed.withOpacity(0.5)),
                             boxShadow: [
                              BoxShadow(color: Colors.red.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                            ],
                          ),
                          child: Row(
                            children: [
                               Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.blueAccent.withOpacity(0.1),
                                ),
                                child: const Icon(FontAwesomeIcons.userShield, color: Colors.blueAccent, size: 18),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text("Role", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: "Orbitron")),
                                    const SizedBox(height: 4),
                                    Text(role.toUpperCase(), style: const TextStyle(color: Colors.blueAccent, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Box 3: Runtime Clock
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0F0000),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: _accentRed.withOpacity(0.5)),
                             boxShadow: [
                              BoxShadow(color: Colors.red.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                            ],
                          ),
                          child: Row(
                            children: [
                               Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.greenAccent.withOpacity(0.1),
                                ),
                                child: const Icon(FontAwesomeIcons.clock, color: Colors.greenAccent, size: 18),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text("Runtime", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: "Orbitron")),
                                    const SizedBox(height: 4),
                                    Text(_timeString, style: const TextStyle(color: Colors.greenAccent, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: "ShareTechMono")),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),

            const SizedBox(height: 25),

            // --- FEATURES ALLOWED ---
            _buildSectionTitle("Features Allowed"),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: _buildActionWideButton(
                      icon: FontAwesomeIcons.bookOpen, 
                      title: "Comic Zone",
                      subtitle: "Read Manga",
                      color: Colors.purpleAccent,
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ComicPage()));
                      },
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: _buildActionWideButton(
                      icon: FontAwesomeIcons.robot,
                      title: "Spam Bot",
                      subtitle: "Tele Automations",
                      color: Colors.blueAccent,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SpamBotPage(sessionKey: sessionKey)),
                        );
                      },
                    ),
                  ),
                ], // Penutup children Row
              ), // Penutup Row
            ), // Penutup Padding

            const SizedBox(height: 25),

            // --- QUICK ACTIONS ---
            _buildSectionTitle("Quick Actions"), // Tambahkan judul section jika perlu
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  _buildActionWideButton(
                    icon: FontAwesomeIcons.telegram,
                    title: "Join Comunity To Next Update !!",
                    subtitle: "Comunity Revengers, All Teams.",
                    color: Colors.blue,
                    onTap: () async {
                      final uri = Uri.parse("https://t.me/revengersinfo1");
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri, mode: LaunchMode.externalApplication);
                      }
                    },
                  ),
                  const SizedBox(height: 10),
                  _buildActionWideButton(
                    icon: FontAwesomeIcons.mobileScreen,
                    title: "Manage Bug Sender",
                    subtitle: "Configure & Manage your sender devices",
                    color: Colors.green,
                    onTap: () {
                      setState(() {
                        _selectedPage = SenderPage(sessionKey: sessionKey);
                      });
                    },
                  ),
                ], // Penutup children Column
              ), // Penutup Column
            ), // Penutup Padding

            const SizedBox(height: 120),
          ], // Penutup children utama (Column di SingleChildScrollView)
        ), // Penutup Column utama
      ), // Penutup RefreshIndicator
    ); // Penutup _buildNewsPage
  }


  // --- WIDGET HELPER KHUSUS ---

  Widget _buildHutaoCard({
    required String imagePath,
    required String mainText,
    required String subText,
  }) {
    return Container(
      width: 240,
      height: 90,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0000),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _glowColor.withOpacity(0.3), width: 1),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Opacity(
                opacity: 0.2,
                child: Image.asset(
                  imagePath,
                  fit: BoxFit.cover,
                  errorBuilder: (ctx, err, stack) => const Icon(Icons.image_not_supported, color: Colors.white10),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                 Container(width: 3, height: 50, color: _glowColor, margin: const EdgeInsets.only(right: 10)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(mainText, style: _glowTextSmall.copyWith(fontSize: 12, color: Colors.white), maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 4),
                      Text(subText, style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10, fontStyle: FontStyle.italic, fontFamily: "ShareTechMono"), maxLines: 1, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHorizontalCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      width: 200,
      height: 110,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0000),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 24),
                const SizedBox(width: 8),
                Expanded(child: Text(title, style: _glowTextSmall.copyWith(fontSize: 14, color: Colors.white), overflow: TextOverflow.ellipsis)),
              ],
            ),
            const SizedBox(height: 8),
            Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10, fontFamily: "ShareTechMono"), maxLines: 3, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  Widget _buildActionWideButton({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: color.withOpacity(0.2),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.4), width: 1),
            color: color.withOpacity(0.05),
          ),
          child: Row(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: "Orbitron")),
                    if(subtitle.isNotEmpty)
                      Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10, fontFamily: "ShareTechMono")),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        height: 150,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.black.withOpacity(0.3)),
        child: const Center(child: Text("No news available", style: TextStyle(color: Colors.white54))),
      );
    }
    return SizedBox(
      height: 200,
      child: PageView.builder(
        controller: _pageController,
        itemCount: newsList.length,
        onPageChanged: (index) => setState(() => _currentNewsIndex = index),
        itemBuilder: (context, index) {
          final item = newsList[index];
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 5)],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (item['image'] != null && item['image'].toString().isNotEmpty) NewsMedia(url: item['image']) else Container(color: const Color(0xFF1D1E33)),
                  Positioned(
                    bottom: 0, left: 0, right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      color: Colors.black.withOpacity(0.7),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['title'] ?? 'No Title', style: _glowTextSmall.copyWith(fontSize: 14)),
                          Text(item['desc'] ?? '', style: const TextStyle(color: Colors.white70, fontSize: 10), maxLines: 2, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // --- BOTTOM NAV TARGET STYLE (BIDIKAN KEREN) ---
  Widget _buildNavTargetIcon(IconData icon, double size) {
    return SizedBox(
      width: 50,
      height: 50,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Outer Glow Circle (Target Scope)
          Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _glowColor.withOpacity(0.8), width: 1.5),
              boxShadow: [
                BoxShadow(color: _glowColor.withOpacity(0.5), blurRadius: 10, spreadRadius: 1)
              ],
            ),
          ),
          
          // Crosshairs (Bidikan)
          // Top Mark
          Positioned(top: 0, child: Container(width: 2, height: 6, color: _glowColor)),
          // Bottom Mark
          Positioned(bottom: 0, child: Container(width: 2, height: 6, color: _glowColor)),
          // Left Mark
          Positioned(left: 0, child: Container(width: 6, height: 2, color: _glowColor)),
          // Right Mark
          Positioned(right: 0, child: Container(width: 6, height: 2, color: _glowColor)),

          // The Icon inside
          Center(child: FaIcon(icon, size: size, color: Colors.white)),
        ],
      ),
    );
  }

  // --- PROFILE MENU BARU ---
  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0F0000).withOpacity(0.95),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
          border: Border(top: BorderSide(color: _glowColor.withOpacity(0.5))),
        ),
        padding: const EdgeInsets.all(25),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle Bar
            Container(width: 50, height: 4, color: Colors.grey.withOpacity(0.3), margin: const EdgeInsets.only(bottom: 25)),
            
            // 1. Profile Picture
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: _glowColor, width: 2),
                image: const DecorationImage(
                  image: AssetImage("assets/images/poto.jpg"),
                  fit: BoxFit.cover,
                ),
                boxShadow: [BoxShadow(color: _glowColor.withOpacity(0.3), blurRadius: 15)]
              ),
            ),
            const SizedBox(height: 20),

            // 2. Blurred Username
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  color: Colors.red.withOpacity(0.1),
                  child: Text(
                    username.toUpperCase(),
                    style: const TextStyle(fontFamily: "Orbitron", fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 3. Expired Date Area
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white24)
              ),
              child: Text("Expired: $expiredDate", style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono", fontSize: 12)),
            ),
            
            const SizedBox(height: 30),

            // 4. Buttons (Side by Side)
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.blue.withOpacity(0.7)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 12)
                    ),
                    icon: const Icon(Icons.lock_reset, size: 18),
                    label: const Text("Change Pass"),
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey)));
                    },
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.redAccent,
                      side: BorderSide(color: Colors.red.withOpacity(0.7)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                       padding: const EdgeInsets.symmetric(vertical: 12)
                    ),
                    icon: const Icon(Icons.logout, size: 18),
                    label: const Text("Logout"),
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  // --- DRAWER BARU ---
  Widget _buildDrawer() {
    final List<Widget> drawerItems = [
       const Padding(
          padding: EdgeInsets.only(bottom: 10, left: 10),
          child: Text("Management Info", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: "Orbitron")),
        ),
        _buildSidebarButton(
          icon: FontAwesomeIcons.bagShopping,
          text: "Seller Page",
          onTap: () => _navigateToPage(SellerPage(keyToken: sessionKey)),
        ),
        const SizedBox(height: 10),
        _buildSidebarButton(
          icon: FontAwesomeIcons.crown,
          text: "Admin Page",
          onTap: () => _navigateToPage(AdminPage(sessionKey: sessionKey)),
        ),
        const SizedBox(height: 10),
        _buildSidebarButton(
          icon: FontAwesomeIcons.whatsapp,
          text: "Manage Sender",
          onTap: () => _navigateToPage(SenderPage(sessionKey: sessionKey)),
        ),
        const SizedBox(height: 15),
        const Divider(color: Colors.white12, thickness: 1),
        const SizedBox(height: 15),
        const Padding(
          padding: EdgeInsets.only(bottom: 10, left: 10),
          child: Text("More Tools", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: "Orbitron")),
        ),
        // All Tools Expansion (Styling matched)
        Container(
          decoration: BoxDecoration(
            color: _isSidebarToolsExpanded ? const Color(0xFF150000) : Colors.transparent,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: _accentRed.withOpacity(_isSidebarToolsExpanded ? 0.5 : 0.0)),
          ),
          child: Column(
            children: [
              _buildSidebarButton(
                icon: FontAwesomeIcons.windows,
                text: "All Tools",
                isExpandable: true,
                isExpanded: _isSidebarToolsExpanded,
                onTap: () => setState(() => _isSidebarToolsExpanded = !_isSidebarToolsExpanded),
              ),
              if (_isSidebarToolsExpanded)
                Padding(
                  padding: const EdgeInsets.only(left: 20, right: 10, bottom: 10),
                  child: Column(
                    children: [
                      _buildMiniToolBtn(Icons.signal_wifi_off, "Wifi Killer", () => _navigateToPage(WifiKillerPage())),
                      _buildMiniToolBtn(FontAwesomeIcons.tiktok, "Tiktok Downloader", () => _navigateToPage(TiktokDownloaderPage())),
                      _buildMiniToolBtn(Icons.smartphone, "Phone Lookup", () => _navigateToPage(PhoneLookupPage(sessionKey: sessionKey))),
                      _buildMiniToolBtn(FontAwesomeIcons.instagram, "Instagram Downloader", () => _navigateToPage(InstagramDownloaderPage())),
                      _buildMiniToolBtn(FontAwesomeIcons.robot, "Ai Asistent", () => _navigateToPage(ChatAIPage(sessionKey: sessionKey))),
                      _buildMiniToolBtn(FontAwesomeIcons.idCard, "Nik Checker", () => _navigateToPage(NIKCheckPage(sessionKey: sessionKey))),
                      _buildMiniToolBtn(Icons.language, "Subdomain Finder", () => _navigateToPage(SubdomainFinderPage(sessionKey: sessionKey))),
                      _buildMiniToolBtn(Icons.play_circle_fill, "Anime Stastion", () => _navigateToPage(HomeAnimePage())),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        _buildSidebarButton(
          icon: FontAwesomeIcons.telegram,
          text: "Report Telegram",
          onTap: () {
            // Navigasi ke halaman Report Bans
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ReportBansPage(sessionKey: sessionKey),
              ),
            );
          },
        ),
        const SizedBox(height: 15),
        const Divider(color: Colors.white12, thickness: 1),
        const SizedBox(height: 15),
        const Padding(
          padding: EdgeInsets.only(bottom: 10, left: 10),
          child: Text("Help & Developer", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: "Orbitron")),
        ),
        _buildSidebarButton(
          icon: FontAwesomeIcons.code,
          text: "Contact Developer",
          onTap: () async {
            final uri = Uri.parse("https://t.me/kaitonotdev");
            if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
          },
        ),
        const SizedBox(height: 10),
         _buildSidebarButton(
          icon: FontAwesomeIcons.circleQuestion,
          text: "Bantuan",
          onTap: () {
             ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Comming Soon")));
          },
        ),
        const SizedBox(height: 50),
    ];

    return Drawer(
      backgroundColor: Colors.black,
      child: Column(
        children: [
          // Sidebar Header
          SizedBox(
            height: 200,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset("assets/images/side.jpg", fit: BoxFit.cover,
                    errorBuilder: (ctx, err, stack) => Container(color: const Color(0xFF1A0505)),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withOpacity(0.9)],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 20, left: 20, right: 20,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                        decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(15), border: Border.all(color: _accentRed)),
                        child: Text("Username : $username\nRole : $role", textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontFamily: "Orbitron")),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(color: Colors.white12, height: 1),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              itemCount: drawerItems.length,
              itemBuilder: (context, index) => SidebarItemReveal(delay: index * 50, child: drawerItems[index]),
            ),
          ),
        ],
      ),
    );
  }

  // --- TOMBOL SIDEBAR BARU (LONJONG & BERGARIS) ---
  Widget _buildSidebarButton({
    required IconData icon, 
    required String text, 
    required VoidCallback onTap, 
    bool isExpandable = false, 
    bool isExpanded = false
  }) {
    // Dominan Merah untuk semua tombol sidebar
    Color btnColor = const Color(0xFF8B0000); 

    return Container(
      margin: const EdgeInsets.only(bottom: 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(50), // SANGAT LONJONG
        gradient: LinearGradient(
          colors: [btnColor.withOpacity(0.2), Colors.transparent],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(50),
          splashColor: btnColor.withOpacity(0.4),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 15),
            child: Row(
              children: [
                // GARIS TEBAL DI KIRI
                Container(
                  height: 20,
                  width: 4,
                  margin: const EdgeInsets.only(right: 15),
                  decoration: BoxDecoration(
                    color: _glowColor,
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [BoxShadow(color: _glowColor, blurRadius: 5)]
                  ),
                ),
                Icon(icon, color: Colors.white, size: 18),
                const SizedBox(width: 15),
                Expanded(child: Text(text, style: const TextStyle(color: Colors.white, fontFamily: "Orbitron", fontWeight: FontWeight.bold, fontSize: 11))),
                if (isExpandable)
                   Icon(isExpanded ? Icons.remove : Icons.add, color: Colors.white54, size: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMiniToolBtn(IconData icon, String text, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: Row(
            children: [
              Icon(icon, color: Colors.redAccent, size: 14),
              const SizedBox(width: 10),
              Text(text, style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: "ShareTechMono")),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: _primaryBackground,
      appBar: AppBar(
        title: Text(
          "Hello, $username",
          style: const TextStyle(color: Colors.white, fontSize: 16, fontFamily: "Orbitron", fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(color: Colors.black.withOpacity(0.2)),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(FontAwesomeIcons.headset, color: _glowColor, size: 20),
            onPressed: () async {
              final uri = Uri.parse("https://t.me/kaitonotdev");
              if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
            },
          ),
          IconButton(
            icon: const Icon(Icons.person, color: Colors.white),
            onPressed: _showAccountMenu,
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          // 1. Background (Pure Black)
          Container(
            color: Colors.black, // Background Hitam Polos
          ),
          // 2. Content
          SafeArea(
            top: false,
            bottom: false,
            child: FadeTransition(opacity: _animation, child: _selectedPage),
          ),
        ],
      ),
      // BOTTOM NAV FUSED (Menyatu kebawah)
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0A0000).withOpacity(0.8), // Dark transparent
          border: Border(top: BorderSide(color: _accentRed.withOpacity(0.3))),
        ),
        child: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: BottomNavigationBar(
              backgroundColor: Colors.transparent,
              selectedItemColor: _glowColor,
              unselectedItemColor: Colors.grey,
              selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontFamily: "Orbitron", fontSize: 10),
              showUnselectedLabels: false,
              showSelectedLabels: true,
              currentIndex: _selectedIndex,
              onTap: _onTabSelected,
              type: BottomNavigationBarType.fixed,
              elevation: 0,
              items: [
                BottomNavigationBarItem(
                  icon: _selectedIndex == 0 ? _buildNavTargetIcon(FontAwesomeIcons.house, 20) : const Icon(FontAwesomeIcons.house, size: 20),
                  label: "Home",
                ),
                BottomNavigationBarItem(
                  key: _bugButtonKey,
                  icon: _selectedIndex == 1 ? _buildNavTargetIcon(FontAwesomeIcons.whatsapp, 20) : const Icon(FontAwesomeIcons.whatsapp, size: 20),
                  label: "Bug",
                ),
                BottomNavigationBarItem(
                  icon: _selectedIndex == 2 ? _buildNavTargetIcon(FontAwesomeIcons.rocket, 20) : const Icon(FontAwesomeIcons.rocket, size: 20),
                  label: "DDoS",
                ),
                BottomNavigationBarItem(
                  // Handshake Icon static (no scale animation)
                  icon: _selectedIndex == 3 ? _buildNavTargetIcon(FontAwesomeIcons.handshake, 20) : const Icon(FontAwesomeIcons.handshake, size: 20),
                  label: "Tq To",
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    try { channel.sink.close(status.goingAway); } catch (e) {}
    _timer?.cancel(); // Cancel Timer
    _controller.dispose();
    _toolsAnimController.dispose();
    _pageController.dispose();
    super.dispose();
  }
}

// --- HELPER CLASSES (SidebarReveal, Media) ---

class SidebarItemReveal extends StatefulWidget {
  final Widget child; final int delay;
  const SidebarItemReveal({super.key, required this.child, required this.delay});
  @override
  State<SidebarItemReveal> createState() => _SidebarItemRevealState();
}

class _SidebarItemRevealState extends State<SidebarItemReveal> with SingleTickerProviderStateMixin {
  late AnimationController _controller; late Animation<double> _opacity; late Animation<Offset> _slide;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _opacity = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _slide = Tween<Offset>(begin: const Offset(-0.2, 0), end: Offset.zero).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutQuad));
    Future.delayed(Duration(milliseconds: widget.delay), () { if (mounted) _controller.forward(); });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(opacity: _opacity, child: SlideTransition(position: _slide, child: widget.child));
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))..initialize().then((_) { if (mounted) { setState(() {}); _controller?.setLooping(true); _controller?.setVolume(0.0); _controller?.play(); } });
    }
  }
  bool _isVideo(String url) => url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");
  @override
  void dispose() { _controller?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return FittedBox(fit: BoxFit.cover, child: SizedBox(width: _controller!.value.size.width, height: _controller!.value.size.height, child: VideoPlayer(_controller!)));
      } else { return const Center(child: CircularProgressIndicator(color: Colors.redAccent)); }
    } else {
      return Image.network(widget.url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white24, size: 50));
    }
  }
}