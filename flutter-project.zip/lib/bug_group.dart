import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  final linkGroupController = TextEditingController();
  static const String baseUrl = "http://rixzz-privat-panel.sano.biz.id:11490";

  // --- Controllers ---
  late AnimationController _buttonController;
  late VideoPlayerController _bannerVideoController;

  // --- States ---
  bool _bannerVideoInitialized = false;
  bool _isSending = false;

  // --- Theme Colors (Clean Dark Red) ---
  final Color primaryRed = const Color(0xFFD50000); 
  final Color darkRed = const Color(0xFF8B0000);
  final Color cleanGlass = const Color(0xFFFFFFFF).withOpacity(0.08); // Blur Putih Halus
  final Color borderColor = const Color(0xFFD50000).withOpacity(0.4);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeBannerVideo();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
  }

  void _initializeBannerVideo() {
    _bannerVideoController = VideoPlayerController.asset('assets/videos/semuadiamm.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bannerVideoInitialized = true);
          _bannerVideoController.setLooping(true);
          _bannerVideoController.play();
          _bannerVideoController.setVolume(0);
        }
      }).catchError((e) => debugPrint("Banner Video Error: $e"));
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _bannerVideoController.dispose();
    linkGroupController.dispose();
    super.dispose();
  }

  // --- LOGIC ---

  bool _isValidGroupLink(String input) {
    return input.contains("chat.whatsapp.com");
  }

  Future<void> _sendGroupBug() async {
    if (_isSending) return;

    await _buttonController.forward();
    await _buttonController.reverse();

    final linkGroup = linkGroupController.text.trim();
    final key = widget.sessionKey;

    if (linkGroup.isEmpty || !_isValidGroupLink(linkGroup)) {
      _showPopup("Invalid Link", "Please enter a valid WhatsApp group link.", isError: true);
      return;
    }

    setState(() => _isSending = true);

    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/groupBug?key=$key&linkGroup=$linkGroup"));
      final data = jsonDecode(res.body);

      setState(() => _isSending = false);

      if (data["valid"] == false) {
        _showPopup("Failed", data["message"] ?? "Failed to send group bug.", isError: true);
      } else {
        if (mounted) _showSuccessPopup(linkGroup, data);
      }
    } catch (_) {
      setState(() => _isSending = false);
      _showPopup("Error", "Connection failed. Please try again.", isError: true);
    }
  }

  void _showPopup(String title, String message, {bool isError = false}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF151515),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: isError ? primaryRed : Colors.greenAccent, width: 1),
          ),
          title: Row(
            children: [
              Icon(
                isError ? FontAwesomeIcons.circleExclamation : FontAwesomeIcons.circleCheck, 
                color: isError ? primaryRed : Colors.greenAccent,
                size: 20,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ],
          ),
          content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }

  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => SuccessDialog(
        linkGroup: linkGroup,
        data: data,
        primaryColor: primaryRed,
      ),
    );
  }

  // --- UI BUILDER ---

  @override
  Widget build(BuildContext context) {
    // Security Check
    if (!["vip", "owner"].contains(widget.role.toLowerCase())) {
      return const Scaffold(backgroundColor: Colors.black, body: Center(child: Text("ACCESS DENIED", style: TextStyle(color: Colors.red))));
    }

    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          // 1. Ambient Background
          Positioned(
            top: -150,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [primaryRed.withOpacity(0.15), Colors.transparent],
                  radius: 0.6,
                ),
              ),
            ),
          ),

          // 2. MAIN CONTENT
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildHeaderProfile(),
                    
                    // PERUBAHAN DI SINI: Jarak dirapatkan dari 20 menjadi 8
                    const SizedBox(height: 8),
                    
                    _buildCleanBanner(),
                    const SizedBox(height: 25),
                    _buildInputArea(),
                    const SizedBox(height: 30),
                    _buildSendButton(),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- COMPONENTS ---

  Widget _buildHeaderProfile() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cleanGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Container(
            width: 55,
            height: 55,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: primaryRed, width: 2),
              image: const DecorationImage(
                image: AssetImage('assets/images/pp.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(FontAwesomeIcons.clock, color: Colors.white54, size: 10),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        "Expired : ${widget.expiredDate}  •  Role : ${widget.role.toUpperCase()}",
                        style: const TextStyle(
                          color: Colors.white70,
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCleanBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 160,
        width: double.infinity,
        color: Colors.black,
        child: Stack(
          children: [
            if (_bannerVideoInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bannerVideoController.value.size.width,
                    height: _bannerVideoController.value.size.height,
                    child: VideoPlayer(_bannerVideoController),
                  ),
                ),
              )
            else
              const Center(child: CircularProgressIndicator(color: Colors.white)),
            
            Positioned(
              bottom: 0, left: 0, right: 0, height: 60,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                  ),
                ),
              ),
            ),

            Positioned(
              bottom: 12,
              left: 15,
              child: Text(
                "REVENGERS",
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                  letterSpacing: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 5, bottom: 8),
          child: Row(
            children: [
              Icon(FontAwesomeIcons.link, color: primaryRed, size: 12),
              const SizedBox(width: 8),
              const Text(
                "LINK GROUP",
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 10, 
                  fontFamily: 'Orbitron', 
                  fontWeight: FontWeight.bold
                ),
              ),
            ],
          ),
        ),

        Container(
          decoration: BoxDecoration(
            color: cleanGlass,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white10),
          ),
          child: TextField(
            controller: linkGroupController,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
            cursorColor: primaryRed,
            decoration: InputDecoration(
              hintText: "https://chat.whatsapp.com/...",
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
              
              prefixIcon: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(width: 14),
                  const Icon(FontAwesomeIcons.globe, color: Colors.white70, size: 16),
                  const SizedBox(width: 12),
                  Container(
                    width: 1,
                    height: 24,
                    color: Colors.white24,
                  ),
                  const SizedBox(width: 12),
                ],
              ),
            ),
          ),
        ),

        const SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            "Disclaimer: This bug can affect anyone, including the sender, so please be careful.",
            style: TextStyle(
              color: Colors.white38,
              fontFamily: 'ShareTechMono',
              fontSize: 10,
              fontStyle: FontStyle.italic,
            ),
            textAlign: TextAlign.justify,
          ),
        ),
      ],
    );
  }

  Widget _buildSendButton() {
    return GestureDetector(
      onTap: _isSending ? null : _sendGroupBug,
      child: AnimatedBuilder(
        animation: _buttonController,
        builder: (context, child) {
          return Transform.scale(
            scale: 1.0 - (_buttonController.value * 0.05),
            child: Container(
              height: 50,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryRed, darkRed],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: primaryRed.withOpacity(0.4),
                    blurRadius: 15,
                    offset: const Offset(0, 4),
                  )
                ],
              ),
              child: Center(
                child: _isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(FontAwesomeIcons.users, color: Colors.white, size: 16),
                        const SizedBox(width: 10),
                        const Text(
                          "SEND BUG",
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// --- POP-UP SUCCESS (Clean Style) ---

class SuccessDialog extends StatelessWidget {
  final String linkGroup;
  final Map<String, dynamic> data;
  final Color primaryColor;

  const SuccessDialog({
    super.key,
    required this.linkGroup,
    required this.data,
    required this.primaryColor,
  });

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
      child: Dialog(
        backgroundColor: const Color(0xFF151515),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: primaryColor, width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: primaryColor.withOpacity(0.1),
                  border: Border.all(color: primaryColor),
                ),
                child: Icon(FontAwesomeIcons.check, color: primaryColor, size: 30),
              ),
              const SizedBox(height: 15),
              Text(
                "SUCCESS EXECUTED",
                style: TextStyle(
                  color: primaryColor,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 15),
              Divider(color: Colors.white10),
              const SizedBox(height: 10),
              _buildDetailRow("Target Type", "Group WhatsApp"),
              _buildDetailRow("Status", "Attack Sent"),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: const Text("Ok", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'ShareTechMono')),
          Text(value, style: TextStyle(color: primaryColor, fontSize: 12, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
