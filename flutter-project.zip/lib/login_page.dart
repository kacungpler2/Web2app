import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'dart:ui';

const String baseUrl = "http://rixzz-privat-panel.sano.biz.id:11490";

// --- TEMA BARU: MERAH TUA GELAP (DARK RED THEME) ---
class AppColors {
  static const Color primaryRed = Color(0xFFD32F2F); // Merah utama
  static const Color brightRed = Color(0xFFFF1744); // Merah terang untuk aksen/glow
  static const Color darkRed = Color(0xFF8E0000); // Merah sangat gelap (background elemen)
  static const Color background = Color(0xFF050000); // Hitam kemerahan
  static const Color cardBackground = Color(0x00000000); // Transparan
  static const Color textDark = Color(0xFFFFFFFF); // Teks putih
  static const Color textRed = Color(0xFFFFCDD2); // Teks merah muda pudar
  static const Color inputBackground = Color(0x40000000); // Background input transparan gelap
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    initLogin();
    // Initialize video controller dengan asset baru
    _videoController = VideoPlayerController.asset('assets/videos/bg.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.play();
        _videoController.setVolume(0);
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (!mounted) return;
          Navigator.pushReplacementNamed(
            context,
            '/loader',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
      } else if (validData['valid'] != true) {
        _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (!mounted) return;
        Navigator.pushNamed(
          context,
          '/loader',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listPayload': validData['listPayload'] ?? [],
            'listDDoS': validData['listDDoS'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (_) {
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }

    setState(() => isLoading = false);
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.9),
        title: Text(
          title,
          style: const TextStyle(
            color: AppColors.brightRed,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: AppColors.textDark,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: AppColors.primaryRed, width: 1),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: _launchDeveloperContact,
              child: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: AppColors.brightRed,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: AppColors.textDark,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Fungsi baru untuk membuka kontak developer
  Future<void> _launchDeveloperContact() async {
    final uri = Uri.parse("https://t.me/CantikaxXxPdl");
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
         throw 'Could not launch $uri';
      }
    } catch (e) {
      // Fallback jika gagal
      debugPrint("Error launching URL: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // 1. Background Video
          SizedBox(
            height: double.infinity,
            width: double.infinity,
            child: FittedBox(
              fit: BoxFit.cover,
              child: _videoController.value.isInitialized
                  ? SizedBox(
                width: _videoController.value.size.width,
                height: _videoController.value.size.height,
                child: VideoPlayer(_videoController),
              )
                  : Container(color: AppColors.background),
            ),
          ),
          
          // 2. Blur Effect
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              color: Colors.black.withOpacity(0.5), // Overlay hitam transparan
            ),
          ),

          // 3. Login Form Content
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  // Foto Transparan Pemanggilan (Login PNG)
                  Image.asset(
                    'assets/images/login.png', 
                    height: 180,
                    fit: BoxFit.contain,
                  ),
                  
                  const SizedBox(height: 40),

                  // --- Input Username Section ---
                  _buildLabel(Icons.input_rounded, "Input Username"),
                  const SizedBox(height: 8),
                  _buildCustomTextField(
                    controller: userController, 
                    hint: "Username...",
                    icon: null
                  ),

                  const SizedBox(height: 20),

                  // --- Input Password Section ---
                  _buildLabel(Icons.vpn_key_rounded, "Input Password"),
                  const SizedBox(height: 8),
                  _buildCustomTextField(
                    controller: passController, 
                    hint: "Password...",
                    isPassword: true
                  ),

                  const SizedBox(height: 35),

                  // --- Tombol MASUK ---
                  Container(
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.brightRed.withOpacity(0.4),
                          blurRadius: 15,
                          offset: const Offset(0, 4),
                        ),
                      ],
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: ElevatedButton(
                      onPressed: isLoading ? null : login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.darkRed.withOpacity(0.8),
                        foregroundColor: AppColors.textDark,
                        minimumSize: const Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                          side: const BorderSide(color: AppColors.brightRed, width: 1.5),
                        ),
                        elevation: 0,
                      ),
                      child: isLoading
                          ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: AppColors.textDark,
                          strokeWidth: 2,
                        ),
                      )
                          : const Text(
                        "MASUK",
                        style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // --- Tombol Contacts Developer ---
                  OutlinedButton(
                    onPressed: _launchDeveloperContact,
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50),
                      side: BorderSide(color: AppColors.primaryRed.withOpacity(0.5)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      backgroundColor: Colors.black.withOpacity(0.3),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.link, color: AppColors.textRed), // Icon Rantai
                        SizedBox(width: 10),
                        Text(
                          "Contacts Developer",
                          style: TextStyle(
                            fontSize: 15,
                            color: AppColors.textRed,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget untuk Label (Icon + Teks Judul)
  Widget _buildLabel(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: AppColors.brightRed, size: 20),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            color: AppColors.textDark,
            fontFamily: 'Orbitron', // Font futuristik
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  // Widget untuk Input Field Custom
  Widget _buildCustomTextField({
    required TextEditingController controller,
    required String hint,
    IconData? icon,
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.inputBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkRed),
        boxShadow: [
           BoxShadow(
             color: Colors.black.withOpacity(0.2),
             blurRadius: 4,
             offset: const Offset(0, 2),
           )
        ]
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        style: const TextStyle(
          color: AppColors.textDark,
          fontFamily: 'ShareTechMono',
          fontSize: 16,
        ),
        cursorColor: AppColors.brightRed,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: AppColors.textDark.withOpacity(0.4),
            fontFamily: 'ShareTechMono',
          ),
          prefixIcon: icon != null 
              ? Icon(icon, color: AppColors.primaryRed) 
              : const SizedBox(width: 15), // Spacer jika tidak ada icon di dalam
          prefixIconConstraints: icon == null ? const BoxConstraints(minWidth: 15) : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }
}
