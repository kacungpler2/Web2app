import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  // Flag untuk update
  bool _updateAvailable = false;
  bool _isLoading = true;
  String _updateMessage = "";
  String _updateVersion = "";
  String _downloadUrl = "";
  
  // Base URL API
  final String _baseUrl = "https://eghatzy.rexypediaa.my.id:25565";
  final String _defaultDownloadUrl = "https://t.me/eghatzy";

  // Tema warna sederhana
  final Color primaryDark = const Color(0xFF0A0A1A);
  final Color accentBlue = const Color(0xFF4285F4);
  final Color cardBg = Colors.white.withOpacity(0.04);

  @override
  void initState() {
    super.initState();
    _checkForUpdatesFromServer();
  }
  
  Future<void> _checkForUpdatesFromServer() async {
    setState(() => _isLoading = true);
    
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedUpdateStatus = prefs.getBool('update_required') ?? false;
      final cachedUpdateMessage = prefs.getString('update_message') ?? "";
      final cachedUpdateVersion = prefs.getString('update_version') ?? "";
      final cachedDownloadUrl = prefs.getString('download_url') ?? _defaultDownloadUrl;
      
      try {
        final response = await http.get(
          Uri.parse("$_baseUrl/checkUpdate"),
          headers: {
            'Content-Type': 'application/json',
          },
        ).timeout(const Duration(seconds: 5));
        
        if (response.statusCode == 200) {
          final Map<String, dynamic> data = json.decode(response.body);
          
          if (data['show_update'] == true) {
            bool isValid = true;
            if (data['expiredDate'] != null && data['expiredDate'].toString().isNotEmpty) {
              try {
                final expired = DateTime.parse(data['expiredDate']);
                final now = DateTime.now();
                isValid = now.isBefore(expired) || now.isAtSameMomentAs(expired);
              } catch (e) {
                isValid = true;
              }
            }
            
            if (isValid) {
              _updateAvailable = true;
              _updateMessage = data['message'] ?? "System undergoing upgrade";
              _updateVersion = data['version'] ?? "";
              _downloadUrl = data['downloadUrl'] ?? _defaultDownloadUrl;
            } else {
              _updateAvailable = false;
            }
          } else {
            _updateAvailable = false;
          }
          
          await prefs.setBool('update_required', _updateAvailable);
          await prefs.setString('update_message', _updateMessage);
          await prefs.setString('update_version', _updateVersion);
          await prefs.setString('download_url', _downloadUrl);
        } else {
          _updateAvailable = cachedUpdateStatus;
          _updateMessage = cachedUpdateMessage;
          _updateVersion = cachedUpdateVersion;
          _downloadUrl = cachedDownloadUrl;
        }
      } catch (e) {
        _updateAvailable = cachedUpdateStatus;
        _updateMessage = cachedUpdateMessage;
        _updateVersion = cachedUpdateVersion;
        _downloadUrl = cachedDownloadUrl;
      }
      
      setState(() => _isLoading = false);
      
      if (_updateAvailable && mounted) {
        _showUpdateDialog();
      }
      
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }
  
  void _showUpdateDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async => false,
          child: Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.all(20),
            child: _buildUpdateDialog(),
          ),
        );
      },
    );
  }
  
  Widget _buildUpdateDialog() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: primaryDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: accentBlue.withOpacity(0.4),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: accentBlue.withOpacity(0.3),
            blurRadius: 30,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.build_circle_outlined,
            color: accentBlue,
            size: 50,
          ),
          const SizedBox(height: 16),
          Text(
            _updateVersion.isNotEmpty ? "UPDATE v$_updateVersion" : "UPDATE REQUIRED",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              _updateMessage.isNotEmpty 
                  ? _updateMessage
                  : "System undergoing upgrade",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 14,
                height: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: accentBlue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () => _openUrl(_downloadUrl),
              child: const Text(
                "DOWNLOAD NOW",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            "Access Blocked Until Update",
            style: TextStyle(
              color: accentBlue,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: primaryDark,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircularProgressIndicator(
                color: Color(0xFF4285F4),
                strokeWidth: 3,
              ),
              const SizedBox(height: 20),
              Text(
                "Loading...",
                style: TextStyle(
                  color: Colors.white54,
                  letterSpacing: 2,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      );
    }
    
    return Scaffold(
      backgroundColor: primaryDark,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _checkForUpdatesFromServer,
          color: accentBlue,
          backgroundColor: primaryDark,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                const SizedBox(height: 40),
                
                // Logo
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: accentBlue.withOpacity(0.5),
                      width: 3,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: accentBlue.withOpacity(0.2),
                        blurRadius: 30,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      "assets/images/logo.jpg",
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          color: accentBlue.withOpacity(0.2),
                          child: Icon(Icons.person, size: 60, color: Colors.white),
                        );
                      },
                    ),
                  ),
                ),
                
                const SizedBox(height: 30),
                
                // Judul
                Text(
                  "BULGHAxRAT V1",
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 4,
                  ),
                ),
                
                const SizedBox(height: 10),
                
                Text(
                  "AUTHORIZED ACCESS ONLY",
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 3,
                  ),
                ),
                
                const SizedBox(height: 50),
                
                // Card Glass
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: cardBg,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.08),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      // Tombol Login
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentBlue,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _updateAvailable ? null : () {
                            Navigator.pushNamed(context, "/login");
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.login_rounded,
                                color: _updateAvailable ? Colors.white38 : Colors.white,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "LOGIN",
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: _updateAvailable ? Colors.white38 : Colors.white,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Tombol Buy Access
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(
                              color: _updateAvailable ? Colors.white24 : accentBlue,
                              width: 1.5,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _updateAvailable ? null : () => _openUrl("https://t.me/eghatzy"),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.shopping_bag_rounded,
                                color: _updateAvailable ? Colors.white24 : accentBlue,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "GET ACCESS",
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: _updateAvailable ? Colors.white24 : accentBlue,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 30),
                
                // Social Media
                Row(
                  children: [
                    Expanded(
                      child: _buildSocialButton(
                        icon: FontAwesomeIcons.telegram,
                        label: "Telegram",
                        url: "https://t.me/eghatzy",
                        color: const Color(0xFF0088cc),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildSocialButton(
                        icon: FontAwesomeIcons.whatsapp,
                        label: "WhatsApp",
                        url: "https://wa.me/6283136741448",
                        color: const Color(0xFF25D366),
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 40),
                
                // Footer
                Column(
                  children: [
                    Text(
                      "© 2025 BulghaxRat Project",
                      style: TextStyle(
                        color: Colors.white24,
                        fontSize: 11,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "SECURE CONNECTION",
                      style: TextStyle(
                        color: Colors.white12,
                        fontSize: 8,
                        letterSpacing: 3,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required String label,
    required String url,
    required Color color,
  }) {
    return InkWell(
      onTap: _updateAvailable ? null : () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: cardBg,
          border: Border.all(
            color: _updateAvailable ? Colors.white.withOpacity(0.03) : Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(
              icon,
              color: _updateAvailable ? Colors.white24 : color,
              size: 16,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: _updateAvailable ? Colors.white24 : Colors.white70,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}