import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  // --- Controllers ---
  final _newUser = TextEditingController();
  final _newPass = TextEditingController();
  final _days = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();
  
  bool loading = false;

  // --- Theme Colors ---
  final Color primaryRed = const Color(0xFFD50000);
  final Color darkRed = const Color(0xFF8B0000);
  final Color bgBlack = const Color(0xFF050505);
  final Color glassWhite = const Color(0xFFFFFFFF).withOpacity(0.05);

  // --- API Logic ---
  Future<void> _create() async {
    final u = _newUser.text.trim(), p = _newPass.text.trim(), d = _days.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _showNotification("All fields are required", isError: true);
      return;
    }
    
    try {
      final res = await http.get(Uri.parse(
          "http://rixzz-privat-panel.sano.biz.id:11490/api/user/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);
      
      if (data['created'] == true) {
        if (mounted) {
          _showNotification("Account created successfully!");
          _newUser.clear(); _newPass.clear(); _days.clear();
          Navigator.pop(context);
        }
      } else {
        if (mounted) _showNotification(data['message'] ?? 'Failed to create account.', isError: true);
      }
    } catch (e) {
      if (mounted) _showNotification("Connection error: ${e.toString()}", isError: true);
    }
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim(), d = _editDays.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _showNotification("Username and days required", isError: true);
      return;
    }

    try {
      final res = await http.get(Uri.parse(
          "http://rixzz-privat-panel.sano.biz.id:11490/api/user/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);
      
      if (data['edited'] == true) {
        if (mounted) {
          _showNotification("Duration updated successfully.");
          _editUser.clear(); _editDays.clear();
          Navigator.pop(context);
        }
      } else {
        if (mounted) _showNotification(data['message'] ?? 'Failed to update user.', isError: true);
      }
    } catch (e) {
      if (mounted) _showNotification("Connection error: ${e.toString()}", isError: true);
    }
  }

  void _showNotification(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(isError ? FontAwesomeIcons.triangleExclamation : FontAwesomeIcons.circleCheck, 
              color: Colors.white, size: 18),
            const SizedBox(width: 12),
            Expanded(child: Text(message, style: const TextStyle(fontFamily: 'ShareTechMono'))),
          ],
        ),
        backgroundColor: isError ? darkRed : Colors.green[800],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: isError ? primaryRed : Colors.greenAccent, width: 1),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Positioned(
            top: -100, left: -50,
            child: Container(
              width: 300, height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [darkRed.withOpacity(0.2), Colors.transparent],
                ),
              ),
            ),
          ),
          
          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.85,
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                color: const Color(0xFF101010),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  )
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: primaryRed.withOpacity(0.1),
                      shape: BoxShape.circle,
                      border: Border.all(color: primaryRed.withOpacity(0.5)),
                    ),
                    child: Icon(FontAwesomeIcons.userTie, color: primaryRed, size: 32),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "RESELLER DASHBOARD",
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      letterSpacing: 1,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "Manage your clients efficiently",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  _buildMenuButton(
                    "CREATE ACCOUNT", 
                    "Generate new access", 
                    FontAwesomeIcons.userPlus, 
                    _showCreateDialog
                  ),
                  const SizedBox(height: 16),
                  _buildMenuButton(
                    "EXTEND DURATION", 
                    "Update expired user", 
                    FontAwesomeIcons.clock, 
                    _showEditDialog
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            top: 40, left: 20,
            child: IconButton(
              icon: const Icon(FontAwesomeIcons.arrowLeft, color: Colors.white70),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuButton(String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: primaryRed.withOpacity(0.2),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          decoration: BoxDecoration(
            color: glassWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white10),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white12),
                ),
                child: Icon(icon, color: primaryRed, size: 18),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.4), fontFamily: 'ShareTechMono', fontSize: 11)),
                  ],
                ),
              ),
              const Icon(FontAwesomeIcons.chevronRight, color: Colors.white24, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  void _showCreateDialog() {
    _showCustomDialog(
      title: "CREATE NEW USER",
      subtitle: "Enter details for the new client",
      icon: FontAwesomeIcons.userPlus,
      children: [
        _buildInputField("Username", _newUser, FontAwesomeIcons.user),
        const SizedBox(height: 12),
        _buildInputField("Password", _newPass, FontAwesomeIcons.lock),
        const SizedBox(height: 12),
        _buildInputField("Duration (Days)", _days, FontAwesomeIcons.calendarDay, isNumber: true),
      ],
      onConfirm: _create,
    );
  }

  void _showEditDialog() {
    _showCustomDialog(
      title: "EXTEND USER",
      subtitle: "Add more days to existing user",
      icon: FontAwesomeIcons.clock,
      children: [
        _buildInputField("Target Username", _editUser, FontAwesomeIcons.user),
        const SizedBox(height: 12),
        _buildInputField("Add Days", _editDays, FontAwesomeIcons.plus, isNumber: true),
      ],
      onConfirm: _edit,
    );
  }

  // FIXED: Tipe parameter onConfirm diubah menjadi Future<void> Function()
  void _showCustomDialog({
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Widget> children,
    required Future<void> Function() onConfirm, 
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Dialog(
              backgroundColor: const Color(0xFF121212),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(color: primaryRed.withOpacity(0.3), width: 1),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [darkRed, const Color(0xFF500000)],
                        ),
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(19), topRight: Radius.circular(19)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(8)),
                            child: Icon(icon, color: Colors.white, size: 20),
                          ),
                          const SizedBox(width: 15),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16)),
                                const SizedBox(height: 4),
                                Text(subtitle, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 11)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(children: children),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                      child: Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: loading ? null : () => Navigator.pop(context),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: Colors.white24),
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              child: const Text("CANCEL", style: TextStyle(color: Colors.white70, fontFamily: 'Orbitron')),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: loading ? null : () async {
                                setDialogState(() => loading = true);
                                await onConfirm(); // Sekarang bisa di-await karena tipenya Future
                                if(mounted) setDialogState(() => loading = false); 
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryRed,
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              child: loading
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                  : const Text("CONFIRM", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }
      ),
    );
  }

  Widget _buildInputField(String hint, TextEditingController controller, IconData icon, {bool isNumber = false}) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white10),
      ),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
        cursorColor: primaryRed,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontFamily: 'ShareTechMono'),
          prefixIcon: Icon(icon, color: Colors.white38, size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
        ),
      ),
    );
  }
}
