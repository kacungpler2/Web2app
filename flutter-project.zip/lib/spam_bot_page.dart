import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;

class SpamBotPage extends StatefulWidget {
  final String sessionKey;
  const SpamBotPage({super.key, required this.sessionKey});

  @override
  State<SpamBotPage> createState() => _SpamBotPageState();
}

class _SpamBotPageState extends State<SpamBotPage> {
  final TextEditingController _tokenController = TextEditingController();
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _msgController = TextEditingController();
  final TextEditingController _delayController = TextEditingController(text: "1000");
  final TextEditingController _countController = TextEditingController(text: "10");
  bool _isSpamming = false;

  Future<void> _startSpam() async {
    setState(() => _isSpamming = true);
    int count = int.tryParse(_countController.text) ?? 0;
    int delay = int.tryParse(_delayController.text) ?? 1000;

    for (int i = 0; i < count; i++) {
      if (!_isSpamming) break;
      try {
        await http.post(
          Uri.parse("https://api.telegram.org/bot${_tokenController.text}/sendMessage"),
          body: {"chat_id": _idController.text, "text": _msgController.text},
        );
      } catch (e) {
        debugPrint("Error: $e");
      }
      await Future.delayed(Duration(milliseconds: delay));
    }
    
    if (mounted) {
      setState(() => _isSpamming = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Spam Completed!")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text("SPAM BOT TELE", style: TextStyle(fontFamily: "Orbitron", fontSize: 16)), backgroundColor: Colors.transparent),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildInputCard(FontAwesomeIcons.robot, "Bot Token", _tokenController, "123456:ABC-DEF..."),
            _buildInputCard(FontAwesomeIcons.idBadge, "Target ID", _idController, "987654321"),
            _buildInputCard(FontAwesomeIcons.commentDots, "Message", _msgController, "Hello world...", maxLines: 3),
            Row(
              children: [
                Expanded(child: _buildInputCard(Icons.timer, "Delay (ms)", _delayController, "1000")),
                const SizedBox(width: 15),
                Expanded(child: _buildInputCard(Icons.numbers, "Count", _countController, "10")),
              ],
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFB00000), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                onPressed: _isSpamming ? () => setState(() => _isSpamming = false) : _startSpam,
                child: Text(_isSpamming ? "STOP SPAM" : "SEND SPAM", style: const TextStyle(fontFamily: "Orbitron", color: Colors.white)),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildInputCard(IconData icon, String label, TextEditingController controller, String hint, {int maxLines = 1}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF0F0000), borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.red.withOpacity(0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Icon(icon, color: Colors.red, size: 14), const SizedBox(width: 8), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: "Orbitron"))]),
          TextField(
            controller: controller,
            maxLines: maxLines,
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(hintText: hint, hintStyle: const TextStyle(color: Colors.white24), border: InputBorder.none),
          ),
        ],
      ),
    );
  }
}
