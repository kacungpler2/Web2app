<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

$qris_error = '';
$qris_success = '';
$qr_image = '';
$ref_id = '';
$trx_reference = '';
$expired = '';
$amount_qris = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['deposit_qris'])) {
    $amount = (int) $_POST['amount'];
    $min_deposit = 80000;
    
    if ($amount < $min_deposit) {
        $qris_error = 'Minimal deposit Rp ' . number_format($min_deposit,0,',','.');
    } else {
        require_once 'wijayapay_config.php';
        $ref_id = 'TN_' . time() . '_' . $user['id'];
        $response = wijayapay_create_payment($amount, $ref_id, 'QRIS');
        
        if (isset($response['success']) && $response['success'] === true) {
            $qr_image = $response['data']['qr_image'] ?? '';
            $trx_reference = $response['data']['trx_reference'] ?? '';
            $expired = $response['data']['expired'] ?? '';
            $amount_qris = $amount;
            
            $temp_dir = __DIR__ . '/data/temp_payments';
            if (!is_dir($temp_dir)) mkdir($temp_dir, 0777, true);
            $temp_data = [
                'ref_id' => $ref_id,
                'trx_reference' => $trx_reference,
                'user_id' => $user['id'],
                'username' => $user['username'],
                'amount' => $amount,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ];
            file_put_contents($temp_dir . '/' . $ref_id . '.json', json_encode($temp_data, JSON_PRETTY_PRINT));
            $qris_success = 'Transaksi QRIS berhasil dibuat! Scan QRIS untuk bayar.';
        } else {
            $qris_error = 'Gagal: ' . ($response['message'] ?? 'Unknown error');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Deposit QRIS - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --bg-card:rgba(255,255,255,0.03);
            --border:rgba(255,255,255,0.06);
            --text:#ffffff;
            --text-muted:#888888;
            --primary:#00d4ff;
            --gold:#ffd700;
            --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc);
            --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00);
            --radius:16px;
            --shadow:0 8px 32px rgba(0,0,0,0.4);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:var(--bg-card); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:var(--border-gold); }
        .user i { font-size:28px; color:var(--text); }

        .section-title { font-size:16px; font-weight:700; margin:20px 0 12px; display:flex; align-items:center; gap:10px; }
        .section-title i { color:var(--gold); font-size:18px; }

        .wallet-box { background:linear-gradient(135deg,rgba(0,212,255,0.06),rgba(123,47,252,0.06)); border:1px solid rgba(0,212,255,0.12); border-radius:var(--radius); padding:16px 20px; margin:16px 0; display:flex; justify-content:space-between; align-items:center; }
        .wallet-box .label { font-size:12px; color:var(--text-muted); }
        .wallet-box .label i { color:var(--gold); margin-right:6px; }
        .wallet-box .amount { font-size:20px; font-weight:700; color:var(--primary); }

        .form-group { margin-bottom:16px; }
        .form-group label { display:block; font-size:13px; color:var(--text-muted); margin-bottom:6px; font-weight:500; }
        .form-group label i { color:var(--gold); margin-right:6px; }
        .form-group input { width:100%; padding:12px 16px; background:rgba(255,255,255,0.04); border:1px solid var(--border); border-radius:12px; color:var(--text); font-size:15px; }
        .form-group input:focus { outline:none; border-color:var(--primary); }
        .btn-gold { background:var(--gradient-gold); border:none; color:#000; padding:14px; border-radius:12px; font-weight:700; font-size:16px; cursor:pointer; width:100%; transition:0.3s; box-shadow:0 4px 20px rgba(255,215,0,0.2); }
        .btn-gold:hover { box-shadow:0 4px 30px rgba(255,215,0,0.35); transform:translateY(-2px); }
        .btn-gold:active { transform:scale(0.97); }
        .alert { padding:12px 16px; border-radius:12px; margin-bottom:12px; font-size:14px; display:flex; align-items:center; gap:10px; }
        .alert-error { background:rgba(255,82,82,0.12); border:1px solid rgba(255,82,82,0.2); color:#ff5252; }
        .alert-success { background:rgba(0,230,118,0.08); border:1px solid rgba(0,230,118,0.15); color:#00e676; }
        .qris-area { text-align:center; margin-top:20px; }
        .qris-area .qris-img { margin:15px 0; }
        .qris-area .qris-img img { width:250px; height:250px; background:#fff; padding:15px; border-radius:15px; }
        .status { padding:10px; border-radius:10px; margin:15px 0; font-weight:700; }
        .status.pending { background:rgba(255,165,0,0.2); color:#ffaa00; }
        .status.success { background:rgba(0,255,0,0.2); color:#00ff00; }

        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }

        @media (max-width:380px) {
            .wallet-box .amount { font-size:17px; }
            .qris-area .qris-img img { width:200px; height:200px; }
        }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="wallet-box">
        <div><div class="label"><i class="fas fa-coins"></i> Saldo Deposit</div></div>
        <div class="amount" id="saldoDisplay"><?= formatRupiah($user['balance_deposit']) ?></div>
    </div>

    <div class="section-title"><i class="fas fa-qrcode"></i> Deposit QRIS</div>

    <?php if ($qris_error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= $qris_error ?></div>
    <?php endif; ?>
    <?php if ($qris_success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $qris_success ?></div>
    <?php endif; ?>

    <?php if ($qr_image): ?>
        <div class="qris-area">
            <div class="status pending" id="paymentStatus">⏳ Menunggu pembayaran...</div>
            <div class="qris-img">
                <img src="<?= $qr_image ?>" alt="QRIS Code">
            </div>
            <p>💰 Total: <strong>Rp <?= number_format($amount_qris, 0, ',', '.') ?></strong></p>
            <p>🕐 Kadaluarsa: <?= $expired ?></p>
            <p style="font-size:12px;color:var(--text-muted);margin-top:8px;">1. Buka aplikasi bank/e-wallet<br>2. Scan QRIS di atas<br>3. Lakukan pembayaran<br>4. Saldo otomatis bertambah</p>
            <a href="deposit.php" class="btn-gold" style="display:block;text-align:center;text-decoration:none;margin-top:12px;"><i class="fas fa-arrow-left"></i> Kembali</a>
        </div>

        <script>
            const refId = '<?= $ref_id ?>';
            let checkInterval;

            function checkPaymentStatus() {
                fetch('wijayapay_check.php?ref_id=' + refId)
                    .then(r => r.json())
                    .then(data => {
                        if (data.status === 'paid' || data.status === 'success') {
                            document.getElementById('paymentStatus').innerHTML = '✅ PEMBAYARAN BERHASIL! Saldo sudah ditambahkan.';
                            document.getElementById('paymentStatus').className = 'status success';
                            clearInterval(checkInterval);
                            setTimeout(() => { window.location.href = 'deposit.php?success=1'; }, 3000);
                        }
                    })
                    .catch(() => {});
            }

            checkInterval = setInterval(checkPaymentStatus, 5000);
            setTimeout(checkPaymentStatus, 2000);
        </script>
    <?php else: ?>
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-qrcode"></i> Nominal (Min Rp 80.000)</label>
                <input type="number" name="amount" required placeholder="Minimal 80.000" min="80000">
            </div>
            <button type="submit" name="deposit_qris" class="btn-gold"><i class="fas fa-qrcode"></i> Bayar dengan QRIS</button>
        </form>
        <div style="margin-top:12px;background:rgba(0,212,255,0.04);border:1px solid rgba(0,212,255,0.08);border-radius:12px;padding:12px 16px;">
            <p style="font-size:13px;color:var(--text-muted);"><i class="fas fa-bolt" style="color:var(--gold);margin-right:8px;"></i> QRIS instan, saldo masuk otomatis setelah pembayaran.</p>
        </div>
    <?php endif; ?>

    <div class="bottom-nav">
        <a href="home.php"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldo = <?= $user['balance_deposit'] ?>;
function updateSaldo() {
    const el = document.getElementById('saldoDisplay');
    if (el) el.textContent = 'Rp ' + saldo.toLocaleString('id-ID');
}
function fetchSaldo() {
    fetch('api.php?action=saldo').then(r=>r.json()).then(data=>{ if(data.status==='success'){ saldo=data.balance_deposit; updateSaldo(); } }).catch(()=>{});
}
updateSaldo();
setInterval(fetchSaldo, 15000);
</script>
</body>
</html>