// ─── API Config ───────────────────────────────────────────────────────────────
// File ini digunakan oleh chat_page.dart dan story_page.dart
// untuk mendapatkan base URL server.

const String baseUrl = 'http://private-legal.jhonaleystore.id:2705';
