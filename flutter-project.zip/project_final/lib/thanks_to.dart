import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ThanksToPage extends StatefulWidget {
  const ThanksToPage({super.key});

  @override
  State<ThanksToPage> createState() => _ThanksToPageState();
}

class _ThanksToPageState extends State<ThanksToPage>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late AnimationController _floatController;

  final List<Map<String, String>> team = [
    {
      "title": "DEVELOPER",
      "username": "@Zyvarno",
      "desc": "DEVELOPER UTAMA",
      "icon": "👮",
      "tg": "Zyvarno",
    },
    {
      "title": "MY LOVE",
      "username": "@kenapagwe",
      "desc": "My Love Zyvarno",
      "icon": "🤍",
      "tg": "kenapagwe",
    },
    {
      "title": "Team XIXTER",
      "username": "@imFahzzSinji",
      "desc": "Support Zyvarno",
      "icon": "📢",
      "tg": "imFahzzSinji",
    },
    {
      "title": "Team XIXTER",
      "username": "@rikzxNotDev",
      "desc": "Ceo",
      "icon": "👑",
      "tg": "rikzxNotDev",
    },
    {
      "title": "Team XIXTER",
      "username": "@BARZz_REAL01",
      "desc": "My Friend Zyvarno",
      "icon": "✨",
      "tg": "BARZz_REAL01",
    },
    {
      "title": "Team XIXTER",
      "username": "@Bizzxx_Reals01",
      "desc": "Bos Sawit",
      "icon": "💸",
      "tg": "Bizzxx_Reals01",
    },
    {
      "title": "Team XIXTER",
      "username": "@vixzzofc",
      "desc": "Ceo Batu Giox",
      "icon": "💫",
      "tg": "vixzzofc",
    },
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  Future<void> _openTelegram(String username) async {
    final uri = Uri.parse("tg://resolve?domain=$username");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(
        Uri.parse("https://t.me/$username"),
        mode: LaunchMode.externalApplication,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Color(0xFFB0B0B0)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Thanks To",
          style: TextStyle(
            color: Color(0xFFB0B0B0),
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // === HEADER ANIMASI ===
            AnimatedBuilder(
              animation: _floatController,
              builder: (_, __) => Transform.translate(
                offset: Offset(0, -6 * _floatController.value),
                child: AnimatedBuilder(
                  animation: _glowController,
                  builder: (_, __) => Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFF757575).withOpacity(0.12),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFFB0B0B0).withOpacity(
                              0.4 + _glowController.value * 0.4),
                          blurRadius: 40,
                          spreadRadius: 5,
                        )
                      ],
                      border: Border.all(
                        color: Color(0xFFB0B0B0)
                            .withOpacity(0.6 + _glowController.value * 0.4),
                        width: 2,
                      ),
                    ),
                    child: const Center(
                      child: Text("🙏", style: TextStyle(fontSize: 44)),
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            const Text(
              "THANKS TO",
              style: TextStyle(
                color: Color(0xFFB0B0B0),
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 24,
                letterSpacing: 4,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Tim yang membuat ini semua terjadi",
              style: TextStyle(
                color: Colors.white.withOpacity(0.4),
                fontFamily: 'ShareTechMono',
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 36),

            // === TEAM CARDS ===
            ...List.generate(team.length, (i) {
              final member = team[i];
              return TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: Duration(milliseconds: 400 + i * 150),
                curve: Curves.easeOutBack,
                builder: (_, val, child) =>
                    Transform.scale(scale: val, child: child),
                child: _buildMemberCard(member, i),
              );
            }),

            const SizedBox(height: 30),

            // === FOOTER ===
            AnimatedBuilder(
              animation: _glowController,
              builder: (_, __) => Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF424242).withOpacity(0.3),
                      Color(0xFF757575).withOpacity(0.1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: Color(0xFFB0B0B0).withOpacity(
                        0.3 + _glowController.value * 0.3),
                    width: 1,
                  ),
                ),
                child: Column(
                  children: [
                    const Text(
                      "❤️ Terima kasih",
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Kepada semua orang yang telah berkontribusi dalam pengembangan aplikasi ini.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontFamily: 'ShareTechMono',
                        fontSize: 12,
                        height: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildMemberCard(Map<String, String> member, int index) {
    final colors = [
      Color(0xFFB0B0B0),
      Color(0xFF9E9E9E),
      Color(0xFF757575),
    ];
    final color = colors[index % colors.length];

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.12),
            blurRadius: 20,
            spreadRadius: -4,
          )
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            // ICON
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.5)),
              ),
              child: Center(
                child: Text(member["icon"]!,
                    style: const TextStyle(fontSize: 26)),
              ),
            ),

            const SizedBox(width: 16),

            // INFO
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      member["title"]!.toUpperCase(),
                      style: TextStyle(
                        color: color,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    member["username"]!,
                    style: TextStyle(
                      color: color,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    member["desc"]!,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),

            // TELEGRAM BUTTON
            GestureDetector(
              onTap: () => _openTelegram(member["tg"]!),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color.withOpacity(0.4)),
                ),
                child: Icon(Icons.telegram, color: color, size: 22),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _floatController.dispose();
    super.dispose();
  }
}
