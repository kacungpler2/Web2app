import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

// ─── Colors ───────────────────────────────────────────────────────────────────
const Color _cBg     = Color(0xFF0D1117);
const Color _cCard   = Color(0xFF161B22);
const Color _cBorder = Color(0xFF30363D);
const Color _cCyan   = Color(0xFF00E5FF);
const Color _cGreen  = Color(0xFF00E676);
const Color _cWhite  = Colors.white;
const Color _cWhite54= Colors.white54;
const Color _cPurple = Color(0xFF7C4DFF);
const Color _cRed    = Color(0xFFEF4444);
const Color _cBubble = Color(0xFF1C2333);

// ─── Emoji List ───────────────────────────────────────────────────────────────
const List<String> _emojiList = [
  '😀','😂','😍','😎','😭','😡','🥰','😱','🤣','😊',
  '😋','🤔','😴','🤩','🥳','😏','🤗','😇','😤','🤯',
  '👍','👎','👏','🙏','🤝','✌️','💪','🫶','🤞','👌',
  '❤️','🧡','💛','💚','💙','💜','🖤','💔','💯','🔥',
  '🎉','🎊','🎈','🏆','🥇','🎯','💡','⚡','🌈','✨',
  '😅','😆','🤭','🫢','😶','😐','🫠','🫨','🤑','🥴',
];

// ─── Message Model ────────────────────────────────────────────────────────────
class ChatMessage {
  final String msgId;
  final String sender;
  final String content;
  final String type; // 'text', 'image', 'video', 'sticker', 'emoji'
  final String createdAt;
  final bool isRead;

  ChatMessage({
    required this.msgId,
    required this.sender,
    required this.content,
    required this.type,
    required this.createdAt,
    required this.isRead,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
    msgId:     j['msg_id']?.toString() ?? '',
    sender:    j['sender']?.toString() ?? '',
    content:   j['content']?.toString() ?? '',
    type:      j['type']?.toString() ?? 'text',
    createdAt: j['created_at']?.toString() ?? '',
    isRead:    j['is_read'] == true,
  );
}

class ChatContact {
  final String username;
  final String lastMessage;
  final String lastTime;
  final int unreadCount;
  final bool isOnline;

  ChatContact({
    required this.username,
    required this.lastMessage,
    required this.lastTime,
    required this.unreadCount,
    required this.isOnline,
  });

  factory ChatContact.fromJson(Map<String, dynamic> j) => ChatContact(
    username:    j['username']?.toString() ?? '',
    lastMessage: j['last_message']?.toString() ?? '',
    lastTime:    j['last_time']?.toString() ?? '',
    unreadCount: j['unread_count'] ?? 0,
    isOnline:    j['is_online'] == true,
  );
}

// ─── Chat List Page ───────────────────────────────────────────────────────────
class ChatListPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const ChatListPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  List<ChatContact> _contacts = [];
  bool _loading = true;
  String? _error;
  Timer? _pollTimer;
  WebSocketChannel? _ws;
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _fetchContacts();
    _pollTimer = Timer.periodic(const Duration(seconds: 15), (_) => _fetchContacts());
    _connectWebSocket();
  }

  OverlayEntry? _notifOverlay;

  void _showChatNotification(String sender, String preview) {
    _notifOverlay?.remove();
    _notifOverlay = null;

    final entry = OverlayEntry(
      builder: (ctx) => Positioned(
        top: MediaQuery.of(ctx).padding.top + 8,
        left: 16,
        right: 16,
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF161B22),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.4)),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00E5FF).withOpacity(0.15),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.chat_bubble, color: Color(0xFF00E5FF), size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        sender,
                        style: const TextStyle(
                          color: Color(0xFF00E5FF),
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      if (preview.isNotEmpty)
                        Text(
                          preview,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontFamily: 'ShareTechMono',
                            fontSize: 12,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(entry);
    _notifOverlay = entry;

    Future.delayed(const Duration(seconds: 3), () {
      _notifOverlay?.remove();
      _notifOverlay = null;
    });
  }

  void _connectWebSocket() {
    try {
      final wsUrl = baseUrl.replaceFirst('http', 'ws');
      _ws = WebSocketChannel.connect(Uri.parse(wsUrl));
      _ws!.stream.listen((data) {
        try {
          final json = jsonDecode(data);
          // Jika ada pesan masuk baru, refresh daftar kontak
          if (json['type'] == 'new_chat_message' && json['notification'] == true) {
            _fetchContacts();
            // Tampilkan notifikasi overlay di layar atas
            final sender = json['message']?['sender']?.toString() ?? 'Pesan baru';
            final preview = json['message']?['content']?.toString() ?? '';
            if (mounted) _showChatNotification(sender, preview);
          }
        } catch (_) {}
      }, onError: (_) {}, onDone: () {
        // Reconnect setelah 5 detik jika koneksi terputus
        Future.delayed(const Duration(seconds: 5), () {
          if (mounted) _connectWebSocket();
        });
      });
      // Auth ke server
      _ws!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _ws?.sink.close();
    _searchCtrl.dispose();
    _notifOverlay?.remove();
    super.dispose();
  }

  Future<void> _fetchContacts() async {
    try {
      final res = await http.get(
        Uri.parse('http://panel.dynap.xyz:2003/getChatContacts?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final List raw = data['contacts'] ?? [];
          if (mounted) {
            setState(() {
              _contacts = raw.map((e) => ChatContact.fromJson(e)).toList();
              _loading = false;
              _error = null;
            });
          }
        } else {
          if (mounted) setState(() { _error = data['message'] ?? 'Gagal memuat chat'; _loading = false; });
        }
      } else {
        if (mounted) setState(() { _error = 'Server error'; _loading = false; });
      }
    } catch (_) {
      if (mounted) setState(() { _error = 'Koneksi gagal'; _loading = false; });
    }
  }

  void _openChat(String targetUsername) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => ChatRoomPage(
        sessionKey: widget.sessionKey,
        myUsername: widget.username,
        targetUsername: targetUsername,
      ),
    )).then((_) => _fetchContacts());
  }

  void _showNewChatDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: _cBorder)),
        title: const Text('Pesan Baru', style: TextStyle(color: _cWhite, fontFamily: 'ShareTechMono', fontSize: 16)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: const TextStyle(color: _cWhite, fontFamily: 'ShareTechMono'),
          decoration: const InputDecoration(
            hintText: 'Masukkan username...',
            hintStyle: TextStyle(color: _cWhite54),
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: _cBorder)),
            focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: _cCyan)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: _cWhite54))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _cCyan, foregroundColor: _cBg),
            onPressed: () {
              final target = ctrl.text.trim();
              if (target.isEmpty || target == widget.username) return;
              Navigator.pop(context);
              _openChat(target);
            },
            child: const Text('Chat', style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  List<ChatContact> get _filtered {
    if (_searchQuery.isEmpty) return _contacts;
    return _contacts.where((c) => c.username.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _cBg,
      appBar: AppBar(
        backgroundColor: _cBg,
        foregroundColor: _cWhite,
        title: const Text('Chat', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 20, fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(icon: const Icon(Icons.edit_square, color: _cCyan), onPressed: _showNewChatDialog),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              controller: _searchCtrl,
              style: const TextStyle(color: _cWhite, fontFamily: 'ShareTechMono', fontSize: 14),
              onChanged: (v) => setState(() => _searchQuery = v),
              decoration: InputDecoration(
                hintText: 'Cari percakapan...',
                hintStyle: const TextStyle(color: _cWhite54, fontSize: 13),
                prefixIcon: const Icon(Icons.search, color: _cWhite54, size: 20),
                filled: true,
                fillColor: _cCard,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _cBorder)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _cBorder)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _cCyan)),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _cCyan))
                : _error != null
                    ? Center(child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.error_outline, color: _cRed, size: 48),
                          const SizedBox(height: 12),
                          Text(_error!, style: const TextStyle(color: _cWhite54, fontFamily: 'ShareTechMono')),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: _cCyan, foregroundColor: _cBg),
                            onPressed: _fetchContacts,
                            child: const Text('Coba Lagi'),
                          ),
                        ],
                      ))
                    : _filtered.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.chat_bubble_outline, color: _cWhite54, size: 64),
                                const SizedBox(height: 16),
                                const Text('Belum ada percakapan', style: TextStyle(color: _cWhite54, fontFamily: 'ShareTechMono', fontSize: 14)),
                                const SizedBox(height: 8),
                                const Text('Ketuk ikon edit untuk mulai chat', style: TextStyle(color: _cWhite54, fontFamily: 'ShareTechMono', fontSize: 12)),
                                const SizedBox(height: 20),
                                ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(backgroundColor: _cCyan, foregroundColor: _cBg),
                                  onPressed: _showNewChatDialog,
                                  icon: const Icon(Icons.add),
                                  label: const Text('Mulai Chat Baru', style: TextStyle(fontFamily: 'ShareTechMono')),
                                ),
                              ],
                            ),
                          )
                        : RefreshIndicator(
                            color: _cCyan,
                            onRefresh: _fetchContacts,
                            child: ListView.builder(
                              itemCount: _filtered.length,
                              itemBuilder: (_, i) => _buildContactTile(_filtered[i]),
                            ),
                          ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactTile(ChatContact c) {
    return InkWell(
      onTap: () => _openChat(c.username),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Color(0x22FFFFFF))),
        ),
        child: Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: _cPurple.withOpacity(0.3),
                  child: Text(c.username.isNotEmpty ? c.username[0].toUpperCase() : '?',
                    style: const TextStyle(color: _cWhite, fontWeight: FontWeight.bold, fontSize: 18)),
                ),
                if (c.isOnline)
                  Positioned(
                    bottom: 0, right: 0,
                    child: Container(
                      width: 12, height: 12,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: _cGreen,
                        border: Border.all(color: _cBg, width: 2),
                        boxShadow: [BoxShadow(color: _cGreen.withOpacity(0.5), blurRadius: 4)]),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(c.username,
                          style: TextStyle(color: _cWhite, fontWeight: c.unreadCount > 0 ? FontWeight.bold : FontWeight.normal,
                            fontFamily: 'ShareTechMono', fontSize: 14),
                          overflow: TextOverflow.ellipsis),
                      ),
                      Text(c.lastTime, style: TextStyle(color: c.unreadCount > 0 ? _cCyan : _cWhite54, fontSize: 11, fontFamily: 'ShareTechMono')),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Expanded(
                        child: Text(c.lastMessage,
                          style: TextStyle(color: c.unreadCount > 0 ? _cWhite : _cWhite54, fontSize: 12, fontFamily: 'ShareTechMono'),
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      ),
                      if (c.unreadCount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(color: _cCyan, borderRadius: BorderRadius.circular(10)),
                          child: Text('${c.unreadCount}', style: const TextStyle(color: _cBg, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Chat Room Page ───────────────────────────────────────────────────────────
class ChatRoomPage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String targetUsername;

  const ChatRoomPage({
    super.key,
    required this.sessionKey,
    required this.myUsername,
    required this.targetUsername,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  List<ChatMessage> _messages = [];
  bool _loading = true;
  bool _sending = false;
  bool _showEmoji = false;
  Timer? _pollTimer;
  WebSocketChannel? _ws;
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  bool _isOnline = false;

  @override
  void initState() {
    super.initState();
    _fetchMessages();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _fetchMessages(silent: true));
    _connectWebSocket();
  }

  void _connectWebSocket() {
    try {
      final wsUrl = baseUrl.replaceFirst('http', 'ws');
      _ws = WebSocketChannel.connect(Uri.parse(wsUrl));
      _ws!.stream.listen((data) {
        try {
          final json = jsonDecode(data);
          if (json['type'] == 'new_chat_message') {
            final msg = json['message'];
            // Jika pesan relevan dengan room ini
            if (msg != null) {
              final sender = msg['sender']?.toString() ?? '';
              final receiver = msg['receiver']?.toString() ?? '';
              if ((sender == widget.targetUsername && receiver == widget.myUsername) ||
                  (sender == widget.myUsername && receiver == widget.targetUsername)) {
                _fetchMessages(silent: true);
              }
            }
          }
          // Update status online
          if (json['type'] == 'user_online' && json['username'] == widget.targetUsername) {
            if (mounted) setState(() => _isOnline = true);
          }
          if (json['type'] == 'user_offline' && json['username'] == widget.targetUsername) {
            if (mounted) setState(() => _isOnline = false);
          }
        } catch (_) {}
      }, onError: (_) {}, onDone: () {
        Future.delayed(const Duration(seconds: 5), () {
          if (mounted) _connectWebSocket();
        });
      });
      // Auth ke server
      _ws!.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _ws?.sink.close();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchMessages({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    try {
      final res = await http.get(
        Uri.parse('http://panel.dynap.xyz:2003/getChatMessages?key=${widget.sessionKey}&with=${widget.targetUsername}'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final List raw = data['messages'] ?? [];
          final msgs = raw.map((e) => ChatMessage.fromJson(e)).toList();
          if (mounted) {
            setState(() {
              _messages = msgs;
              if (!silent) _isOnline = data['is_online'] == true;
              _loading = false;
            });
            if (msgs.isNotEmpty) _scrollToBottom();
          }
        } else {
          if (mounted) setState(() => _loading = false);
        }
      } else {
        if (mounted) setState(() => _loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _sendText() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _sending) return;
    _msgCtrl.clear();
    setState(() { _sending = true; _showEmoji = false; });

    try {
      final res = await http.post(
        Uri.parse('http://panel.dynap.xyz:2003/sendChatMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'to': widget.targetUsername,
          'content': text,
          'type': 'text',
        }),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        await _fetchMessages(silent: true);
      } else {
        _showSnack(data['message'] ?? 'Gagal mengirim');
      }
    } catch (_) {
      _showSnack('Gagal mengirim pesan');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _sendEmoji(String emoji) async {
    if (_sending) return;
    setState(() { _sending = true; _showEmoji = false; });

    try {
      final res = await http.post(
        Uri.parse('http://panel.dynap.xyz:2003/sendChatEmoji'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'to': widget.targetUsername,
          'emoji': emoji,
        }),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        await _fetchMessages(silent: true);
      } else {
        _showSnack(data['message'] ?? 'Gagal kirim emoji');
      }
    } catch (_) {
      _showSnack('Gagal mengirim emoji');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null) return;

    setState(() => _sending = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('http://panel.dynap.xyz:2003/sendChatImage'));
      req.fields['key'] = widget.sessionKey;
      req.fields['to']  = widget.targetUsername;
      req.files.add(await http.MultipartFile.fromPath('image', picked.path));
      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final res = await http.Response.fromStream(streamed);
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        await _fetchMessages(silent: true);
      } else {
        _showSnack(data['message'] ?? 'Gagal kirim gambar');
      }
    } catch (_) {
      _showSnack('Gagal mengirim gambar');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _sendVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    if (file.path == null) return;

    // Cek ukuran file (max 50MB)
    final fileSize = File(file.path!).lengthSync();
    if (fileSize > 50 * 1024 * 1024) {
      _showSnack('Video terlalu besar (maks 50MB)');
      return;
    }

    setState(() => _sending = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('http://panel.dynap.xyz:2003/sendChatVideo'));
      req.fields['key'] = widget.sessionKey;
      req.fields['to']  = widget.targetUsername;
      req.files.add(await http.MultipartFile.fromPath('video', file.path!));
      final streamed = await req.send().timeout(const Duration(seconds: 120));
      final res = await http.Response.fromStream(streamed);
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        await _fetchMessages(silent: true);
      } else {
        _showSnack(data['message'] ?? 'Gagal kirim video');
      }
    } catch (_) {
      _showSnack('Gagal mengirim video');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _deleteMessage(String msgId) async {
    try {
      final res = await http.post(
        Uri.parse('http://panel.dynap.xyz:2003/deleteChatMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'msg_id': msgId}),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _fetchMessages(silent: true);
      }
    } catch (_) {}
  }

  void _showAttachMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _cCard,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: _cBorder, borderRadius: BorderRadius.circular(2))),
            const Text('Kirim Media', style: TextStyle(color: _cWhite, fontFamily: 'ShareTechMono', fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _attachBtn(Icons.image_rounded, 'Foto', _cCyan, () {
                  Navigator.pop(context);
                  _sendImage();
                }),
                _attachBtn(Icons.videocam_rounded, 'Video', _cPurple, () {
                  Navigator.pop(context);
                  _sendVideo();
                }),
                _attachBtn(Icons.camera_alt_rounded, 'Kamera', _cGreen, () {
                  Navigator.pop(context);
                  _sendImageFromCamera();
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _sendImageFromCamera() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.camera, imageQuality: 80);
    if (picked == null) return;

    setState(() => _sending = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('http://panel.dynap.xyz:2003/sendChatImage'));
      req.fields['key'] = widget.sessionKey;
      req.fields['to']  = widget.targetUsername;
      req.files.add(await http.MultipartFile.fromPath('image', picked.path));
      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final res = await http.Response.fromStream(streamed);
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        await _fetchMessages(silent: true);
      } else {
        _showSnack(data['message'] ?? 'Gagal kirim foto');
      }
    } catch (_) {
      _showSnack('Gagal mengirim foto');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Widget _attachBtn(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: color.withOpacity(0.4)),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(color: color, fontFamily: 'ShareTechMono', fontSize: 12)),
        ],
      ),
    );
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
        backgroundColor: _cRed.withOpacity(0.85),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _cBg,
      appBar: AppBar(
        backgroundColor: _cBg,
        foregroundColor: _cWhite,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _cCyan),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: _cPurple.withOpacity(0.3),
                  child: Text(
                    widget.targetUsername.isNotEmpty ? widget.targetUsername[0].toUpperCase() : '?',
                    style: const TextStyle(color: _cWhite, fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
                if (_isOnline)
                  Positioned(
                    bottom: 0, right: 0,
                    child: Container(
                      width: 10, height: 10,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: _cGreen,
                        border: Border.all(color: _cBg, width: 1.5)),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.targetUsername, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 15, fontWeight: FontWeight.bold)),
                Text(_isOnline ? 'Online' : 'Offline', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _isOnline ? _cGreen : _cWhite54)),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _cCyan))
                : _messages.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.chat_bubble_outline, color: _cWhite54, size: 56),
                            SizedBox(height: 12),
                            Text('Mulai percakapan...', style: TextStyle(color: _cWhite54, fontFamily: 'ShareTechMono', fontSize: 13)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollCtrl,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        itemCount: _messages.length,
                        itemBuilder: (_, i) => _buildBubble(_messages[i]),
                      ),
          ),
          // Emoji Panel
          if (_showEmoji) _buildEmojiPanel(),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildEmojiPanel() {
    return Container(
      height: 220,
      decoration: const BoxDecoration(
        color: _cCard,
        border: Border(top: BorderSide(color: _cBorder)),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(
              children: [
                const Text('Emoji', style: TextStyle(color: _cWhite54, fontFamily: 'ShareTechMono', fontSize: 12)),
                const Spacer(),
                GestureDetector(
                  onTap: () => setState(() => _showEmoji = false),
                  child: const Icon(Icons.keyboard_arrow_down, color: _cWhite54, size: 20),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 10,
                childAspectRatio: 1,
              ),
              itemCount: _emojiList.length,
              itemBuilder: (_, i) => GestureDetector(
                onTap: () => _sendEmoji(_emojiList[i]),
                child: Center(
                  child: Text(_emojiList[i], style: const TextStyle(fontSize: 22)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBubble(ChatMessage msg) {
    final isMe = msg.sender == widget.myUsername;
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: isMe ? () => _showMessageOptions(msg) : null,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          decoration: msg.type == 'emoji'
              ? null // emoji tidak pakai bubble
              : BoxDecoration(
                  color: isMe ? _cCyan.withOpacity(0.15) : _cBubble,
                  borderRadius: BorderRadius.only(
                    topLeft:     const Radius.circular(16),
                    topRight:    const Radius.circular(16),
                    bottomLeft:  Radius.circular(isMe ? 16 : 4),
                    bottomRight: Radius.circular(isMe ? 4 : 16),
                  ),
                  border: Border.all(color: isMe ? _cCyan.withOpacity(0.3) : _cBorder),
                ),
          padding: msg.type == 'emoji'
              ? const EdgeInsets.symmetric(horizontal: 4, vertical: 2)
              : const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Column(
            crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              _buildMessageContent(msg),
              if (msg.type != 'emoji') ...[
                const SizedBox(height: 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(msg.createdAt, style: const TextStyle(color: _cWhite54, fontSize: 10, fontFamily: 'ShareTechMono')),
                    if (isMe) ...[
                      const SizedBox(width: 4),
                      Icon(msg.isRead ? Icons.done_all : Icons.done, size: 13,
                        color: msg.isRead ? _cCyan : _cWhite54),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMessageContent(ChatMessage msg) {
    switch (msg.type) {
      case 'image':
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.network(
            msg.content,
            fit: BoxFit.cover,
            width: 200,
            loadingBuilder: (_, child, progress) => progress == null
                ? child
                : Container(width: 200, height: 120, color: _cBorder,
                    child: const Center(child: CircularProgressIndicator(color: _cCyan, strokeWidth: 2))),
            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: _cWhite54, size: 40),
          ),
        );

      case 'video':
        return _VideoMessageWidget(url: msg.content);

      case 'sticker':
        return Image.network(
          msg.content,
          width: 120, height: 120,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: _cWhite54, size: 60),
        );

      case 'emoji':
        return Text(msg.content, style: const TextStyle(fontSize: 36));

      default:
        return Text(msg.content, style: const TextStyle(color: _cWhite, fontFamily: 'ShareTechMono', fontSize: 14));
    }
  }

  void _showMessageOptions(ChatMessage msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _cCard,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (msg.type == 'text')
              ListTile(
                leading: const Icon(Icons.copy, color: _cCyan),
                title: const Text('Salin', style: TextStyle(color: _cWhite, fontFamily: 'ShareTechMono')),
                onTap: () {
                  Navigator.pop(context);
                  Clipboard.setData(ClipboardData(text: msg.content));
                },
              ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: _cRed),
              title: const Text('Hapus Pesan', style: TextStyle(color: _cRed, fontFamily: 'ShareTechMono')),
              onTap: () {
                Navigator.pop(context);
                _deleteMessage(msg.msgId);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(8, 8, 8, MediaQuery.of(context).padding.bottom + 8),
      decoration: const BoxDecoration(
        color: _cCard,
        border: Border(top: BorderSide(color: _cBorder)),
      ),
      child: Row(
        children: [
          // Lampiran (foto, video, kamera)
          IconButton(
            icon: const Icon(Icons.add_circle_outline, color: _cCyan, size: 26),
            onPressed: _sending ? null : _showAttachMenu,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 36, minHeight: 40),
          ),
          // Emoji
          IconButton(
            icon: Icon(Icons.emoji_emotions_outlined,
              color: _showEmoji ? _cCyan : _cWhite54, size: 24),
            onPressed: () => setState(() => _showEmoji = !_showEmoji),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 36, minHeight: 40),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(color: _cWhite, fontFamily: 'ShareTechMono', fontSize: 14),
              maxLines: 4,
              minLines: 1,
              textInputAction: TextInputAction.newline,
              onTap: () { if (_showEmoji) setState(() => _showEmoji = false); },
              decoration: InputDecoration(
                hintText: 'Ketik pesan...',
                hintStyle: const TextStyle(color: _cWhite54, fontSize: 13),
                filled: true,
                fillColor: _cBg,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: _cBorder)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: _cBorder)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: _cCyan)),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _sending ? null : _sendText,
            child: Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _cCyan,
                boxShadow: [BoxShadow(color: _cCyan.withOpacity(0.35), blurRadius: 8)],
              ),
              child: _sending
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: CircularProgressIndicator(color: _cBg, strokeWidth: 2),
                    )
                  : const Icon(Icons.send_rounded, color: _cBg, size: 20),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Video Message Widget ─────────────────────────────────────────────────────
class _VideoMessageWidget extends StatefulWidget {
  final String url;
  const _VideoMessageWidget({required this.url});

  @override
  State<_VideoMessageWidget> createState() => _VideoMessageWidgetState();
}

class _VideoMessageWidgetState extends State<_VideoMessageWidget> {
  late VideoPlayerController _ctrl;
  bool _initialized = false;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) setState(() => _initialized = true);
      }).catchError((_) {
        if (mounted) setState(() => _error = true);
      });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error) {
      return Container(
        width: 200, height: 120,
        decoration: BoxDecoration(color: _cBorder, borderRadius: BorderRadius.circular(10)),
        child: const Center(child: Icon(Icons.videocam_off, color: _cWhite54, size: 36)),
      );
    }
    if (!_initialized) {
      return Container(
        width: 200, height: 120,
        decoration: BoxDecoration(color: _cBorder, borderRadius: BorderRadius.circular(10)),
        child: const Center(child: CircularProgressIndicator(color: _cCyan, strokeWidth: 2)),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: SizedBox(
        width: 200,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AspectRatio(
              aspectRatio: _ctrl.value.aspectRatio,
              child: VideoPlayer(_ctrl),
            ),
            GestureDetector(
              onTap: () => setState(() {
                _ctrl.value.isPlaying ? _ctrl.pause() : _ctrl.play();
              }),
              child: Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black54,
                ),
                child: Icon(
                  _ctrl.value.isPlaying ? Icons.pause : Icons.play_arrow,
                  color: Colors.white, size: 28,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
