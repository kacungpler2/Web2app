// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;

import 'music_service.dart';
import 'admin_page.dart';
import 'api_config.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'thanks_to.dart';
import 'chat_page.dart';
import 'story_page.dart';

class LoaderPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const LoaderPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<LoaderPage> createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;
  late Timer _statsRefreshTimer;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;
  bool isStatsLive = false;

  Map<String, String> jadwalSholat = {};
  bool isLoadingJadwal = false;
  String nextSholat = "";
  String nextSholatTime = "";

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _startStatsRefresh();
    _fetchJadwalSholat();

    // 🎵 Mulai musik background secara otomatis & loop — tersembunyi dari UI
    MusicService.instance.play();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws.panel-legal.jhonaley.net:3429'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }

      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 1;
          activeConnections = data['activeConnections'] ?? 1;
          isStatsLive = true;
        });
      }
    });
  }

  Future<void> _fetchJadwalSholat() async {
    setState(() => isLoadingJadwal = true);

    final now = DateTime.now();
    final url = Uri.parse(
      "https://api.myquran.com/v2/sholat/jadwal/1301/${now.year}/${now.month}/${now.day}",
    );

    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final jadwalApi = data["data"]["jadwal"];

        setState(() {
          jadwalSholat = {
            "Subuh": jadwalApi["subuh"],
            "Dzuhur": jadwalApi["dzuhur"],
            "Ashar": jadwalApi["ashar"],
            "Maghrib": jadwalApi["maghrib"],
            "Isya": jadwalApi["isya"],
          };
          _calculateNextSholat();
        });
      }
    } catch (e) {
      print("Error fetching prayer times: $e");
    }
    setState(() => isLoadingJadwal = false);
  }

  void _calculateNextSholat() {
    if (jadwalSholat.isEmpty) return;

    final now = DateTime.now();
    final currentTime = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

    List<MapEntry<String, String>> sortedJadwal = jadwalSholat.entries.toList();

    for (var prayer in sortedJadwal) {
      if (prayer.value.compareTo(currentTime) > 0) {
        setState(() {
          nextSholat = prayer.key;
          nextSholatTime = prayer.value;
        });
        return;
      }
    }

    setState(() {
      nextSholat = "Subuh";
      nextSholatTime = jadwalSholat["Subuh"] ?? "05:00";
    });
  }

  void _startStatsRefresh() {
    _statsRefreshTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (channel.sink != null) {
        try {
          channel.sink.add(jsonEncode({"type": "stats"}));
        } catch (e) {
          print("Error requesting stats: $e");
        }
      }
      _calculateNextSholat();
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text("Session Expired", style: TextStyle(color: Color(0xFFBDBDBD), fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Color(0xFFBDBDBD))),
          ),
        ],
      ),
    );
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();

      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = ChatListPage(
          sessionKey: sessionKey,
          username: username,
        );
      } else if (index == 3) {
        _selectedPage = StoryPage(
          sessionKey: sessionKey,
          username: username,
        );
      }
    });
  }

  void _selectFromDrawer(String page) {
    Navigator.pop(context);
    setState(() {
      if (page == 'reseller') {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (page == 'admin') {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      }
    });
  }

  Widget _buildJadwalSholatCompact() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color(0xFF1A1A1A), const Color(0xFF2E2E2E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
            ),
          ),
          child: Row(
            children: [
              const Icon(Icons.mosque, color: Color(0xFFBDBDBD), size: 22),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "JADWAL SHOLAT",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Orbitron",
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      "Jakarta • ${DateTime.now().toString().split(' ')[0]}",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: 10,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade900.withOpacity(0.5),
            border: Border(
              bottom: BorderSide(color: Colors.grey.shade700.withOpacity(0.3), width: 1),
              left: BorderSide(color: Colors.grey.shade800.withOpacity(0.4), width: 1),
              right: BorderSide(color: Colors.grey.shade800.withOpacity(0.4), width: 1),
            ),
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(16),
              bottomRight: Radius.circular(16),
            ),
          ),
          padding: const EdgeInsets.all(12),
          child: isLoadingJadwal
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: SizedBox(
                    height: 36,
                    width: 36,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFBDBDBD)),
                      strokeWidth: 2,
                    ),
                  ),
                )
              : Column(
                  children: [
                    if (nextSholat.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.amber.shade700, Colors.orange.shade600],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.amber.withOpacity(0.3),
                              blurRadius: 8,
                              spreadRadius: 0,
                            )
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(Icons.access_time_filled, color: Colors.white, size: 16),
                                ),
                                const SizedBox(width: 10),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text("BERIKUTNYA", style: TextStyle(color: Colors.white70, fontSize: 9, fontFamily: "Orbitron", fontWeight: FontWeight.bold, letterSpacing: 1)),
                                    const SizedBox(height: 2),
                                    Text(nextSholat, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                                  ],
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.white.withOpacity(0.2), width: 1),
                              ),
                              child: Text(nextSholatTime, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: "ShareTechMono")),
                            ),
                          ],
                        ),
                      ),
                    Row(
                      children: jadwalSholat.entries.map((entry) {
                        final isNext = entry.key == nextSholat;
                        return Expanded(child: _buildPrayerCardFlat(entry.key, entry.value, isNext));
                      }).toList(),
                    ),
                  ],
                ),
        ),
      ],
    );
  }

  Widget _buildPrayerCardFlat(String name, String time, bool isNext) {
    final prayerIcons = {
      "Subuh": Icons.nights_stay,
      "Dzuhur": Icons.wb_sunny,
      "Ashar": Icons.wb_cloudy,
      "Maghrib": Icons.wb_twilight,
      "Isya": Icons.star,
    };

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 3),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
      decoration: BoxDecoration(
        color: isNext ? Colors.grey.shade800.withOpacity(0.4) : Colors.transparent,
        border: Border.all(
          color: isNext ? Colors.grey.shade500.withOpacity(0.5) : Colors.white.withOpacity(0.08),
          width: isNext ? 1.5 : 1,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(prayerIcons[name] ?? Icons.access_time, color: isNext ? const Color(0xFFBDBDBD) : Colors.white.withOpacity(0.5), size: 18),
          const SizedBox(height: 6),
          Text(name, textAlign: TextAlign.center, style: TextStyle(color: isNext ? Colors.white : Colors.white.withOpacity(0.6), fontSize: 9, fontWeight: FontWeight.bold, fontFamily: "Orbitron", letterSpacing: 0.3)),
          const SizedBox(height: 4),
          Text(time, textAlign: TextAlign.center, style: TextStyle(color: isNext ? const Color(0xFFBDBDBD) : Colors.white.withOpacity(0.5), fontSize: 11, fontWeight: FontWeight.bold, fontFamily: "ShareTechMono")),
          if (isNext)
            Container(
              margin: const EdgeInsets.only(top: 4),
              width: 4,
              height: 4,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.amber.shade500),
            ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required List<Color> gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: gradient[0].withOpacity(0.4), blurRadius: 12, spreadRadius: 0)],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 32),
            const SizedBox(height: 8),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
            const SizedBox(height: 4),
            Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 9, fontFamily: "ShareTechMono")),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 220,
            child: PageView.builder(
              controller: PageController(viewportFraction: 0.9),
              itemCount: newsList.length,
              itemBuilder: (context, index) {
                final item = newsList[index];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(colors: [const Color(0xFF212121), Colors.black], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    boxShadow: [BoxShadow(color: Colors.grey.shade800.withOpacity(0.4), blurRadius: 12, spreadRadius: -2)],
                  ),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Opacity(
                            opacity: 0.2,
                            child: Image.network(item['image'] ?? 'https://via.placeholder.com/400', fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFF212121))),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(color: const Color(0xFF555555), borderRadius: BorderRadius.circular(8)),
                              child: Text(item['category'] ?? 'NEWS', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item['title'] ?? 'No Title', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                                const SizedBox(height: 8),
                                Text(item['description'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12, fontFamily: "ShareTechMono")),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          Container(margin: const EdgeInsets.symmetric(horizontal: 12), child: _buildJadwalSholatCompact()),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFFBDBDBD), Color(0xFF1A1A1A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.bolt, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    const Text("Quick Actions", style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade700.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFBDBDBD), width: 0.5),
                      ),
                      child: const Text("5 Features", style: TextStyle(color: Color(0xFFBDBDBD), fontSize: 10, fontFamily: "ShareTechMono")),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 110,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: SizedBox(
                          width: 130,
                          child: _buildQuickActionCard(
                            icon: Icons.call_missed,
                            title: "Bug WhatsApp",
                            subtitle: "WhatsApp",
                            gradient: [Colors.green.shade700, Colors.greenAccent],
                            onTap: () {
                              setState(() {
                                _selectedIndex = 1;
                                _selectedPage = HomePage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
                              });
                            },
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: SizedBox(
                          width: 130,
                          child: _buildQuickActionCard(
                            icon: Icons.favorite_rounded,
                            title: "Credits",
                            subtitle: "Thanks",
                            gradient: [Colors.pink.shade700, Colors.pinkAccent],
                            onTap: () { Navigator.push(context, MaterialPageRoute(builder: (_) => const ThanksToPage())); },
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: SizedBox(
                          width: 130,
                          child: _buildQuickActionCard(
                            icon: Icons.bug_report,
                            title: "Manager Sender",
                            subtitle: "Sender",
                            gradient: [const Color(0xFF2E2E2E), const Color(0xFFBDBDBD)],
                            onTap: () { Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))); },
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: SizedBox(
                          width: 130,
                          child: _buildQuickActionCard(
                            icon: Icons.chat_bubble_rounded,
                            title: "Chat",
                            subtitle: "Pesan Langsung",
                            gradient: [Color(0xFF006994), Color(0xFF00E5FF)],
                            onTap: () {
                              setState(() {
                                _selectedIndex = 2;
                                _controller.reset();
                                _controller.forward();
                                _selectedPage = ChatListPage(sessionKey: sessionKey, username: username);
                              });
                            },
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: SizedBox(
                          width: 130,
                          child: _buildQuickActionCard(
                            icon: Icons.auto_stories_rounded,
                            title: "Story",
                            subtitle: "Lihat Cerita",
                            gradient: [const Color(0xFF2A2A2A), const Color(0xFF555555)],
                            onTap: () {
                              setState(() {
                                _selectedIndex = 3;
                                _controller.reset();
                                _controller.forward();
                                _selectedPage = StoryPage(sessionKey: sessionKey, username: username);
                              });
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () async {
                final uri = Uri.parse("tg://resolve?domain=informasiapkcrash_light");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/informasiapkcrash_light"), mode: LaunchMode.externalApplication);
                }
              },
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Color(0xFF2E2E2E)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.group_add_rounded, color: Colors.white, size: 36),
                    SizedBox(width: 12),
                    Expanded(child: Text("Telegram Channel: Join To Get More Info!", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                    Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 16),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          _buildStatsSection(),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildStatsSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [const Color(0xFF1A1A1A), Colors.black], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade600.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: Colors.grey.shade800.withOpacity(0.3), blurRadius: 12, spreadRadius: 0)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("REAL-TIME STATS", style: TextStyle(color: Color(0xFFBDBDBD), fontSize: 14, fontWeight: FontWeight.bold, fontFamily: "Orbitron", letterSpacing: 1.2)),
          const SizedBox(height: 12),
          Table(
            columnWidths: const {0: FlexColumnWidth(), 1: FlexColumnWidth()},
            children: [
              _buildTableRow("Online Users", "$onlineUsers", Colors.greenAccent),
              _buildTableRow("Active Connections", "$activeConnections", Colors.cyanAccent),
              _buildTableRow("Status", isStatsLive ? "LIVE" : "CONNECTING", isStatsLive ? Colors.greenAccent : Colors.orangeAccent),
            ],
          ),
        ],
      ),
    );
  }

  TableRow _buildTableRow(String label, String value, Color valueColor) {
    return TableRow(
      children: [
        Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 14))),
        Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(value, textAlign: TextAlign.right, style: TextStyle(color: valueColor, fontFamily: "ShareTechMono", fontWeight: FontWeight.bold, fontSize: 14))),
      ],
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.black87,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Account Info", style: TextStyle(color: Color(0xFFBDBDBD), fontSize: 20, fontFamily: "Orbitron")),
            const SizedBox(height: 12),
            _infoCard(Icons.person, "Username", username),
            _infoCard(Icons.date_range, "Expired", expiredDate),
            _infoCard(Icons.security, "Role", role),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.lock_reset),
              label: const Text("Change Password"),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2E2E2E), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey)));
              },
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              icon: const Icon(Icons.logout),
              label: const Text("Logout"),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2E2E2E), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Card(
      color: Colors.white.withOpacity(0.05),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFFBDBDBD)),
            const SizedBox(width: 10),
            Text("$label:", style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
            const Spacer(),
            Text(value, style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono")),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("XIXTER", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        backgroundColor: Colors.black,
        elevation: 6,
        shadowColor: const Color(0xFF424242).withOpacity(0.6),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle, color: Color(0xFFBDBDBD)),
            onPressed: _showAccountMenu,
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: Colors.black,
        child: ListView(
          padding: const EdgeInsets.all(0),
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFF1A1A1A), Color(0xFF2E2E2E)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("XIXTER", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 5),
                  Text("User: $username", style: const TextStyle(color: Colors.white70)),
                  Text("Role: $role", style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.favorite_rounded, color: Color(0xFFBDBDBD)),
              title: const Text("Thanks To", style: TextStyle(color: Colors.white70)),
              onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => const ThanksToPage())); },
            ),
            if (role == "reseller" || role == "owner")
              ListTile(
                leading: const Icon(Icons.person_add, color: Color(0xFFBDBDBD)),
                title: const Text("Reseller Page", style: TextStyle(color: Colors.white70)),
                onTap: () => _selectFromDrawer('reseller'),
              ),
            if (role == "owner")
              ListTile(
                leading: const Icon(Icons.admin_panel_settings, color: Color(0xFFBDBDBD)),
                title: const Text("Admin Page", style: TextStyle(color: Colors.white70)),
                onTap: () => _selectFromDrawer('admin'),
              ),
          ],
        ),
      ),
      body: FadeTransition(opacity: _animation, child: _selectedPage),
      bottomNavigationBar: Stack(
        children: [
          BottomNavigationBar(
            backgroundColor: Colors.black,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white54,
            type: BottomNavigationBarType.fixed,
            currentIndex: _selectedIndex,
            onTap: _onTabSelected,
            items: [
              const BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
              // ✅ FIXED: Menggunakan FaIcon agar WhatsApp icon tampil benar
              BottomNavigationBarItem(
                icon: FaIcon(
                  FontAwesomeIcons.whatsapp,
                  color: _selectedIndex == 1 ? const Color(0xFF25D366) : Colors.white54,
                  size: 24,
                ),
                label: "Whatsapp",
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.chat_bubble_rounded,
                  color: _selectedIndex == 2 ? const Color(0xFF00E5FF) : Colors.white54,
                  size: 24,
                ),
                label: "Chat",
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.auto_stories_rounded,
                  color: _selectedIndex == 3 ? const Color(0xFFE040FB) : Colors.white54,
                  size: 24,
                ),
                label: "Story",
              ),
            ],
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: Center(
                child: Text(
                  username,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white.withOpacity(0.05)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _statsRefreshTimer.cancel();
    super.dispose();
  }
}
