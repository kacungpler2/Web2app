import 'package:audioplayers/audioplayers.dart';

/// Singleton service untuk background music.
/// Music akan terus berjalan meskipun berpindah halaman.
class MusicService {
  MusicService._internal();
  static final MusicService _instance = MusicService._internal();
  static MusicService get instance => _instance;

  final AudioPlayer _player = AudioPlayer();
  bool _isPlaying = false;

  /// Mulai putar musik background dengan loop otomatis.
  /// Aman dipanggil berkali-kali — tidak akan restart jika sudah berjalan.
  Future<void> play() async {
    if (_isPlaying) return;
    await _player.setReleaseMode(ReleaseMode.loop);
    await _player.play(AssetSource('audio/background_music.mp3'));
    _isPlaying = true;
  }

  /// Hentikan musik (opsional, bisa dipanggil jika perlu).
  Future<void> stop() async {
    await _player.stop();
    _isPlaying = false;
  }

  bool get isPlaying => _isPlaying;
}
