<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Profit otomatis
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        foreach ($u['active_products'] as &$p) {
            if ($p['status'] == 'active') {
                $last = strtotime($p['last_profit'] ?? $p['bought_at']);
                $now = time();
                $interval = 3600;
                $bought = strtotime($p['bought_at']);
                $expired = $bought + ($p['duration_days'] * 86400);
                if ($now > $expired) {
                    $p['status'] = 'expired';
                    continue;
                }
                if ($now - $last >= $interval && $p['profit_count'] < $p['total_profit_count']) {
                    $p['profit_count']++;
                    $u['balance_withdraw'] += $p['profit_per_hour'];
                    $u['total_profit'] += $p['profit_per_hour'];
                    $p['last_profit'] = date('Y-m-d H:i:s');
                    $db['transactions']['profits'][] = [
                        'id' => 'PRF' . date('Ymd') . rand(100, 999),
                        'user_id' => $u['id'],
                        'username' => $u['username'],
                        'product_id' => $p['product_id'],
                        'product_name' => $p['name'],
                        'amount' => $p['profit_per_hour'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        $_SESSION['user'] = $u;
        break;
    }
}
file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

$buy_error = '';
$buy_success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_product'])) {
    $product_id = $_POST['product_id'];
    $product = null;
    foreach ($db['products'] as $p) {
        if ($p['id'] == $product_id && $p['status'] == 'active') {
            $product = $p;
            break;
        }
    }
    if (!$product) {
        $buy_error = 'Produk tidak ditemukan!';
    } else {
        $count = 0;
        foreach ($user['active_products'] as $p) {
            if ($p['product_id'] == $product_id && $p['status'] == 'active') $count++;
        }
        if ($count >= $product['max_buy']) {
            $buy_error = 'Maksimal pembelian ' . $product['max_buy'] . 'x!';
        } elseif ($user['balance_deposit'] < $product['price']) {
            $buy_error = 'Saldo deposit tidak cukup! Butuh ' . formatRupiah($product['price']);
        } else {
            foreach ($db['users'] as &$u) {
                if ($u['id'] == $user['id']) {
                    $u['balance_deposit'] -= $product['price'];
                    $u['active_products'][] = [
                        'product_id' => $product['id'],
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'profit_per_hour' => $product['profit_per_hour'],
                        'duration_days' => $product['duration_days'],
                        'total_profit' => $product['total_profit'],
                        'total_profit_count' => $product['duration_days'] * 24,
                        'profit_count' => 0,
                        'last_profit' => date('Y-m-d H:i:s'),
                        'bought_at' => date('Y-m-d H:i:s'),
                        'status' => 'active'
                    ];
                    $u['product_history'][] = [
                        'product_id' => $product['id'],
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'bought_at' => date('Y-m-d H:i:s')
                    ];
                    $user = $u;
                    $_SESSION['user'] = $u;
                    break;
                }
            }
            file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
            $buy_success = 'Berhasil membeli ' . $product['name'] . '!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Produk - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --bg-card:rgba(255,255,255,0.04);
            --bg-card-hover:rgba(255,255,255,0.07);
            --border:rgba(255,255,255,0.06);
            --border-gold:rgba(255,215,0,0.15);
            --text:#ffffff;
            --text-muted:#888888;
            --primary:#00d4ff;
            --gold:#ffd700;
            --success:#00e676;
            --danger:#ff5252;
            --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc);
            --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00);
            --radius:14px;
            --shadow:0 8px 32px rgba(0,0,0,0.4);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:var(--bg-card); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:var(--border-gold); }
        .user i { font-size:28px; color:var(--text); }

        .section-title { font-size:16px; font-weight:700; margin:16px 0 10px; display:flex; align-items:center; gap:10px; }
        .section-title i { color:var(--gold); font-size:18px; }

        .sub-header { padding:8px 0; }
        .sub-header .title { font-size:13px; font-weight:600; color:var(--gold); }
        .sub-header .desc { font-size:11px; color:var(--text-muted); margin-top:2px; }

        .naga-habis { display:flex; justify-content:space-between; align-items:center; padding:8px 0 12px; border-bottom:1px solid var(--border); }
        .naga-habis .label { font-size:13px; font-weight:600; color:var(--text-muted); }
        .naga-habis .badge { font-size:11px; font-weight:700; color:var(--danger); background:rgba(255,82,82,0.15); padding:4px 14px; border-radius:20px; border:1px solid rgba(255,82,82,0.2); }

        .product-card {
            background:var(--bg-card);
            border-radius:var(--radius);
            padding:14px 16px;
            margin-bottom:12px;
            transition:0.3s;
            border:1px solid var(--border);
        }
        .product-card:hover {
            border-color:var(--border-gold);
            transform:translateY(-2px);
            background:var(--bg-card-hover);
        }
        .product-card .top-row {
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            margin-bottom:6px;
        }
        .product-card .top-row .left { display:flex; flex-direction:column; gap:2px; }
        .product-card .top-row .left .name { font-size:15px; font-weight:700; }
        .product-card .top-row .left .name i { color:var(--gold); margin-right:6px; }
        .product-card .top-row .left .status { font-size:9px; font-weight:600; padding:2px 12px; border-radius:12px; display:inline-block; width:fit-content; }
        .product-card .top-row .left .status.active { background:rgba(0,230,118,0.12); color:var(--success); }
        .product-card .top-row .left .status.offline { background:rgba(255,82,82,0.12); color:var(--danger); }
        .product-card .top-row .badge { font-size:8px; font-weight:700; padding:2px 10px; border-radius:12px; text-transform:uppercase; }
        .product-card .top-row .badge.new { background:var(--danger); color:#fff; }
        .product-card .top-row .badge.popular { background:var(--gold); color:#000; }
        .product-card .top-row .badge.premium { background:linear-gradient(135deg,#ffd700,#f59f00); color:#000; }
        .product-card .top-row .badge.legend { background:linear-gradient(135deg,#00d4ff,#7b2ffc); color:#fff; }
        .product-card .top-row .badge.mythic { background:linear-gradient(135deg,#9b59b6,#8e44ad); color:#fff; }
        .product-card .top-row .badge.ultimate { background:linear-gradient(135deg,#ff4500,#c92a2a); color:#fff; }

        .product-card .detail-grid {
            display:grid;
            grid-template-columns:1fr 1fr 1fr;
            gap:6px;
            padding:8px 0;
            border-top:1px solid var(--border);
            border-bottom:1px solid var(--border);
            margin:6px 0 8px;
        }
        .product-card .detail-grid .item { text-align:center; }
        .product-card .detail-grid .item .lbl { font-size:8px; color:var(--text-muted); display:block; }
        .product-card .detail-grid .item .val { font-size:12px; font-weight:600; color:var(--text); }
        .product-card .detail-grid .item .val.gold { color:var(--gold); }
        .product-card .detail-grid .item .val.green { color:var(--success); }

        .product-card .bottom-row {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:10px;
        }
        .product-card .bottom-row .price {
            font-size:16px;
            font-weight:700;
            color:var(--gold);
            white-space:nowrap;
        }
        .product-card .bottom-row .btn-buy {
            background:var(--gradient);
            border:none;
            color:#fff;
            padding:6px 16px;
            border-radius:20px;
            font-weight:700;
            font-size:11px;
            cursor:pointer;
            transition:0.3s;
            box-shadow:0 4px 15px rgba(0,212,255,0.15);
            display:flex;
            align-items:center;
            gap:4px;
            white-space:nowrap;
        }
        .product-card .bottom-row .btn-buy:hover {
            box-shadow:0 4px 25px rgba(0,212,255,0.3);
            transform:translateY(-2px);
        }
        .product-card .bottom-row .btn-buy:disabled {
            opacity:0.4;
            cursor:not-allowed;
            box-shadow:none;
            transform:none;
        }
        .product-card .bottom-row .btn-buy.offline {
            background:var(--text-muted);
            box-shadow:none;
            cursor:not-allowed;
        }
        .product-card .max-buy {
            font-size:10px;
            color:var(--text-muted);
            text-align:center;
            margin-top:6px;
        }

        .alert { padding:10px 14px; border-radius:12px; margin-bottom:10px; font-size:13px; display:flex; align-items:center; gap:8px; }
        .alert-error { background:rgba(255,82,82,0.12); border:1px solid rgba(255,82,82,0.2); color:var(--danger); }
        .alert-success { background:rgba(0,230,118,0.08); border:1px solid rgba(0,230,118,0.15); color:var(--success); }

        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }

        @media (max-width:380px) {
            .product-card .detail-grid { grid-template-columns:1fr 1fr; }
            .product-card .bottom-row { flex-wrap:wrap; }
        }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="sub-header">
        <div class="title"><i class="fas fa-dragon"></i> NAGA E-PREMIUM | NAGA ESCALE | ASTRALINK NAGA</div>
        <div class="desc">Pilih naga yang tersedia untuk investasi Anda</div>
    </div>

    <div class="naga-habis">
        <span class="label"><i class="fas fa-circle" style="color:var(--danger);font-size:10px;"></i> NAGA TELAH HABIS</span>
        <span class="badge">OFFLINE</span>
    </div>

    <?php if ($buy_error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= $buy_error ?></div>
    <?php endif; ?>
    <?php if ($buy_success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $buy_success ?></div>
    <?php endif; ?>

    <?php foreach ($db['products'] as $product): ?>
        <?php
        $count = 0;
        foreach ($user['active_products'] as $p) {
            if ($p['product_id'] == $product['id'] && $p['status'] == 'active') $count++;
        }
        $can_buy = $count < $product['max_buy'];
        $is_offline = $product['status'] != 'active' || !$can_buy;
        $badge = strtolower($product['badge'] ?? '');
        $badge_class = '';
        if ($badge == 'new') $badge_class = 'new';
        elseif ($badge == 'popular') $badge_class = 'popular';
        elseif ($badge == 'premium') $badge_class = 'premium';
        elseif ($badge == 'legend') $badge_class = 'legend';
        elseif ($badge == 'mythic') $badge_class = 'mythic';
        elseif ($badge == 'ultimate') $badge_class = 'ultimate';
        ?>
        <div class="product-card">
            <div class="top-row">
                <div class="left">
                    <div class="name"><i class="fas fa-dragon"></i> <?= $product['name'] ?></div>
                    <span class="status <?= $is_offline ? 'offline' : 'active' ?>">
                        <?= $is_offline ? 'OFFLINE' : 'TERSEDIA' ?>
                    </span>
                </div>
                <?php if ($badge_class): ?>
                    <span class="badge <?= $badge_class ?>"><?= strtoupper($badge) ?></span>
                <?php endif; ?>
            </div>

            <div class="detail-grid">
                <div class="item">
                    <span class="lbl">PROFIT / JAM</span>
                    <span class="val green"><?= formatRupiah($product['profit_per_hour']) ?></span>
                </div>
                <div class="item">
                    <span class="lbl">PROFIT / HARI</span>
                    <span class="val green"><?= formatRupiah($product['profit_per_day']) ?></span>
                </div>
                <div class="item">
                    <span class="lbl">DURASI</span>
                    <span class="val"><?= $product['duration_days'] ?> Hari</span>
                </div>
                <div class="item">
                    <span class="lbl">TOTAL PROFIT</span>
                    <span class="val gold"><?= formatRupiah($product['total_profit']) ?></span>
                </div>
                <div class="item">
                    <span class="lbl">MAX BELI</span>
                    <span class="val"><?= $product['max_buy'] ?>x</span>
                </div>
                <div class="item">
                    <span class="lbl">DIBELI</span>
                    <span class="val"><?= $count ?></span>
                </div>
            </div>

            <div class="bottom-row">
                <span class="price"><?= formatRupiah($product['price']) ?></span>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                    <button type="submit" name="buy_product" class="btn-buy <?= $is_offline ? 'offline' : '' ?>" <?= $is_offline ? 'disabled' : '' ?>>
                        <i class="fas fa-shopping-cart"></i> <?= $is_offline ? 'HABIS' : 'BELI' ?>
                    </button>
                </form>
            </div>
            <div class="max-buy">Dibeli: <?= $count ?> / <?= $product['max_buy'] ?>x</div>
        </div>
    <?php endforeach; ?>

    <div class="bottom-nav">
        <a href="home.php"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php" class="active"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldoDeposit = <?= $user['balance_deposit'] ?>;
saldoWithdraw = <?= $user['balance_withdraw'] ?>;
updateSaldoUI();
setInterval(fetchSaldo, 30000);
</script>
</body>
</html>