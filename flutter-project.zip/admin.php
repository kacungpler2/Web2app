<?php
error_reporting(0);
session_start();

$db_file = 'data/db.json';
if (!file_exists($db_file)) {
    die('Database tidak ditemukan.');
}

$db = json_decode(file_get_contents($db_file), true);
$admin_password_hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    if (password_verify($_POST['password'], $admin_password_hash)) {
        $_SESSION['admin'] = true;
    }
}

if (!isset($_SESSION['admin'])) {
    ?>
    <!DOCTYPE html>
    <html><head><title>Admin Login</title>
    <style>body{background:#0a0a0f;color:#fff;font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh}.login-box{background:rgba(255,255,255,0.05);padding:30px;border-radius:16px;width:300px;border:1px solid rgba(255,215,0,0.2)}h2{text-align:center;color:#ffd700}input{width:100%;padding:12px;margin:10px 0;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:#fff}button{width:100%;padding:12px;background:linear-gradient(135deg,#ffd700,#f59f00);border:none;border-radius:8px;color:#000;font-weight:bold;cursor:pointer}</style>
    </head>
    <body><div class="login-box"><h2>Admin Panel</h2><form method="POST"><input type="password" name="password" placeholder="Password" required><button type="submit" name="login">Login</button></form></div></body></html>
    <?php
    exit();
}

if (isset($_GET['approve_deposit'])) {
    $id = $_GET['approve_deposit'];
    foreach ($db['transactions']['deposits'] as &$d) {
        if ($d['id'] == $id && $d['status'] == 'pending') {
            $d['status'] = 'approved';
            foreach ($db['users'] as &$u) {
                if ($u['id'] == $d['user_id']) {
                    $u['balance_deposit'] += $d['amount'];
                    $u['total_deposit'] += $d['amount'];
                    break;
                }
            }
            break;
        }
    }
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    header('Location: admin.php?success=Deposit approved');
    exit();
}

if (isset($_GET['reject_deposit'])) {
    $id = $_GET['reject_deposit'];
    foreach ($db['transactions']['deposits'] as &$d) {
        if ($d['id'] == $id && $d['status'] == 'pending') {
            $d['status'] = 'rejected';
            break;
        }
    }
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    header('Location: admin.php?success=Deposit rejected');
    exit();
}

if (isset($_GET['approve_withdraw'])) {
    $id = $_GET['approve_withdraw'];
    foreach ($db['transactions']['withdrawals'] as &$w) {
        if ($w['id'] == $id && $w['status'] == 'pending') {
            $w['status'] = 'approved';
            foreach ($db['users'] as &$u) {
                if ($u['id'] == $w['user_id']) {
                    $u['balance_withdraw'] -= $w['amount'];
                    $u['total_withdraw'] += $w['amount'];
                    break;
                }
            }
            break;
        }
    }
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    header('Location: admin.php?success=Withdraw approved');
    exit();
}

if (isset($_GET['reject_withdraw'])) {
    $id = $_GET['reject_withdraw'];
    foreach ($db['transactions']['withdrawals'] as &$w) {
        if ($w['id'] == $id && $w['status'] == 'pending') {
            $w['status'] = 'rejected';
            break;
        }
    }
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    header('Location: admin.php?success=Withdraw rejected');
    exit();
}

if (isset($_GET['reset_user'])) {
    $id = $_GET['reset_user'];
    foreach ($db['users'] as &$u) {
        if ($u['id'] == $id) {
            $u['password'] = password_hash('password123', PASSWORD_DEFAULT);
            break;
        }
    }
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    header('Location: admin.php?success=Password reset');
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit();
}

$success = $_GET['success'] ?? '';
?>
<!DOCTYPE html>
<html>
<head><title>Admin Panel</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}
body{background:#0a0a0f;color:#fff;padding:20px}
.container{max-width:1200px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center;padding:20px 0;border-bottom:1px solid rgba(255,255,255,0.05)}
.header h1 i{color:#ffd700}
.logout-btn{background:#ff5252;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin:20px 0}
.stat-card{background:rgba(255,255,255,0.05);padding:20px;border-radius:12px;text-align:center}
.stat-card h3{font-size:28px;color:#ffd700}
.stat-card p{color:#888;font-size:14px}
.section{margin:30px 0}
.section h2{margin-bottom:15px}
.section h2 i{color:#ffd700}
table{width:100%;border-collapse:collapse}
th,td{padding:12px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.05)}
th{color:#888;font-size:12px;text-transform:uppercase}
.btn-approve{background:#00e676;color:#000;padding:4px 12px;border-radius:4px;text-decoration:none;font-size:12px}
.btn-reject{background:#ff5252;color:#fff;padding:4px 12px;border-radius:4px;text-decoration:none;font-size:12px}
.btn-reset{background:#ffd700;color:#000;padding:4px 12px;border-radius:4px;text-decoration:none;font-size:12px}
.status-pending{color:#ffd700}
.status-approved{color:#00e676}
.status-rejected{color:#ff5252}
.alert-success{background:rgba(0,230,118,0.1);border:1px solid rgba(0,230,118,0.2);color:#00e676;padding:12px 16px;border-radius:8px;margin:10px 0}
.no-data{color:#555;text-align:center;padding:20px}
</style>
</head>
<body>
<div class="container">
    <div class="header"><h1><i class="fas fa-shield-alt"></i> Admin Panel</h1><a href="?logout" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a></div>
    <?php if ($success): ?><div class="alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php
    $total_users = count($db['users']);
    $total_deposit = 0; $total_withdraw = 0; $pending_deposits = 0; $pending_withdrawals = 0;
    foreach ($db['transactions']['deposits'] as $d) {
        if ($d['status'] == 'approved') $total_deposit += $d['amount'];
        if ($d['status'] == 'pending') $pending_deposits++;
    }
    foreach ($db['transactions']['withdrawals'] as $w) {
        if ($w['status'] == 'approved') $total_withdraw += $w['amount'];
        if ($w['status'] == 'pending') $pending_withdrawals++;
    }
    ?>
    <div class="stats">
        <div class="stat-card"><h3><?= $total_users ?></h3><p>Total User</p></div>
        <div class="stat-card"><h3>Rp <?= number_format($total_deposit,0,',','.') ?></h3><p>Total Deposit</p></div>
        <div class="stat-card"><h3>Rp <?= number_format($total_withdraw,0,',','.') ?></h3><p>Total Withdraw</p></div>
        <div class="stat-card"><h3><?= $pending_deposits + $pending_withdrawals ?></h3><p>Pending</p></div>
    </div>
    <div class="section"><h2><i class="fas fa-plus-circle"></i> Pending Deposits</h2>
    <?php $pending_dep = array_filter($db['transactions']['deposits'], fn($d) => $d['status'] == 'pending');
    if (count($pending_dep) > 0): ?>
    <table><tr><th>User</th><th>Jumlah</th><th>Bank</th><th>Pengirim</th><th>Aksi</th></tr>
    <?php foreach ($pending_dep as $d): ?>
        <tr><td><?= $d['username'] ?></td><td>Rp <?= number_format($d['amount'],0,',','.') ?></td><td><?= $d['bank'] ?></td><td><?= $d['sender'] ?></td><td><a href="?approve_deposit=<?= $d['id'] ?>" class="btn-approve">Approve</a> <a href="?reject_deposit=<?= $d['id'] ?>" class="btn-reject">Reject</a></td></tr>
    <?php endforeach; ?></table>
    <?php else: ?><p class="no-data">Tidak ada deposit pending</p><?php endif; ?></div>

    <div class="section"><h2><i class="fas fa-arrow-up"></i> Pending Withdrawals</h2>
    <?php $pending_wd = array_filter($db['transactions']['withdrawals'], fn($w) => $w['status'] == 'pending');
    if (count($pending_wd) > 0): ?>
    <table><tr><th>User</th><th>Jumlah</th><th>Net</th><th>Metode</th><th>Aksi</th></tr>
    <?php foreach ($pending_wd as $w): ?>
        <tr><td><?= $w['username'] ?></td><td>Rp <?= number_format($w['amount'],0,',','.') ?></td><td>Rp <?= number_format($w['net_amount'],0,',','.') ?></td><td><?= $w['payment_method'] ?? '-' ?></td><td><a href="?approve_withdraw=<?= $w['id'] ?>" class="btn-approve">Approve</a> <a href="?reject_withdraw=<?= $w['id'] ?>" class="btn-reject">Reject</a></td></tr>
    <?php endforeach; ?></table>
    <?php else: ?><p class="no-data">Tidak ada penarikan pending</p><?php endif; ?></div>

    <div class="section"><h2><i class="fas fa-users"></i> All Users</h2>
    <table><tr><th>Username</th><th>Deposit</th><th>Tarik</th><th>Referral</th><th>Aksi</th></tr>
    <?php foreach ($db['users'] as $u): ?>
        <tr><td><?= $u['username'] ?></td><td>Rp <?= number_format($u['balance_deposit'],0,',','.') ?></td><td>Rp <?= number_format($u['balance_withdraw'],0,',','.') ?></td><td><?= $u['referral_count'] ?></td><td><a href="?reset_user=<?= $u['id'] ?>" class="btn-reset" onclick="return confirm('Reset password?')">Reset PW</a></td></tr>
    <?php endforeach; ?></table></div>
</div>
</body>
</html>