// ============================================
// TERNAK NAGA - CUSTOM NOTIFICATION
// ============================================

function showNotification(title, message, type = 'info', callback = null) {
    const old = document.getElementById('customModal');
    if (old) old.remove();

    const overlay = document.createElement('div');
    overlay.id = 'customModal';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        backdrop-filter: blur(12px);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: fadeIn 0.3s ease;
        padding: 20px;
    `;

    const colors = {
        success: '#00e676',
        error: '#ff5252',
        info: '#00d4ff',
        warning: '#ffd700'
    };
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle',
        warning: 'fas fa-exclamation-triangle'
    };
    const color = colors[type] || colors.info;
    const icon = icons[type] || icons.info;

    overlay.innerHTML = `
        <div style="
            background: linear-gradient(145deg, #1a1a2e, #14141e);
            border: 1px solid ${color}44;
            border-radius: 24px;
            padding: 32px 28px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            box-shadow: 0 30px 80px rgba(0,0,0,0.6);
            animation: popIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        ">
            <div style="font-size: 56px; color: ${color}; margin-bottom: 12px;">
                <i class="${icon}"></i>
            </div>
            <h3 style="color: #fff; font-size: 22px; font-weight: 700; margin-bottom: 6px;">${title}</h3>
            <p style="color: #aaa; font-size: 14px; line-height: 1.7; margin-bottom: 24px;">${message}</p>
            <button onclick="closeNotification()" style="
                background: linear-gradient(135deg, ${color}, ${color}dd);
                border: none;
                color: #fff;
                padding: 12px 48px;
                border-radius: 30px;
                font-weight: 700;
                font-size: 16px;
                cursor: pointer;
                transition: 0.3s;
                box-shadow: 0 4px 20px ${color}33;
            ">OK</button>
        </div>
    `;

    document.body.appendChild(overlay);

    if (!document.getElementById('modalStyles')) {
        const style = document.createElement('style');
        style.id = 'modalStyles';
        style.textContent = `
            @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
            @keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        `;
        document.head.appendChild(style);
    }

    if (callback) overlay._callback = callback;
}

function closeNotification() {
    const modal = document.getElementById('customModal');
    if (modal) {
        const cb = modal._callback;
        modal.remove();
        if (cb && typeof cb === 'function') cb();
    }
}

function showConfirm(title, message, onConfirm, onCancel = null) {
    const old = document.getElementById('customModal');
    if (old) old.remove();

    const overlay = document.createElement('div');
    overlay.id = 'customModal';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        backdrop-filter: blur(12px);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: fadeIn 0.3s ease;
        padding: 20px;
    `;

    overlay.innerHTML = `
        <div style="
            background: linear-gradient(145deg, #1a1a2e, #14141e);
            border: 1px solid rgba(255,215,0,0.2);
            border-radius: 24px;
            padding: 32px 28px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            box-shadow: 0 30px 80px rgba(0,0,0,0.6);
            animation: popIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        ">
            <div style="font-size: 56px; color: #ffd700; margin-bottom: 12px;">
                <i class="fas fa-question-circle"></i>
            </div>
            <h3 style="color: #fff; font-size: 22px; font-weight: 700; margin-bottom: 6px;">${title}</h3>
            <p style="color: #aaa; font-size: 14px; line-height: 1.7; margin-bottom: 24px;">${message}</p>
            <div style="display: flex; gap: 12px;">
                <button onclick="closeConfirm(false)" style="
                    background: rgba(255,255,255,0.06);
                    border: 1px solid rgba(255,255,255,0.08);
                    color: #fff;
                    padding: 12px 24px;
                    border-radius: 12px;
                    font-weight: 600;
                    font-size: 15px;
                    cursor: pointer;
                    flex: 1;
                ">Batal</button>
                <button onclick="closeConfirm(true)" style="
                    background: linear-gradient(135deg, #ffd700, #f59f00);
                    border: none;
                    color: #000;
                    padding: 12px 24px;
                    border-radius: 12px;
                    font-weight: 700;
                    font-size: 15px;
                    cursor: pointer;
                    flex: 1;
                    box-shadow: 0 4px 20px rgba(255,215,0,0.25);
                ">Ya, Lanjutkan</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    if (!document.getElementById('modalStyles')) {
        const style = document.createElement('style');
        style.id = 'modalStyles';
        style.textContent = `
            @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
            @keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        `;
        document.head.appendChild(style);
    }

    overlay._onConfirm = onConfirm;
    overlay._onCancel = onCancel;
}

function closeConfirm(result) {
    const modal = document.getElementById('customModal');
    if (modal) {
        const onConfirm = modal._onConfirm;
        const onCancel = modal._onCancel;
        modal.remove();
        if (result && onConfirm && typeof onConfirm === 'function') onConfirm();
        if (!result && onCancel && typeof onCancel === 'function') onCancel();
    }
}

let saldoDeposit = 0;
let saldoWithdraw = 0;

function updateSaldoUI() {
    const el1 = document.getElementById('saldoDeposit');
    const el2 = document.getElementById('saldoWithdraw');
    if (el1) el1.textContent = 'Rp ' + saldoDeposit.toLocaleString('id-ID');
    if (el2) el2.textContent = 'Rp ' + saldoWithdraw.toLocaleString('id-ID');
}

function fetchSaldo() {
    fetch('api.php?action=saldo')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'success') {
                saldoDeposit = data.balance_deposit || 0;
                saldoWithdraw = data.balance_withdraw || 0;
                updateSaldoUI();
            }
        })
        .catch(() => {});
}

function copyRefCode() {
    const code = document.getElementById('refCode')?.textContent || '';
    const url = window.location.origin + window.location.pathname.replace(/\/[^\/]*$/, '/') + '?ref=' + code;
    if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
            showNotification('Berhasil', 'Link referral disalin!', 'success');
        }).catch(() => fallbackCopy(url));
    } else {
        fallbackCopy(url);
    }
}

function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showNotification('Berhasil', 'Link referral disalin!', 'success');
}

const paymentOptions = [
    { value: 'BCA', label: '🏦 BCA', type: 'bank' },
    { value: 'MANDIRI', label: '🏦 Mandiri', type: 'bank' },
    { value: 'BNI', label: '🏦 BNI', type: 'bank' },
    { value: 'BRI', label: '🏦 BRI', type: 'bank' },
    { value: 'DANA', label: '📱 DANA', type: 'ewallet' },
    { value: 'OVO', label: '📱 OVO', type: 'ewallet' },
    { value: 'GOPAY', label: '📱 GoPay', type: 'ewallet' },
    { value: 'SHOPEEPAY', label: '📱 ShopeePay', type: 'ewallet' },
    { value: 'LINKAJA', label: '📱 LinkAja', type: 'ewallet' }
];

function populatePaymentOptions(selectId) {
    const select = document.getElementById(selectId);
    if (!select) return;
    select.innerHTML = '';
    paymentOptions.forEach(opt => {
        const option = document.createElement('option');
        option.value = opt.value;
        option.textContent = opt.label;
        select.appendChild(option);
    });
}

function handleFormSubmit(formId, action, redirectUrl = null) {
    const form = document.getElementById(formId);
    if (!form) return;
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('api.php?action=' + action, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.status === 'success') {
                    showNotification('Berhasil', data.message, 'success', () => {
                        if (redirectUrl) window.location.href = redirectUrl;
                        else window.location.reload();
                    });
                } else {
                    showNotification('Gagal', data.message || 'Terjadi kesalahan!', 'error');
                }
            })
            .catch(() => showNotification('Error', 'Terjadi kesalahan koneksi!', 'error'));
    });
}

document.addEventListener('DOMContentLoaded', function() {
    populatePaymentOptions('paymentType');
    populatePaymentOptions('paymentTypeWithdraw');
    populatePaymentOptions('paymentMethod');
    if (document.getElementById('saldoDeposit') || document.getElementById('saldoWithdraw')) {
        fetchSaldo();
        setInterval(fetchSaldo, 30000);
    }
    handleFormSubmit('depositForm', 'deposit', 'home.php');
    handleFormSubmit('withdrawForm', 'withdraw', 'home.php');
    handleFormSubmit('bankForm', 'update_bank', null);
});

window.showNotification = showNotification;
window.closeNotification = closeNotification;
window.showConfirm = showConfirm;
window.closeConfirm = closeConfirm;
window.fetchSaldo = fetchSaldo;
window.copyRefCode = copyRefCode;
window.paymentOptions = paymentOptions;
window.populatePaymentOptions = populatePaymentOptions;