<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Profit otomatis
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        foreach ($u['active_products'] as &$p) {
            if ($p['status'] == 'active') {
                $last = strtotime($p['last_profit'] ?? $p['bought_at']);
                $now = time();
                $interval = 3600;
                $bought = strtotime($p['bought_at']);
                $expired = $bought + ($p['duration_days'] * 86400);
                if ($now > $expired) {
                    $p['status'] = 'expired';
                    continue;
                }
                if ($now - $last >= $interval && $p['profit_count'] < $p['total_profit_count']) {
                    $p['profit_count']++;
                    $u['balance_withdraw'] += $p['profit_per_hour'];
                    $u['total_profit'] += $p['profit_per_hour'];
                    $p['last_profit'] = date('Y-m-d H:i:s');
                    $db['transactions']['profits'][] = [
                        'id' => 'PRF' . date('Ymd') . rand(100, 999),
                        'user_id' => $u['id'],
                        'username' => $u['username'],
                        'product_id' => $p['product_id'],
                        'product_name' => $p['name'],
                        'amount' => $p['profit_per_hour'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        $_SESSION['user'] = $u;
        break;
    }
}
file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

// Hitung referral 3 level
$level1 = [];
$level2 = [];
$level3 = [];
$level1_earnings = 0;
$level2_earnings = 0;
$level3_earnings = 0;

foreach ($db['users'] as $u) {
    if ($u['referred_by'] == $user['referral_code']) {
        $level1[] = $u;
        $level1_earnings += $u['total_deposit'] * 0.11;
    }
}
foreach ($db['users'] as $u) {
    foreach ($level1 as $l1) {
        if ($u['referred_by'] == $l1['referral_code']) {
            $level2[] = $u;
            $level2_earnings += $u['total_deposit'] * 0.04;
        }
    }
}
foreach ($db['users'] as $u) {
    foreach ($level2 as $l2) {
        if ($u['referred_by'] == $l2['referral_code']) {
            $level3[] = $u;
            $level3_earnings += $u['total_deposit'] * 0.01;
        }
    }
}
$total_earnings = $level1_earnings + $level2_earnings + $level3_earnings;
$total_nodes = count($level1) + count($level2) + count($level3);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Tim - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --text:#ffffff;
            --text-muted:#888888;
            --gold:#ffd700;
            --gold-dim:rgba(255,215,0,0.1);
            --success:#00e676;
            --primary:#00d4ff;
            --border:rgba(255,255,255,0.05);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:linear-gradient(135deg,#ffd700,#f59f00); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:#00d4ff; }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:rgba(255,255,255,0.03); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:rgba(255,215,0,0.2); }
        .user i { font-size:28px; color:var(--text); }

        .section-title { font-size:16px; font-weight:700; margin:24px 0 12px; display:flex; align-items:center; gap:10px; }
        .section-title i { color:var(--gold); font-size:18px; }

        /* ===== REF SECTION ===== */
        .ref-section {
            margin:12px 0 16px;
            padding:0 0 12px;
            border-bottom:1px solid var(--border);
        }
        .ref-section .label {
            font-size:12px;
            color:var(--text-muted);
            display:flex;
            align-items:center;
            gap:6px;
            margin-bottom:4px;
        }
        .ref-section .label i { color:var(--gold); }
        .ref-section .code {
            font-size:28px;
            font-weight:800;
            letter-spacing:4px;
            color:var(--gold);
            margin:4px 0 8px;
            font-family:'Courier New',monospace;
        }
        .ref-section .bonus-text {
            font-size:13px;
            color:var(--text-muted);
            line-height:1.7;
            margin-bottom:12px;
        }
        .ref-section .bonus-text strong { color:var(--gold); }
        .ref-section .bonus-text .highlight { color:var(--success); font-weight:600; }
        .ref-section .btn-group {
            display:flex;
            gap:8px;
            flex-wrap:wrap;
        }
        .ref-section .btn-group button {
            padding:6px 14px;
            border-radius:20px;
            font-weight:600;
            font-size:11px;
            cursor:pointer;
            transition:0.3s;
            display:inline-flex;
            align-items:center;
            gap:5px;
            border:none;
        }
        .ref-section .btn-group button:active { transform:scale(0.95); }
        .ref-section .btn-group .btn-copy {
            background:linear-gradient(135deg,#ffd700,#f59f00);
            color:#000;
        }
        .ref-section .btn-group .btn-wa {
            background:#25D366;
            color:#fff;
        }

        /* ===== STATS BADGE ===== */
        .stats-badge {
            display:flex;
            gap:16px;
            flex-wrap:wrap;
            margin:12px 0;
            padding:0;
        }
        .stats-badge .badge {
            display:flex;
            align-items:center;
            gap:6px;
            font-size:13px;
            color:var(--text-muted);
        }
        .stats-badge .badge i {
            font-size:16px;
            color:var(--gold);
        }
        .stats-badge .badge strong {
            font-weight:700;
            color:var(--text);
            font-size:15px;
        }
        .stats-badge .badge .num {
            font-weight:700;
            color:var(--gold);
            font-size:15px;
        }

        /* ===== KOMISI LEVEL ===== */
        .level-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:10px 0;
            border-bottom:1px solid var(--border);
        }
        .level-item:last-child { border-bottom:none; }
        .level-item .left { display:flex; align-items:center; gap:10px; }
        .level-item .left .badge {
            display:inline-block;
            padding:2px 10px;
            border-radius:12px;
            font-size:10px;
            font-weight:700;
        }
        .level-item .left .badge.l1 { background:rgba(255,215,0,0.2); color:#ffd700; }
        .level-item .left .badge.l2 { background:rgba(0,212,255,0.2); color:#00d4ff; }
        .level-item .left .badge.l3 { background:rgba(0,230,118,0.2); color:#00e676; }
        .level-item .left .label { font-size:13px; color:var(--text-muted); }
        .level-item .right .amount { font-weight:700; font-size:15px; }
        .level-item .right .amount.gold { color:var(--gold); }
        .level-item .right .amount.blue { color:var(--primary); }
        .level-item .right .amount.green { color:var(--success); }

        .total-row {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:12px 0 0;
            border-top:1px solid rgba(255,215,0,0.15);
            margin-top:4px;
        }
        .total-row .label { font-size:14px; font-weight:700; color:var(--gold); }
        .total-row .amount { font-size:20px; font-weight:700; color:var(--gold); }

        /* ===== INFO ===== */
        .info-text {
            margin:12px 0;
            padding:0;
        }
        .info-text h4 {
            font-size:14px;
            font-weight:700;
            color:var(--gold);
            margin-bottom:8px;
        }
        .info-text h4 i { margin-right:6px; }
        .info-text p {
            font-size:12px;
            color:var(--text-muted);
            line-height:1.8;
            margin-bottom:4px;
        }
        .info-text .highlight { color:var(--gold); font-weight:600; }
        .info-text .highlight-green { color:var(--success); font-weight:600; }

        /* ===== DAFTAR REFERRAL ===== */
        .ref-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:10px 0;
            border-bottom:1px solid var(--border);
        }
        .ref-item .name { font-weight:500; font-size:14px; }
        .ref-item .date { font-size:11px; color:var(--text-muted); }
        .ref-item .bonus { color:var(--success); font-weight:600; font-size:14px; }
        .empty { text-align:center; color:var(--text-muted); padding:24px 0; font-size:14px; }
        .empty i { font-size:36px; color:var(--text-muted); display:block; margin-bottom:8px; opacity:0.4; }

        /* ===== BOTTOM NAV ===== */
        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }

        @media (max-width:380px) {
            .stats-badge { gap:10px; }
            .ref-section .code { font-size:22px; letter-spacing:2px; }
            .ref-section .btn-group { flex-direction:column; }
            .ref-section .btn-group button { width:100%; justify-content:center; }
        }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="section-title"><i class="fas fa-network-wired"></i> Tim Referral</div>

    <!-- ===== REF SECTION ===== -->
    <div class="ref-section">
        <div class="label"><i class="fas fa-link"></i> KODE REFERRAL ANDA</div>
        <div class="code" id="refCode"><?= $user['referral_code'] ?></div>
        <div class="bonus-text">
            <strong>Setiap orang yang mendaftar melalui link Anda</strong> akan memberikan Anda <span class="highlight">Rp 1.000</span> langsung ke saldo tarik.
            <br>Bonus ini berlaku untuk setiap referral aktif tanpa batas.
        </div>
        <div class="btn-group">
            <button class="btn-copy" onclick="copyRefCode()"><i class="fas fa-copy"></i> Salin Link</button>
            <button class="btn-wa" onclick="shareWA()"><i class="fab fa-whatsapp"></i> Bagikan ke WA</button>
        </div>
    </div>

    <!-- ===== STATS BADGE (REFF & TOTAL REFF) ===== -->
    <div class="stats-badge">
        <div class="badge">
            <i class="fas fa-users"></i>
            <span>Total Referral</span>
            <strong class="num"><?= $user['referral_count'] ?></strong>
        </div>
        <div class="badge">
            <i class="fas fa-layer-group"></i>
            <span>Level 1</span>
            <strong><?= count($level1) ?></strong>
        </div>
        <div class="badge">
            <i class="fas fa-layer-group"></i>
            <span>Level 2</span>
            <strong><?= count($level2) ?></strong>
        </div>
        <div class="badge">
            <i class="fas fa-layer-group"></i>
            <span>Level 3</span>
            <strong><?= count($level3) ?></strong>
        </div>
    </div>

    <!-- ===== KOMISI LEVEL ===== -->
    <div class="level-item">
        <div class="left">
            <span class="badge l1">L1</span>
            <span class="label">Level 1 (11%)</span>
        </div>
        <div class="right"><span class="amount gold"><?= formatRupiah($level1_earnings) ?></span></div>
    </div>
    <div class="level-item">
        <div class="left">
            <span class="badge l2">L2</span>
            <span class="label">Level 2 (4%)</span>
        </div>
        <div class="right"><span class="amount blue"><?= formatRupiah($level2_earnings) ?></span></div>
    </div>
    <div class="level-item">
        <div class="left">
            <span class="badge l3">L3</span>
            <span class="label">Level 3 (1%)</span>
        </div>
        <div class="right"><span class="amount green"><?= formatRupiah($level3_earnings) ?></span></div>
    </div>
    <div class="total-row">
        <span class="label">Total Komisi</span>
        <span class="amount"><?= formatRupiah($total_earnings) ?></span>
    </div>

    <!-- ===== INFO ===== -->
    <div class="info-text">
        <h4><i class="fas fa-info-circle"></i> Bagaimana Cara Kerja Referral?</h4>
        <p>1. Bagikan link referral Anda ke teman atau keluarga.</p>
        <p>2. Setiap orang yang mendaftar menggunakan link Anda akan menjadi <span class="highlight">referral level 1</span>.</p>
        <p>3. Anda akan mendapatkan <span class="highlight-green">Rp 1.000</span> per referral yang aktif.</p>
        <p>4. Tambahan komisi <span class="highlight">3 level</span> dari deposit mereka:
            <br>• Level 1: <span class="highlight">11%</span> dari deposit referral
            <br>• Level 2: <span class="highlight">4%</span> dari deposit referral level 2
            <br>• Level 3: <span class="highlight">1%</span> dari deposit referral level 3
        </p>
        <p style="margin-top:4px;font-size:11px;color:var(--text-muted);">
            <i class="fas fa-arrow-right" style="color:var(--gold);"></i> Semakin banyak referral, semakin besar bonus Anda!
        </p>
    </div>

    <!-- ===== DAFTAR REFERRAL ===== -->
    <div class="section-title" style="font-size:15px;margin-top:8px;"><i class="fas fa-list"></i> Daftar Referral</div>
    <?php if (count($user['referral_list'] ?? []) > 0): ?>
        <?php foreach (array_reverse($user['referral_list']) as $ref): ?>
            <div class="ref-item">
                <div>
                    <div class="name"><?= htmlspecialchars($ref['username']) ?></div>
                    <div class="date"><?= date('d/m/Y', strtotime($ref['joined_at'])) ?></div>
                </div>
                <div class="bonus">+Rp 1.000</div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="empty"><i class="fas fa-users-slash"></i> Belum ada referral. Bagikan link Anda!</div>
    <?php endif; ?>

    <div class="bottom-nav">
        <a href="home.php"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php" class="active"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldoDeposit = <?= $user['balance_deposit'] ?>;
saldoWithdraw = <?= $user['balance_withdraw'] ?>;
updateSaldoUI();
setInterval(fetchSaldo, 30000);

function getShareMessage() {
    const code = document.getElementById('refCode').textContent;
    const url = window.location.origin + window.location.pathname.replace(/\/[^\/]*$/, '/') + '?ref=' + code;
    return '🐉 *Ternak Naga* - Dapatkan Rp 1.000 per referral!\n\n' +
           '🎯 Gabung sekarang dan mulai investasi ternak naga!\n' +
           '💰 Profit otomatis setiap jam\n' +
           '👥 Bonus referral 3 level (11% - 4% - 1%)\n\n' +
           '🔗 Link pendaftaran:\n' + url;
}

function copyRefCode() {
    const message = getShareMessage();
    if (navigator.clipboard) {
        navigator.clipboard.writeText(message).then(() => {
            showNotification('Berhasil', 'Link dengan judul disalin!', 'success');
        }).catch(() => fallbackCopy(message));
    } else {
        fallbackCopy(message);
    }
}

function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showNotification('Berhasil', 'Link dengan judul disalin!', 'success');
}

function shareWA() {
    const message = getShareMessage();
    const waUrl = 'https://api.whatsapp.com/send?text=' + encodeURIComponent(message);
    window.open(waUrl, '_blank');
}
</script>
</body>
</html>