module.exports = {
  BOT_TOKEN: "8243196199:AAFmNAWh3YFHZvrESlMlYKCZigy9_zrfD8I",
  OWNER_ID: ["7033328355"],
};