module.exports = {
    version: "2",
    ownerId: 6736986837,
    namaBot: "𝙱𝙾𝚃 𝙱𝚄𝙶 𝙰𝙽𝙶𝙺𝙰𝚂𝙰",
    usernameOwner: "@angkasanyabobo",
    telegramBotToken: "8284071488:AAGPRyAvox5ZnvGPpfAtOuD5RVrxZ6DKgFE",
    sessionName: "session",
    portVps: "1303",
    ipVps: "http://165.22.49.57",
    message: {
        owner: `🚫 Khusus Owner Jangan Spam!`,
        wait: `⏳ Otw Tunggu Sebentar...`,
        error: `⚠️ error. Coba lagi nanti.`,
        waNotConnected: `⚠️ Tidak Ada Whatsapp Yang Terhubung /pairing Untuk Menghubngkan Ke Whatsapp.`
    },
    settings: {
        namabot: "Apk Bug By Angkasa",
        footer: "Powered By Angkasa",
        cekBioBatchSize: 20
    }
};