module.exports = {
  BOT_TOKEN: '8907887757:AAH3hIDYq6L8IYCSri2DnSsau7sHfjiO1qI', // Ganti dengan token asli dari BotFather
  REQUIRED_CHANNEL: '@LalzzXiter', // Channel wajib agar bot aktif di grup
  START_IMAGE_URL: 'https://files.catbox.moe/j22ij8.jpg', // Gambar sambutan untuk /start
  OWNER_ID: 6462842640 // Ganti dengan ID Telegram kamu
};