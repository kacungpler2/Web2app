package com.safa.playlist

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity: AudioServiceActivity()
