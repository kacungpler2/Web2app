import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';
import '../screens/now_playing_screen.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(builder: (_, prov, __) {
      final song = prov.currentSong;
      if (song == null) return const SizedBox.shrink();

      return GestureDetector(
        onTap: () => Navigator.push(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => const NowPlayingScreen(),
            transitionsBuilder: (_, anim, __, child) => SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 1),
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
              child: child,
            ),
          ),
        ),
        child: Container(
          height: 64,
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            border: Border(
              top: BorderSide(color: AppTheme.primary.withOpacity(0.3), width: 1),
            ),
          ),
          child: Column(
            children: [
              // Progress bar
              LinearProgressIndicator(
                value: prov.progress.clamp(0.0, 1.0),
                backgroundColor: AppTheme.bgElevated,
                valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primary),
                minHeight: 2,
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      // Album art
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: song.albumArt != null
                            ? Image.memory(song.albumArt!,
                                width: 42, height: 42, fit: BoxFit.cover)
                            : Container(
                                width: 42,
                                height: 42,
                                decoration: const BoxDecoration(
                                  gradient: AppTheme.primaryGradient,
                                ),
                                child: const Icon(Icons.music_note,
                                    color: Colors.white, size: 20),
                              ),
                      ),
                      const SizedBox(width: 10),
                      // Info
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              song.title,
                              style: const TextStyle(
                                color: AppTheme.textPrimary,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              song.artist,
                              style: const TextStyle(
                                  color: AppTheme.textHint, fontSize: 11),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      // Controls
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.skip_previous,
                                color: AppTheme.textSecondary, size: 22),
                            padding: EdgeInsets.zero,
                            onPressed: prov.playPrevious,
                          ),
                          GestureDetector(
                            onTap: prov.togglePlayPause,
                            child: Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: AppTheme.primaryGradient,
                                boxShadow: [
                                  BoxShadow(
                                    color: AppTheme.primary.withOpacity(0.3),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                              child: Icon(
                                prov.isPlaying ? Icons.pause : Icons.play_arrow,
                                color: AppTheme.bgDark,
                                size: 20,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.skip_next,
                                color: AppTheme.textSecondary, size: 22),
                            padding: EdgeInsets.zero,
                            onPressed: prov.playNext,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
