import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';
import '../providers/music_provider.dart';
import '../providers/playlist_provider.dart';
import '../theme/app_theme.dart';
import '../screens/now_playing_screen.dart';
import '../screens/edit_song_screen.dart';

class SongTile extends StatelessWidget {
  final Song song;
  final List<Song> songList;

  const SongTile({super.key, required this.song, required this.songList});

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(builder: (_, prov, __) {
      final isPlaying = prov.currentSong?.id == song.id;
      return Slidable(
        endActionPane: ActionPane(
          motion: const BehindMotion(),
          extentRatio: 0.55,
          children: [
            SlidableAction(
              onPressed: (_) => prov.toggleFavorite(song.id),
              backgroundColor:
                  song.isFavorite ? Colors.redAccent : AppTheme.bgElevated,
              foregroundColor: Colors.white,
              icon:
                  song.isFavorite ? Icons.favorite : Icons.favorite_outline,
              borderRadius: BorderRadius.circular(12),
            ),
            SlidableAction(
              onPressed: (_) => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => EditSongScreen(song: song)),
              ),
              backgroundColor: AppTheme.primaryDark,
              foregroundColor: Colors.white,
              icon: Icons.edit_outlined,
              borderRadius: BorderRadius.circular(12),
            ),
            SlidableAction(
              onPressed: (_) =>
                  _showAddToPlaylist(context, prov, song),
              backgroundColor: AppTheme.bgSurface,
              foregroundColor: AppTheme.accent,
              icon: Icons.playlist_add,
              borderRadius: BorderRadius.circular(12),
            ),
          ],
        ),
        child: InkWell(
          onTap: () async {
            await prov.playSong(song, songList: songList);
            if (context.mounted) {
              Navigator.push(
                context,
                PageRouteBuilder(
                  pageBuilder: (_, __, ___) => const NowPlayingScreen(),
                  transitionsBuilder: (_, anim, __, child) =>
                      SlideTransition(
                    position: Tween<Offset>(
                            begin: const Offset(0, 1), end: Offset.zero)
                        .animate(CurvedAnimation(
                            parent: anim, curve: Curves.easeOutCubic)),
                    child: child,
                  ),
                ),
              );
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isPlaying
                  ? AppTheme.primary.withOpacity(0.08)
                  : Colors.transparent,
            ),
            child: Row(
              children: [
                // Album art / playing indicator
                Stack(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: AppTheme.bgElevated,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: song.albumArt != null
                            ? Image.memory(song.albumArt!, fit: BoxFit.cover)
                            : Container(
                                decoration: const BoxDecoration(
                                  gradient: AppTheme.cardGradient,
                                ),
                                child: const Icon(Icons.music_note,
                                    color: AppTheme.primary, size: 24),
                              ),
                      ),
                    ),
                    if (isPlaying)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppTheme.bgDark.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.equalizer,
                              color: AppTheme.primary, size: 20),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 12),
                // Song info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        song.title,
                        style: TextStyle(
                          color: isPlaying
                              ? AppTheme.primary
                              : AppTheme.textPrimary,
                          fontSize: 14,
                          fontWeight: isPlaying
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        song.artist,
                        style: const TextStyle(
                            color: AppTheme.textHint, fontSize: 12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                // Duration + favorite
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      song.durationString,
                      style: const TextStyle(
                          color: AppTheme.textHint, fontSize: 11),
                    ),
                    if (song.isFavorite)
                      const Icon(Icons.favorite,
                          color: Colors.redAccent, size: 14),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  void _showAddToPlaylist(
      BuildContext context, MusicProvider musicProv, Song song) {
    final playlistProv = context.read<PlaylistProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgSurface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Tambah ke Playlist',
                style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
          ),
          if (playlistProv.playlists.isEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('Belum ada playlist. Buat dulu di tab Playlist.',
                  style: TextStyle(color: AppTheme.textHint),
                  textAlign: TextAlign.center),
            )
          else
            ...playlistProv.playlists.map((pl) {
              final inPl = playlistProv.isSongInPlaylist(pl.id, song.id);
              return ListTile(
                leading: Icon(
                  inPl ? Icons.check_circle : Icons.playlist_add,
                  color: inPl ? AppTheme.success : AppTheme.primary,
                ),
                title: Text(pl.name,
                    style: const TextStyle(color: AppTheme.textPrimary)),
                subtitle: Text('${pl.songCount} lagu',
                    style: const TextStyle(color: AppTheme.textHint)),
                onTap: () {
                  if (inPl) {
                    playlistProv.removeSongFromPlaylist(pl.id, song.id);
                  } else {
                    playlistProv.addSongToPlaylist(pl.id, song.id);
                  }
                  Navigator.pop(context);
                },
              );
            }),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
