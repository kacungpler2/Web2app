import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class MusicVisualizer extends StatefulWidget {
  final bool isPlaying;
  const MusicVisualizer({super.key, required this.isPlaying});

  @override
  State<MusicVisualizer> createState() => _MusicVisualizerState();
}

class _MusicVisualizerState extends State<MusicVisualizer>
    with TickerProviderStateMixin {
  final List<AnimationController> _controllers = [];
  final List<Animation<double>> _animations = [];
  final _random = Random();
  static const int _barCount = 32;

  @override
  void initState() {
    super.initState();
    for (int i = 0; i < _barCount; i++) {
      final duration = Duration(milliseconds: 300 + _random.nextInt(500));
      final ctrl = AnimationController(vsync: this, duration: duration);
      final anim = Tween<double>(
        begin: 0.05,
        end: 0.2 + _random.nextDouble() * 0.8,
      ).animate(CurvedAnimation(parent: ctrl, curve: Curves.easeInOut));
      _controllers.add(ctrl);
      _animations.add(anim);
      if (widget.isPlaying) {
        Future.delayed(Duration(milliseconds: _random.nextInt(200)), () {
          if (mounted) ctrl.repeat(reverse: true);
        });
      }
    }
  }

  @override
  void didUpdateWidget(MusicVisualizer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isPlaying != oldWidget.isPlaying) {
      for (int i = 0; i < _controllers.length; i++) {
        if (widget.isPlaying) {
          Future.delayed(Duration(milliseconds: _random.nextInt(150)), () {
            if (mounted) _controllers[i].repeat(reverse: true);
          });
        } else {
          _controllers[i].animateTo(0.05, duration: const Duration(milliseconds: 300));
        }
      }
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final barWidth = (constraints.maxWidth / _barCount) - 2.0;
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(_barCount, (i) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: AnimatedBuilder(
              animation: _animations[i],
              builder: (_, __) {
                final height = constraints.maxHeight * _animations[i].value;
                final progress = i / _barCount;
                final color = Color.lerp(
                  AppTheme.primary,
                  AppTheme.accent,
                  progress,
                )!;
                return Container(
                  width: barWidth,
                  height: height.clamp(3.0, constraints.maxHeight),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(barWidth / 2),
                    gradient: LinearGradient(
                      colors: [color.withOpacity(0.4), color],
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                    ),
                    boxShadow: widget.isPlaying
                        ? [
                            BoxShadow(
                              color: color.withOpacity(0.3),
                              blurRadius: 4,
                              spreadRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                );
              },
            ),
          );
        }),
      );
    });
  }
}
