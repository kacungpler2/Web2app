import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';

class LyricsScreen extends StatelessWidget {
  const LyricsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(builder: (_, prov, __) {
      final song = prov.currentSong;
      if (song == null) return const SizedBox.shrink();

      return Scaffold(
        backgroundColor: AppTheme.bgDark,
        body: Container(
          decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
          child: SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.keyboard_arrow_down,
                            color: AppTheme.textSecondary, size: 28),
                        onPressed: () => Navigator.pop(context),
                      ),
                      Expanded(
                        child: Column(
                          children: [
                            Text(song.title,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: AppTheme.textPrimary,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                            Text(song.artist,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: AppTheme.textHint, fontSize: 12),
                                maxLines: 1),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.refresh,
                            color: AppTheme.primary, size: 22),
                        onPressed: () => prov.fetchLyricsAuto(song),
                        tooltip: 'Ambil ulang lirik',
                      ),
                    ],
                  ),
                ),

                const Divider(color: AppTheme.divider, height: 1),

                // Lyrics body
                Expanded(
                  child: prov.isFetchingLyrics
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(color: AppTheme.primary),
                              SizedBox(height: 16),
                              Text('Mengambil lirik otomatis...',
                                  style: TextStyle(
                                      color: AppTheme.textSecondary, fontSize: 14)),
                              SizedBox(height: 6),
                              Text('via LyricsOVH API',
                                  style: TextStyle(
                                      color: AppTheme.textHint, fontSize: 11)),
                            ],
                          ),
                        )
                      : song.lyrics != null && song.lyrics!.isNotEmpty
                          ? SingleChildScrollView(
                              padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    song.lyrics!,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: AppTheme.textPrimary,
                                      fontSize: 16,
                                      height: 1.8,
                                    ),
                                  ),
                                  const SizedBox(height: 24),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: AppTheme.bgSurface,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: const Text('Lirik dari LyricsOVH',
                                        style: TextStyle(
                                            color: AppTheme.textHint,
                                            fontSize: 11)),
                                  ),
                                ],
                              ),
                            )
                          : Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.lyrics_outlined,
                                      size: 64,
                                      color: AppTheme.textHint.withOpacity(0.3)),
                                  const SizedBox(height: 16),
                                  const Text('Lirik tidak ditemukan',
                                      style: TextStyle(
                                          color: AppTheme.textSecondary,
                                          fontSize: 16)),
                                  const SizedBox(height: 8),
                                  Text(
                                    '${song.title} - ${song.artist}',
                                    style: const TextStyle(
                                        color: AppTheme.textHint, fontSize: 12),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 20),
                                  ElevatedButton.icon(
                                    onPressed: () => prov.fetchLyricsAuto(song),
                                    icon: const Icon(Icons.search, size: 18),
                                    label: const Text('Cari Lirik Otomatis'),
                                  ),
                                ],
                              ),
                            ),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}
