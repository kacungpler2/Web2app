import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';

class EditSongScreen extends StatefulWidget {
  final Song song;
  const EditSongScreen({super.key, required this.song});

  @override
  State<EditSongScreen> createState() => _EditSongScreenState();
}

class _EditSongScreenState extends State<EditSongScreen> {
  late TextEditingController _titleCtrl;
  late TextEditingController _artistCtrl;
  late TextEditingController _albumCtrl;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.song.title);
    _artistCtrl = TextEditingController(text: widget.song.artist);
    _albumCtrl = TextEditingController(text: widget.song.album);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _artistCtrl.dispose();
    _albumCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_titleCtrl.text.trim().isEmpty) return;
    setState(() => _isSaving = true);
    await context.read<MusicProvider>().updateSongInfo(
          widget.song.id,
          _titleCtrl.text.trim(),
          _artistCtrl.text.trim(),
          _albumCtrl.text.trim(),
        );
    setState(() => _isSaving = false);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('Edit Info Lagu'),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: _isSaving
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppTheme.primary))
                : const Text('Simpan',
                    style: TextStyle(
                        color: AppTheme.primary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Album art preview
              Center(
                child: Container(
                  width: 120,
                  height: 120,
                  margin: const EdgeInsets.only(bottom: 28),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                          color: AppTheme.primary.withOpacity(0.2),
                          blurRadius: 20)
                    ],
                  ),
                  child: ClipOval(
                    child: widget.song.albumArt != null
                        ? Image.memory(widget.song.albumArt!, fit: BoxFit.cover)
                        : Container(
                            decoration:
                                const BoxDecoration(gradient: AppTheme.primaryGradient),
                            child: const Icon(Icons.music_note,
                                size: 50, color: Colors.white70),
                          ),
                  ),
                ),
              ),

              // Fields
              _buildField(
                controller: _titleCtrl,
                label: 'Judul Lagu',
                icon: Icons.music_note_outlined,
              ),
              const SizedBox(height: 16),
              _buildField(
                controller: _artistCtrl,
                label: 'Artis',
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 16),
              _buildField(
                controller: _albumCtrl,
                label: 'Album',
                icon: Icons.album_outlined,
              ),
              const SizedBox(height: 24),

              // File path (read-only)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.bgSurface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.divider),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.folder_outlined,
                        color: AppTheme.textHint, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        widget.song.path,
                        style: const TextStyle(
                            color: AppTheme.textHint, fontSize: 11),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Duration
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.bgSurface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.divider),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.timer_outlined,
                        color: AppTheme.textHint, size: 18),
                    const SizedBox(width: 8),
                    Text('Durasi: ${widget.song.durationString}',
                        style: const TextStyle(
                            color: AppTheme.textSecondary, fontSize: 13)),
                    const Spacer(),
                    Text('Diputar: ${widget.song.playCount}x',
                        style: const TextStyle(
                            color: AppTheme.textHint, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
  }) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: AppTheme.textPrimary),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
    );
  }
}
