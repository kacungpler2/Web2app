import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/song_tile.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(builder: (_, prov, __) {
      final songs = prov.favorites;
      return Scaffold(
        backgroundColor: Colors.transparent,
        body: Container(
          decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
          child: CustomScrollView(
            slivers: [
              SliverAppBar(
                pinned: true,
                backgroundColor: AppTheme.bgDark,
                title: Row(
                  children: [
                    const Icon(Icons.favorite, color: Colors.redAccent, size: 22),
                    const SizedBox(width: 8),
                    Text('Favorit (${songs.length})',
                        style: const TextStyle(color: AppTheme.textPrimary)),
                  ],
                ),
                actions: [
                  if (songs.isNotEmpty)
                    TextButton.icon(
                      onPressed: () => prov.playSong(songs.first, songList: songs),
                      icon: const Icon(Icons.play_arrow, color: AppTheme.primary),
                      label: const Text('Putar Semua',
                          style: TextStyle(color: AppTheme.primary)),
                    ),
                ],
              ),
              if (songs.isEmpty)
                SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.favorite_outline,
                            size: 80,
                            color: AppTheme.textHint.withOpacity(0.3)),
                        const SizedBox(height: 16),
                        const Text('Belum ada favorit',
                            style: TextStyle(
                                color: AppTheme.textSecondary, fontSize: 16)),
                        const SizedBox(height: 8),
                        const Text('Tekan ❤ pada lagu untuk menambahkan',
                            style: TextStyle(
                                color: AppTheme.textHint, fontSize: 12)),
                      ],
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.only(bottom: 100),
                  sliver: AnimationLimiter(
                    child: SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (ctx, i) => AnimationConfiguration.staggeredList(
                          position: i,
                          duration: const Duration(milliseconds: 350),
                          child: SlideAnimation(
                            horizontalOffset: 50,
                            child: FadeInAnimation(
                              child: SongTile(song: songs[i], songList: songs),
                            ),
                          ),
                        ),
                        childCount: songs.length,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }
}
