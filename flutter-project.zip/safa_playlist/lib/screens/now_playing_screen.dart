import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/music_visualizer.dart';
import 'lyrics_screen.dart';

class NowPlayingScreen extends StatefulWidget {
  const NowPlayingScreen({super.key});
  @override
  State<NowPlayingScreen> createState() => _NowPlayingScreenState();
}

class _NowPlayingScreenState extends State<NowPlayingScreen>
    with TickerProviderStateMixin {
  late AnimationController _rotateController;
  late AnimationController _pulseController;
  late Animation<double> _pulse;
  bool _showVisualizer = true;

  @override
  void initState() {
    super.initState();
    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: 1.0, end: 1.05).animate(
        CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _rotateController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(builder: (_, prov, __) {
      final song = prov.currentSong;
      if (song == null) return const SizedBox.shrink();

      // Sync rotation with playback
      if (prov.isPlaying) {
        _rotateController.repeat();
        _pulseController.repeat(reverse: true);
      } else {
        _rotateController.stop();
        _pulseController.stop();
      }

      return Scaffold(
        backgroundColor: AppTheme.bgDark,
        body: Container(
          decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
          child: SafeArea(
            child: Column(
              children: [
                // AppBar row
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.keyboard_arrow_down,
                            color: AppTheme.textSecondary, size: 28),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Expanded(
                        child: Text('Sedang Diputar',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 13,
                                letterSpacing: 1)),
                      ),
                      IconButton(
                        icon: Icon(
                          _showVisualizer
                              ? Icons.equalizer
                              : Icons.equalizer_outlined,
                          color: _showVisualizer
                              ? AppTheme.primary
                              : AppTheme.textSecondary,
                        ),
                        onPressed: () =>
                            setState(() => _showVisualizer = !_showVisualizer),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Album Art
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: AnimatedBuilder(
                    animation: _pulse,
                    builder: (_, child) => Transform.scale(
                      scale: prov.isPlaying ? _pulse.value : 1.0,
                      child: child,
                    ),
                    child: Container(
                      width: 240,
                      height: 240,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primary.withOpacity(0.3),
                            blurRadius: 30,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: AnimatedBuilder(
                        animation: _rotateController,
                        builder: (_, child) => Transform.rotate(
                          angle: prov.isPlaying
                              ? _rotateController.value * 2 * 3.14159
                              : 0,
                          child: child,
                        ),
                        child: ClipOval(
                          child: song.albumArt != null
                              ? Image.memory(song.albumArt!,
                                  fit: BoxFit.cover)
                              : Container(
                                  decoration: const BoxDecoration(
                                    gradient: AppTheme.primaryGradient,
                                  ),
                                  child: const Icon(Icons.music_note,
                                      size: 80, color: Colors.white70),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // Visualizer
                if (_showVisualizer && prov.isPlaying)
                  SizedBox(
                    height: 60,
                    child: MusicVisualizer(isPlaying: prov.isPlaying),
                  ),
                if (!_showVisualizer || !prov.isPlaying)
                  const SizedBox(height: 12),

                // Song info + favorite
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              song.title,
                              style: const TextStyle(
                                color: AppTheme.textPrimary,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              song.artist,
                              style: const TextStyle(
                                  color: AppTheme.textSecondary, fontSize: 14),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: IconButton(
                          key: ValueKey(song.isFavorite),
                          icon: Icon(
                            song.isFavorite
                                ? Icons.favorite
                                : Icons.favorite_outline,
                            color: song.isFavorite
                                ? Colors.redAccent
                                : AppTheme.textHint,
                            size: 28,
                          ),
                          onPressed: () => prov.toggleFavorite(song.id),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Progress slider
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          trackHeight: 3,
                          thumbShape: const RoundSliderThumbShape(
                              enabledThumbRadius: 6),
                          overlayShape: const RoundSliderOverlayShape(
                              overlayRadius: 14),
                        ),
                        child: Slider(
                          value: prov.progress.clamp(0.0, 1.0),
                          onChanged: (v) => prov.seek(Duration(
                              milliseconds:
                                  (v * prov.duration.inMilliseconds).toInt())),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_formatDuration(prov.position),
                                style: const TextStyle(
                                    color: AppTheme.textHint, fontSize: 12)),
                            Text(_formatDuration(prov.duration),
                                style: const TextStyle(
                                    color: AppTheme.textHint, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // Controls
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Shuffle
                      IconButton(
                        icon: Icon(
                          Icons.shuffle,
                          color: prov.isShuffle
                              ? AppTheme.primary
                              : AppTheme.textHint,
                          size: 24,
                        ),
                        onPressed: prov.toggleShuffle,
                      ),
                      // Previous
                      IconButton(
                        icon: const Icon(Icons.skip_previous,
                            color: AppTheme.textPrimary, size: 36),
                        onPressed: prov.playPrevious,
                      ),
                      // Play/Pause
                      GestureDetector(
                        onTap: prov.togglePlayPause,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 68,
                          height: 68,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: AppTheme.primaryGradient,
                            boxShadow: [
                              BoxShadow(
                                color: AppTheme.primary.withOpacity(0.4),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Icon(
                            prov.isPlaying
                                ? Icons.pause
                                : Icons.play_arrow,
                            color: AppTheme.bgDark,
                            size: 36,
                          ),
                        ),
                      ),
                      // Next
                      IconButton(
                        icon: const Icon(Icons.skip_next,
                            color: AppTheme.textPrimary, size: 36),
                        onPressed: prov.playNext,
                      ),
                      // ✅ PERBAIKAN DI SINI:
                      // Repeat
                      IconButton(
                        icon: Icon(
                          prov.repeatMode == RepeatModeType.one
                              ? Icons.repeat_one
                              : Icons.repeat,
                          color: prov.repeatMode != RepeatModeType.off
                              ? AppTheme.primary
                              : AppTheme.textHint,
                          size: 24,
                        ),
                        onPressed: prov.toggleRepeat,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Lyrics button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const LyricsScreen())),
                        icon: prov.isFetchingLyrics
                            ? const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: AppTheme.primary))
                            : const Icon(Icons.lyrics_outlined, size: 16),
                        label: Text(
                          prov.isFetchingLyrics
                              ? 'Mengambil lirik...'
                              : 'Lihat Lirik',
                          style: const TextStyle(fontSize: 13),
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppTheme.primary,
                          side: const BorderSide(color: AppTheme.primary),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      );
    });
  }
}