import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/song_tile.dart';
import 'contact_screen.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(
      builder: (context, prov, _) {
        final songs = prov.allSongs;
        return Scaffold(
          backgroundColor: Colors.transparent,
          body: Container(
            decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  pinned: true,
                  expandedHeight: 140,
                  backgroundColor: AppTheme.bgDark,
                  flexibleSpace: FlexibleSpaceBar(
                    titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
                    title: Row(
                      children: [
                        ClipOval(
                          child: Image.asset(
                            'assets/images/logo_dragon.jpg',
                            width: 32,
                            height: 32,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ShaderMask(
                              shaderCallback: (b) =>
                                  AppTheme.primaryGradient.createShader(b),
                              child: const Text(
                                'SAFA PLAYLIST',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                            Text(
                              '${songs.length} lagu',
                              style: const TextStyle(
                                color: AppTheme.textHint,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    background: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primaryDeep, AppTheme.bgDark],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                  ),
                  actions: [
                    // Sort button
                    PopupMenuButton<SortMode>(
                      icon: const Icon(Icons.sort, color: AppTheme.primary),
                      color: AppTheme.bgSurface,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      onSelected: prov.setSortMode,
                      itemBuilder: (_) => [
                        _sortItem(SortMode.title, Icons.sort_by_alpha, 'A-Z Judul', prov.sortMode),
                        _sortItem(SortMode.artist, Icons.person_outline, 'Artis', prov.sortMode),
                        _sortItem(SortMode.duration, Icons.timer_outlined, 'Durasi', prov.sortMode),
                        _sortItem(SortMode.recent, Icons.access_time, 'Terbaru', prov.sortMode),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.info_outline, color: AppTheme.textHint),
                      onPressed: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => const ContactScreen())),
                    ),
                  ],
                ),
                if (prov.isLoading)
                  const SliverFillRemaining(
                    child: Center(
                      child: CircularProgressIndicator(
                          color: AppTheme.primary),
                    ),
                  )
                else if (songs.isEmpty)
                  SliverFillRemaining(
                    child: _emptyState(context, prov),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.only(bottom: 100),
                    sliver: AnimationLimiter(
                      child: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (ctx, i) => AnimationConfiguration.staggeredList(
                            position: i,
                            duration: const Duration(milliseconds: 375),
                            child: SlideAnimation(
                              verticalOffset: 50.0,
                              child: FadeInAnimation(
                                child: SongTile(
                                  song: songs[i],
                                  songList: songs,
                                ),
                              ),
                            ),
                          ),
                          childCount: songs.length,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  PopupMenuItem<SortMode> _sortItem(
      SortMode mode, IconData icon, String label, SortMode current) {
    return PopupMenuItem(
      value: mode,
      child: Row(
        children: [
          Icon(icon,
              color: current == mode ? AppTheme.primary : AppTheme.textHint,
              size: 18),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: current == mode
                      ? AppTheme.primary
                      : AppTheme.textPrimary)),
          if (current == mode) ...[
            const Spacer(),
            const Icon(Icons.check, color: AppTheme.primary, size: 16),
          ],
        ],
      ),
    );
  }

  Widget _emptyState(BuildContext context, MusicProvider prov) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.music_off,
              size: 80, color: AppTheme.textHint.withOpacity(0.5)),
          const SizedBox(height: 16),
          const Text('Belum ada lagu',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 18)),
          const SizedBox(height: 8),
          const Text('Izinkan akses ke penyimpanan HP',
              style: TextStyle(color: AppTheme.textHint, fontSize: 13)),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => prov.loadSongs(),
            icon: const Icon(Icons.refresh),
            label: const Text('Muat Ulang'),
          ),
        ],
      ),
    );
  }
}
