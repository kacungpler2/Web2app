import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/playlist.dart';
import '../providers/music_provider.dart';
import '../providers/playlist_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/song_tile.dart';

class PlaylistDetailScreen extends StatelessWidget {
  final Playlist playlist;
  const PlaylistDetailScreen({super.key, required this.playlist});

  @override
  Widget build(BuildContext context) {
    return Consumer2<MusicProvider, PlaylistProvider>(
      builder: (_, musicProv, playlistProv, __) {
        final pl = playlistProv.playlists
            .firstWhere((p) => p.id == playlist.id, orElse: () => playlist);
        final songs = pl.songIds
            .map((id) => musicProv.getSongById(id))
            .where((s) => s != null)
            .map((s) => s!)
            .toList();

        return Scaffold(
          backgroundColor: AppTheme.bgDark,
          body: Container(
            decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  expandedHeight: 220,
                  pinned: true,
                  backgroundColor: AppTheme.bgDark,
                  flexibleSpace: FlexibleSpaceBar(
                    title: Text(pl.name,
                        style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.bold)),
                    background: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primaryDark, AppTheme.bgDark],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                      child: Center(
                        child: songs.isEmpty
                            ? Icon(Icons.queue_music,
                                size: 80,
                                color: AppTheme.primary.withOpacity(0.4))
                            : songs.first.albumArt != null
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(16),
                                    child: Image.memory(songs.first.albumArt!,
                                        width: 120,
                                        height: 120,
                                        fit: BoxFit.cover))
                                : Icon(Icons.queue_music,
                                    size: 80,
                                    color: AppTheme.primary.withOpacity(0.4)),
                      ),
                    ),
                  ),
                  actions: [
                    IconButton(
                      icon: const Icon(Icons.share_outlined,
                          color: AppTheme.primary),
                      onPressed: () => _sharePlaylist(songs, pl),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add, color: AppTheme.primary),
                      onPressed: () =>
                          _showAddSongDialog(context, musicProv, playlistProv, pl.id),
                    ),
                  ],
                ),
                // Info row
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    child: Row(
                      children: [
                        Text('${songs.length} lagu',
                            style: const TextStyle(
                                color: AppTheme.textHint, fontSize: 13)),
                        const Spacer(),
                        if (songs.isNotEmpty)
                          ElevatedButton.icon(
                            onPressed: () => musicProv.playSong(songs.first,
                                songList: songs),
                            icon: const Icon(Icons.play_arrow, size: 18),
                            label: const Text('Putar Semua'),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                if (songs.isEmpty)
                  SliverFillRemaining(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.music_note_outlined,
                              size: 64,
                              color: AppTheme.textHint.withOpacity(0.3)),
                          const SizedBox(height: 12),
                          const Text('Playlist masih kosong',
                              style: TextStyle(
                                  color: AppTheme.textHint, fontSize: 14)),
                          const SizedBox(height: 16),
                          ElevatedButton.icon(
                            onPressed: () => _showAddSongDialog(
                                context, musicProv, playlistProv, pl.id),
                            icon: const Icon(Icons.add),
                            label: const Text('Tambah Lagu'),
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.only(bottom: 100),
                    sliver: AnimationLimiter(
                      child: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (ctx, i) => AnimationConfiguration.staggeredList(
                            position: i,
                            duration: const Duration(milliseconds: 300),
                            child: SlideAnimation(
                              verticalOffset: 30,
                              child: FadeInAnimation(
                                child: Dismissible(
                                  key: Key(songs[i].id),
                                  direction: DismissDirection.endToStart,
                                  background: Container(
                                    alignment: Alignment.centerRight,
                                    padding: const EdgeInsets.only(right: 20),
                                    color: AppTheme.error.withOpacity(0.8),
                                    child: const Icon(Icons.delete_outline,
                                        color: Colors.white),
                                  ),
                                  onDismissed: (_) => playlistProv
                                      .removeSongFromPlaylist(pl.id, songs[i].id),
                                  child: SongTile(
                                      song: songs[i], songList: songs),
                                ),
                              ),
                            ),
                          ),
                          childCount: songs.length,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _sharePlaylist(List songs, Playlist pl) {
    final buffer = StringBuffer();
    buffer.writeln('🎵 Playlist: ${pl.name}');
    buffer.writeln('Dari SAFA PLAYLIST LAGU\n');
    for (var s in songs) {
      buffer.writeln('• ${s.title} - ${s.artist}');
    }
    buffer.writeln('\nTeam Safa Audio • Sepele Tiap Singkal 🐉');
    Share.share(buffer.toString());
  }

  void _showAddSongDialog(BuildContext context, MusicProvider musicProv,
      PlaylistProvider playlistProv, String playlistId) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgSurface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(builder: (ctx, setS) {
        var filtered = musicProv.allSongs;
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.85,
          builder: (_, scrollCtrl) => Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: TextField(
                  controller: ctrl,
                  style: const TextStyle(color: AppTheme.textPrimary),
                  decoration:
                      const InputDecoration(hintText: 'Cari lagu...'),
                  onChanged: (v) => setS(() {
                    filtered = musicProv.allSongs
                        .where((s) =>
                            s.title.toLowerCase().contains(v.toLowerCase()) ||
                            s.artist.toLowerCase().contains(v.toLowerCase()))
                        .toList();
                  }),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  controller: scrollCtrl,
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final inPl = playlistProv
                        .isSongInPlaylist(playlistId, filtered[i].id);
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: AppTheme.bgElevated,
                        child: filtered[i].albumArt != null
                            ? ClipOval(
                                child: Image.memory(filtered[i].albumArt!,
                                    fit: BoxFit.cover))
                            : const Icon(Icons.music_note,
                                color: AppTheme.primary, size: 18),
                      ),
                      title: Text(filtered[i].title,
                          style:
                              const TextStyle(color: AppTheme.textPrimary),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      subtitle: Text(filtered[i].artist,
                          style:
                              const TextStyle(color: AppTheme.textHint),
                          maxLines: 1),
                      trailing: Icon(
                        inPl ? Icons.check_circle : Icons.add_circle_outline,
                        color: inPl ? AppTheme.success : AppTheme.primary,
                      ),
                      onTap: () {
                        if (inPl) {
                          playlistProv.removeSongFromPlaylist(
                              playlistId, filtered[i].id);
                        } else {
                          playlistProv.addSongToPlaylist(
                              playlistId, filtered[i].id);
                        }
                        setS(() {});
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
