import 'dart:typed_data';

class Song {
  final String id;
  String title;
  String artist;
  String album;
  final String path;
  final Duration duration;
  Uint8List? albumArt;
  String? lyrics;
  bool isFavorite;
  DateTime? lastPlayed;
  int playCount;

  Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.path,
    required this.duration,
    this.albumArt,
    this.lyrics,
    this.isFavorite = false,
    this.lastPlayed,
    this.playCount = 0,
  });

  String get durationString {
    final m = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'path': path,
        'durationMs': duration.inMilliseconds,
        'lyrics': lyrics,
        'isFavorite': isFavorite,
        'lastPlayed': lastPlayed?.toIso8601String(),
        'playCount': playCount,
      };

  factory Song.fromJson(Map<String, dynamic> json) => Song(
        id: json['id'],
        title: json['title'],
        artist: json['artist'],
        album: json['album'] ?? 'Unknown Album',
        path: json['path'],
        duration: Duration(milliseconds: json['durationMs'] ?? 0),
        lyrics: json['lyrics'],
        isFavorite: json['isFavorite'] ?? false,
        lastPlayed: json['lastPlayed'] != null
            ? DateTime.parse(json['lastPlayed'])
            : null,
        playCount: json['playCount'] ?? 0,
      );

  Song copyWith({
    String? title,
    String? artist,
    String? album,
    String? lyrics,
    bool? isFavorite,
    Uint8List? albumArt,
    DateTime? lastPlayed,
    int? playCount,
  }) {
    return Song(
      id: id,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      album: album ?? this.album,
      path: path,
      duration: duration,
      albumArt: albumArt ?? this.albumArt,
      lyrics: lyrics ?? this.lyrics,
      isFavorite: isFavorite ?? this.isFavorite,
      lastPlayed: lastPlayed ?? this.lastPlayed,
      playCount: playCount ?? this.playCount,
    );
  }
}
