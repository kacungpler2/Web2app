class Playlist {
  final String id;
  String name;
  String? description;
  List<String> songIds;
  DateTime createdAt;
  String? coverPath;

  Playlist({
    required this.id,
    required this.name,
    this.description,
    List<String>? songIds,
    DateTime? createdAt,
    this.coverPath,
  })  : songIds = songIds ?? [],
        createdAt = createdAt ?? DateTime.now();

  int get songCount => songIds.length;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'songIds': songIds,
        'createdAt': createdAt.toIso8601String(),
        'coverPath': coverPath,
      };

  factory Playlist.fromJson(Map<String, dynamic> json) => Playlist(
        id: json['id'],
        name: json['name'],
        description: json['description'],
        songIds: List<String>.from(json['songIds'] ?? []),
        createdAt: json['createdAt'] != null
            ? DateTime.parse(json['createdAt'])
            : DateTime.now(),
        coverPath: json['coverPath'],
      );

  Playlist copyWith({
    String? name,
    String? description,
    List<String>? songIds,
    String? coverPath,
  }) {
    return Playlist(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      songIds: songIds ?? List.from(this.songIds),
      createdAt: createdAt,
      coverPath: coverPath ?? this.coverPath,
    );
  }
}
