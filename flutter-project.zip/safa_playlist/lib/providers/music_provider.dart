import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../models/song.dart';

// HAPUS enum RepeatMode dari sini - pindahkan ke file terpisah atau gunakan nama berbeda
// Buat file baru: lib/models/repeat_mode.dart
// Atau gunakan nama: enum RepeatModeType { off, one, all }

// OPSI 1: Buat enum dengan nama berbeda untuk menghindari konflik
enum RepeatModeType { off, one, all }

// OPSI 2: Gunakan ini jika ingin tetap pakai nama RepeatMode
// Tapi tambahkan di file baru dan export
enum SortMode { title, artist, duration, recent }

class MusicProvider extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  final OnAudioQuery _audioQuery = OnAudioQuery();

  List<Song> _allSongs = [];
  List<Song> _filteredSongs = [];
  List<Song> _queue = [];
  List<Song> _history = [];
  List<String> _savedHistoryIds = [];
  Song? _currentSong;
  bool _isPlaying = false;
  bool _isShuffle = false;
  
  // Gunakan RepeatModeType bukan RepeatMode
  RepeatModeType _repeatMode = RepeatModeType.off;
  SortMode _sortMode = SortMode.title;
  
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _isLoading = false;
  String _searchQuery = '';
  String? _loadingLyrics;
  bool _isFetchingLyrics = false;

  // Getters
  List<Song> get allSongs => _filteredSongs.isEmpty && _searchQuery.isEmpty
      ? _allSongs
      : _filteredSongs;
  List<Song> get queue => _queue;
  List<Song> get history => _history;
  List<Song> get favorites =>
      _allSongs.where((s) => s.isFavorite).toList();
  Song? get currentSong => _currentSong;
  bool get isPlaying => _isPlaying;
  bool get isShuffle => _isShuffle;
  
  // Ubah tipe return menjadi RepeatModeType
  RepeatModeType get repeatMode => _repeatMode;
  SortMode get sortMode => _sortMode;
  Duration get position => _position;
  Duration get duration => _duration;
  bool get isLoading => _isLoading;
  bool get isFetchingLyrics => _isFetchingLyrics;
  AudioPlayer get player => _player;

  double get progress {
    if (_duration.inMilliseconds == 0) return 0;
    return _position.inMilliseconds / _duration.inMilliseconds;
  }

  MusicProvider() {
    _init();
  }

  Future<void> _init() async {
    await _loadSavedData();
    _setupPlayerListeners();
  }

  void _setupPlayerListeners() {
    _player.positionStream.listen((pos) {
      _position = pos;
      notifyListeners();
    });

    _player.durationStream.listen((dur) {
      if (dur != null) {
        _duration = dur;
        notifyListeners();
      }
    });

    _player.playerStateStream.listen((state) {
      _isPlaying = state.playing;
      if (state.processingState == ProcessingState.completed) {
        _onSongCompleted();
      }
      notifyListeners();
    });
  }

  Future<void> loadSongs() async {
    _isLoading = true;
    notifyListeners();

    try {
      bool hasPermission = await _audioQuery.permissionsStatus();
      if (!hasPermission) {
        await _audioQuery.permissionsRequest();
      }

      final queriedSongs = await _audioQuery.querySongs(
        sortType: SongSortType.TITLE,
        orderType: OrderType.ASC_OR_SMALLER,
        uriType: UriType.EXTERNAL,
        ignoreCase: true,
      );

      final prefs = await SharedPreferences.getInstance();
      final savedData = prefs.getString('songs_data');
      Map<String, dynamic> savedMap = {};
      if (savedData != null) {
        savedMap = json.decode(savedData) as Map<String, dynamic>;
      }

      _allSongs = queriedSongs
          .where((s) => s.duration != null && s.duration! > 30000)
          .map((s) {
        final saved = savedMap[s.id.toString()];
        return Song(
          id: s.id.toString(),
          title: saved?['title'] ?? s.title,
          artist: saved?['artist'] ?? (s.artist ?? 'Unknown Artist'),
          album: saved?['album'] ?? (s.album ?? 'Unknown Album'),
          path: s.data,
          duration: Duration(milliseconds: s.duration ?? 0),
          lyrics: saved?['lyrics'],
          isFavorite: saved?['isFavorite'] ?? false,
          lastPlayed: saved?['lastPlayed'] != null
              ? DateTime.parse(saved!['lastPlayed'])
              : null,
          playCount: saved?['playCount'] ?? 0,
        );
      }).toList();

      // Load album art
      for (var song in _allSongs) {
        final artBytes = await _audioQuery.queryArtwork(
          int.parse(song.id),
          ArtworkType.AUDIO,
          quality: 100,
          size: 300,
        );
        song.albumArt = artBytes;
      }

      _applySorting();

      // Restore play history now that songs are available
      if (_savedHistoryIds.isNotEmpty) {
        _history = _savedHistoryIds
            .map((id) => getSongById(id))
            .where((s) => s != null)
            .map((s) => s!)
            .toList();
      }
    } catch (e) {
      debugPrint('Error loading songs: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  void search(String query) {
    _searchQuery = query;
    if (query.isEmpty) {
      _filteredSongs = [];
    } else {
      _filteredSongs = _allSongs.where((s) {
        return s.title.toLowerCase().contains(query.toLowerCase()) ||
            s.artist.toLowerCase().contains(query.toLowerCase()) ||
            s.album.toLowerCase().contains(query.toLowerCase());
      }).toList();
    }
    notifyListeners();
  }

  void setSortMode(SortMode mode) {
    _sortMode = mode;
    _applySorting();
    notifyListeners();
  }

  void _applySorting() {
    switch (_sortMode) {
      case SortMode.title:
        _allSongs.sort(
            (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
        break;
      case SortMode.artist:
        _allSongs.sort((a, b) =>
            a.artist.toLowerCase().compareTo(b.artist.toLowerCase()));
        break;
      case SortMode.duration:
        _allSongs.sort(
            (a, b) => a.duration.inSeconds.compareTo(b.duration.inSeconds));
        break;
      case SortMode.recent:
        _allSongs.sort((a, b) {
          if (a.lastPlayed == null && b.lastPlayed == null) return 0;
          if (a.lastPlayed == null) return 1;
          if (b.lastPlayed == null) return -1;
          return b.lastPlayed!.compareTo(a.lastPlayed!);
        });
        break;
    }
  }

  Future<void> playSong(Song song, {List<Song>? songList}) async {
    _currentSong = song;

    if (songList != null) {
      _queue = List.from(songList);
    }

    try {
      await _player.setAudioSource(
        AudioSource.uri(
          Uri.parse(song.path),
          tag: MediaItem(
            id: song.id,
            title: song.title,
            artist: song.artist,
            album: song.album,
            artUri: song.albumArt != null
                ? Uri.dataFromBytes(song.albumArt!,
                    mimeType: 'image/jpeg')
                : null,
          ),
        ),
      );
      await _player.play();

      // Update history & play count
      _addToHistory(song);
      final idx = _allSongs.indexWhere((s) => s.id == song.id);
      if (idx != -1) {
        _allSongs[idx].playCount++;
        _allSongs[idx].lastPlayed = DateTime.now();
      }

      await _saveData();

      // Auto-fetch lyrics
      if (song.lyrics == null || song.lyrics!.isEmpty) {
        fetchLyricsAuto(song);
      }
    } catch (e) {
      debugPrint('Error playing song: $e');
    }

    notifyListeners();
  }

  Future<void> togglePlayPause() async {
    if (_isPlaying) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }

  Future<void> seekBySeconds(int seconds) async {
    final newPos = _position + Duration(seconds: seconds);
    await _player.seek(newPos.isNegative ? Duration.zero : newPos);
  }

  Future<void> playNext() async {
    if (_queue.isEmpty || _currentSong == null) return;
    final idx = _queue.indexWhere((s) => s.id == _currentSong!.id);
    if (idx == -1 || idx >= _queue.length - 1) return;

    if (_isShuffle) {
      final random =
          _queue[DateTime.now().millisecondsSinceEpoch % _queue.length];
      await playSong(random);
    } else {
      await playSong(_queue[idx + 1]);
    }
  }

  Future<void> playPrevious() async {
    if (_position.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    if (_queue.isEmpty || _currentSong == null) return;
    final idx = _queue.indexWhere((s) => s.id == _currentSong!.id);
    if (idx <= 0) return;
    await playSong(_queue[idx - 1]);
  }

  // PERBAIKAN: Ganti RepeatMode menjadi RepeatModeType
  void _onSongCompleted() {
    switch (_repeatMode) {
      case RepeatModeType.one:
        _player.seek(Duration.zero);
        _player.play();
        break;
      case RepeatModeType.all:
        playNext();
        break;
      case RepeatModeType.off:
        if (_queue.isNotEmpty && _currentSong != null) {
          final idx = _queue.indexWhere((s) => s.id == _currentSong!.id);
          if (idx < _queue.length - 1) playNext();
        }
        break;
    }
  }

  void toggleShuffle() {
    _isShuffle = !_isShuffle;
    notifyListeners();
  }

  // PERBAIKAN: Ganti RepeatMode menjadi RepeatModeType
  void toggleRepeat() {
    _repeatMode = RepeatModeType
        .values[(_repeatMode.index + 1) % RepeatModeType.values.length];
    notifyListeners();
  }

  void toggleFavorite(String songId) {
    final idx = _allSongs.indexWhere((s) => s.id == songId);
    if (idx != -1) {
      _allSongs[idx].isFavorite = !_allSongs[idx].isFavorite;
      if (_currentSong?.id == songId) {
        _currentSong = _allSongs[idx];
      }
      _saveData();
      notifyListeners();
    }
  }

  void _addToHistory(Song song) {
    _history.removeWhere((s) => s.id == song.id);
    _history.insert(0, song);
    if (_history.length > 50) _history.removeLast();
  }

  void clearHistory() {
    _history.clear();
    notifyListeners();
    _saveData();
  }

  Future<void> updateSongInfo(
      String songId, String title, String artist, String album) async {
    final idx = _allSongs.indexWhere((s) => s.id == songId);
    if (idx != -1) {
      _allSongs[idx].title = title;
      _allSongs[idx].artist = artist;
      _allSongs[idx].album = album;
      if (_currentSong?.id == songId) {
        _currentSong = _allSongs[idx];
      }
      await _saveData();
      notifyListeners();
    }
  }

  Future<void> saveLyrics(String songId, String lyrics) async {
    final idx = _allSongs.indexWhere((s) => s.id == songId);
    if (idx != -1) {
      _allSongs[idx].lyrics = lyrics;
      if (_currentSong?.id == songId) {
        _currentSong = _allSongs[idx];
      }
      await _saveData();
      notifyListeners();
    }
  }

  // === AUTO LYRICS FETCH ===
  Future<void> fetchLyricsAuto(Song song) async {
    _isFetchingLyrics = true;
    notifyListeners();

    try {
      // Primary: LyricsOVH
      final artist = Uri.encodeComponent(song.artist);
      final title = Uri.encodeComponent(song.title);
      final url =
          Uri.parse('https://api.lyrics.ovh/v1/$artist/$title');

      final response =
          await http.get(url).timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['lyrics'] != null && (data['lyrics'] as String).isNotEmpty) {
          await saveLyrics(song.id, data['lyrics']);
          _isFetchingLyrics = false;
          notifyListeners();
          return;
        }
      }

      // Fallback: try cleaned title (remove feat., remix, etc.)
      String cleanTitle = song.title
          .replaceAll(RegExp(r'\(.*?\)'), '')
          .replaceAll(RegExp(r'\[.*?\]'), '')
          .trim();
      if (cleanTitle != song.title) {
        final cleanTitleEnc = Uri.encodeComponent(cleanTitle);
        final url2 =
            Uri.parse('https://api.lyrics.ovh/v1/$artist/$cleanTitleEnc');
        final response2 =
            await http.get(url2).timeout(const Duration(seconds: 8));
        if (response2.statusCode == 200) {
          final data2 = json.decode(response2.body);
          if (data2['lyrics'] != null &&
              (data2['lyrics'] as String).isNotEmpty) {
            await saveLyrics(song.id, data2['lyrics']);
            _isFetchingLyrics = false;
            notifyListeners();
            return;
          }
        }
      }
    } catch (e) {
      debugPrint('Lyrics fetch error: $e');
    }

    _isFetchingLyrics = false;
    notifyListeners();
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    final map = <String, dynamic>{};
    for (final song in _allSongs) {
      map[song.id] = {
        'title': song.title,
        'artist': song.artist,
        'album': song.album,
        'lyrics': song.lyrics,
        'isFavorite': song.isFavorite,
        'lastPlayed': song.lastPlayed?.toIso8601String(),
        'playCount': song.playCount,
      };
    }
    await prefs.setString('songs_data', json.encode(map));

    final historyIds = _history.map((s) => s.id).toList();
    await prefs.setStringList('history_ids', historyIds);
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    // Will be populated after songs are loaded
    _savedHistoryIds = prefs.getStringList('history_ids') ?? [];
  }

  Song? getSongById(String id) {
    try {
      return _allSongs.firstWhere((s) => s.id == id);
    } catch (_) {
      return null;
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}