import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/playlist.dart';

class PlaylistProvider extends ChangeNotifier {
  List<Playlist> _playlists = [];
  final _uuid = const Uuid();

  List<Playlist> get playlists => _playlists;

  PlaylistProvider() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('playlists');
    if (data != null) {
      final list = json.decode(data) as List;
      _playlists = list.map((e) => Playlist.fromJson(e)).toList();
      notifyListeners();
    }
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'playlists', json.encode(_playlists.map((p) => p.toJson()).toList()));
  }

  Future<Playlist> createPlaylist(String name, {String? description}) async {
    final playlist = Playlist(
      id: _uuid.v4(),
      name: name,
      description: description,
    );
    _playlists.add(playlist);
    await _save();
    notifyListeners();
    return playlist;
  }

  Future<void> updatePlaylist(String id, String name,
      {String? description}) async {
    final idx = _playlists.indexWhere((p) => p.id == id);
    if (idx != -1) {
      _playlists[idx].name = name;
      _playlists[idx].description = description;
      await _save();
      notifyListeners();
    }
  }

  Future<void> deletePlaylist(String id) async {
    _playlists.removeWhere((p) => p.id == id);
    await _save();
    notifyListeners();
  }

  Future<void> addSongToPlaylist(String playlistId, String songId) async {
    final idx = _playlists.indexWhere((p) => p.id == playlistId);
    if (idx != -1 && !_playlists[idx].songIds.contains(songId)) {
      _playlists[idx].songIds.add(songId);
      await _save();
      notifyListeners();
    }
  }

  Future<void> removeSongFromPlaylist(
      String playlistId, String songId) async {
    final idx = _playlists.indexWhere((p) => p.id == playlistId);
    if (idx != -1) {
      _playlists[idx].songIds.remove(songId);
      await _save();
      notifyListeners();
    }
  }

  Future<void> reorderSongs(
      String playlistId, int oldIndex, int newIndex) async {
    final idx = _playlists.indexWhere((p) => p.id == playlistId);
    if (idx != -1) {
      final songs = _playlists[idx].songIds;
      final item = songs.removeAt(oldIndex);
      songs.insert(newIndex, item);
      await _save();
      notifyListeners();
    }
  }

  bool isSongInPlaylist(String playlistId, String songId) {
    final playlist = _playlists.firstWhere(
      (p) => p.id == playlistId,
      orElse: () => Playlist(id: '', name: ''),
    );
    return playlist.songIds.contains(songId);
  }

  List<Playlist> getPlaylistsContainingSong(String songId) {
    return _playlists.where((p) => p.songIds.contains(songId)).toList();
  }
}
