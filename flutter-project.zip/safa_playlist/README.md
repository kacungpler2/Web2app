# 🐉 SAFA PLAYLIST LAGU

**Aplikasi pemutar musik Android untuk SAFA PRO AUDIO**  
*Team Sepele Tiap Singkal — Tebuwung Dukun Gresik*

---

## ✨ Fitur Lengkap

| Fitur | Keterangan |
|-------|-----------|
| 🎵 Import Lagu | Otomatis baca semua lagu dari HP |
| 📋 Playlist CRUD | Buat, edit, hapus, isi playlist |
| 🔍 Cari Lagu | Cari berdasarkan judul / artis / album |
| ❤️ Favorit | Tandai lagu favorit |
| 🎵 Queue & Now Playing | Antrian lagu + screen player keren |
| 🔀 Shuffle & Repeat | Mode acak + ulang sekali/semua |
| 🕘 Riwayat | 50 lagu terakhir yang diputar |
| 🖼️ Album Art | Otomatis dari file lagu |
| 🎤 Lirik Otomatis | Fetch dari LyricsOVH API (gratis) |
| 🌀 Visualizer | Animasi bars 32 kolom saat memutar |
| ✏️ Edit Info Lagu | Edit judul, artis, album |
| 🔤 Urutkan | A-Z, Artis, Durasi, Terbaru |
| 🔒 Lock Screen | Kontrol musik di notifikasi & lock screen |
| 🔗 Share | Bagikan playlist ke teman |
| 📱 Background Play | Musik terus jalan meski HP dikunci |
| 📞 Kontak | TikTok ×2, Instagram ×2, YouTube ×1 |

---

## 🎨 Tema

**Biru Nagaa** — Dark theme dengan warna biru cyan (#00B4D8) terinspirasi dari naga biru logo Team Safa Audio.

---

## 🚀 Cara Install & Jalankan

### Persyaratan
- Flutter SDK 3.0.0+
- Android SDK (min API 21 / Android 5.0)
- Dart 3.0.0+

### Langkah

```bash
# 1. Clone / extract project
cd safa_playlist

# 2. Install dependencies
flutter pub get

# 3. Jalankan di HP/emulator
flutter run

# 4. Build APK
flutter build apk --release
# APK ada di: build/app/outputs/flutter-apk/app-release.apk
```

---

## 📦 Dependencies Utama

| Package | Fungsi |
|---------|--------|
| `just_audio` | Pemutar audio |
| `just_audio_background` | Background + lock screen |
| `on_audio_query` | Baca lagu dari HP |
| `provider` | State management |
| `shared_preferences` | Simpan data lokal |
| `http` | Fetch lirik otomatis |
| `share_plus` | Share playlist |
| `flutter_staggered_animations` | Animasi list |
| `flutter_slidable` | Swipe actions |
| `url_launcher` | Buka link sosmed |

---

## 📱 Izin Android yang Dibutuhkan

- `READ_MEDIA_AUDIO` — Baca lagu (Android 13+)
- `READ_EXTERNAL_STORAGE` — Baca lagu (Android 12 ke bawah)
- `INTERNET` — Fetch lirik otomatis
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK` — Background audio

---

## 📞 Kontak

| Platform | Akun |
|----------|------|
| TikTok | @safa_pro_audio |
| TikTok | @team_sepele_tiap_singkal |
| Instagram | @safa_pro_audio |
| Instagram | @team_safa_audio |
| YouTube | SAFA PRO AUDIO |

**Tebuwung Dukun Gresik**  
📞 0858-5394-5827 | 0851-9492-4273

---

*SAFA PLAYLIST LAGU v1.0.0 — The New Ruler Off Sound System 🐉*
