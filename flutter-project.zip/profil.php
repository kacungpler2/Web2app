<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Profit otomatis
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        foreach ($u['active_products'] as &$p) {
            if ($p['status'] == 'active') {
                $last = strtotime($p['last_profit'] ?? $p['bought_at']);
                $now = time();
                $interval = 3600;
                $bought = strtotime($p['bought_at']);
                $expired = $bought + ($p['duration_days'] * 86400);
                if ($now > $expired) {
                    $p['status'] = 'expired';
                    continue;
                }
                if ($now - $last >= $interval && $p['profit_count'] < $p['total_profit_count']) {
                    $p['profit_count']++;
                    $u['balance_withdraw'] += $p['profit_per_hour'];
                    $u['total_profit'] += $p['profit_per_hour'];
                    $p['last_profit'] = date('Y-m-d H:i:s');
                    $db['transactions']['profits'][] = [
                        'id' => 'PRF' . date('Ymd') . rand(100, 999),
                        'user_id' => $u['id'],
                        'username' => $u['username'],
                        'product_id' => $p['product_id'],
                        'product_name' => $p['name'],
                        'amount' => $p['profit_per_hour'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        $_SESSION['user'] = $u;
        break;
    }
}
file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

$active_count = 0;
foreach ($user['active_products'] as $p) {
    if ($p['status'] == 'active') $active_count++;
}

$vip_level = 0;
if ($active_count >= 1) $vip_level = 1;
if ($active_count >= 3) $vip_level = 2;
if ($active_count >= 5) $vip_level = 3;
if ($active_count >= 10) $vip_level = 4;
if ($active_count >= 20) $vip_level = 5;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Profil - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --bg-card:rgba(255,255,255,0.04);
            --border:rgba(255,255,255,0.06);
            --border-gold:rgba(255,215,0,0.15);
            --text:#ffffff;
            --text-muted:#888888;
            --primary:#00d4ff;
            --gold:#ffd700;
            --success:#00e676;
            --danger:#ff5252;
            --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc);
            --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00);
            --radius:16px;
            --shadow:0 8px 32px rgba(0,0,0,0.4);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:var(--bg-card); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:var(--border-gold); }
        .user i { font-size:28px; color:var(--text); }

        .section-title { font-size:16px; font-weight:700; margin:20px 0 12px; display:flex; align-items:center; gap:10px; }
        .section-title i { color:var(--gold); font-size:18px; }

        .profile-header { display:flex; align-items:center; gap:16px; padding:12px 0; }
        .profile-header .avatar { width:56px; height:56px; border-radius:50%; background:var(--gradient-gold); display:flex; align-items:center; justify-content:center; font-size:24px; font-weight:700; color:#000; }
        .profile-header .info .name { font-size:18px; font-weight:700; }
        .profile-header .info .level { font-size:12px; color:var(--gold); font-weight:600; }
        .profile-header .info .level i { margin-right:4px; }

        .finance-card { background:var(--bg-card); border-radius:var(--radius); padding:16px; border:1px solid var(--border); margin-bottom:12px; }
        .finance-card .row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid var(--border); }
        .finance-card .row:last-child { border-bottom:none; }
        .finance-card .row .label { color:var(--text-muted); font-size:13px; }
        .finance-card .row .value { font-weight:600; font-size:14px; }
        .finance-card .row .value.gold { color:var(--gold); }
        .finance-card .row .value.green { color:var(--success); }
        .finance-card .row .value.blue { color:var(--primary); }

        .menu-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; margin:12px 0; }
        .menu-grid .menu-item { background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:14px 8px; text-align:center; transition:0.3s; cursor:pointer; }
        .menu-grid .menu-item:hover { border-color:var(--border-gold); background:rgba(255,255,255,0.05); }
        .menu-grid .menu-item i { font-size:18px; color:var(--gold); display:block; margin-bottom:4px; }
        .menu-grid .menu-item span { font-size:10px; color:var(--text-muted); }

        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="profile-header">
        <div class="avatar"><?= strtoupper(substr($user['username'], 0, 1)) ?></div>
        <div class="info">
            <div class="name"><?= htmlspecialchars($user['username']) ?></div>
            <div class="level"><i class="fas fa-crown"></i> AKSES LEVEL: VIP <?= $vip_level ?></div>
        </div>
    </div>

    <div class="section-title"><i class="fas fa-wallet"></i> Data Keuangan</div>
    <div class="finance-card">
        <div class="row">
            <span class="label"><i class="fas fa-coins" style="color:var(--primary);"></i> Saldo Deposit</span>
            <span class="value blue"><?= formatRupiah($user['balance_deposit']) ?></span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-hand-holding-usd" style="color:var(--gold);"></i> Saldo Tarik</span>
            <span class="value gold"><?= formatRupiah($user['balance_withdraw']) ?></span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-arrow-down" style="color:var(--success);"></i> Total Ingress</span>
            <span class="value green"><?= formatRupiah($user['total_deposit'] + $user['total_profit']) ?></span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-arrow-up" style="color:var(--danger);"></i> Total Egress</span>
            <span class="value" style="color:var(--danger);"><?= formatRupiah($user['total_withdraw']) ?></span>
        </div>
    </div>

    <!-- TOMBOL TARIK & DEPOSIT DIHAPUS -->

    <div class="section-title"><i class="fas fa-list"></i> Menu</div>
    <div class="menu-grid">
        <div class="menu-item" onclick="window.location.href='riwayat.php?tab=deposit'">
            <i class="fas fa-arrow-down"></i><span>Riwayat Deposit</span>
        </div>
        <div class="menu-item" onclick="window.location.href='riwayat.php?tab=withdraw'">
            <i class="fas fa-arrow-up"></i><span>Riwayat Tarik</span>
        </div>
        <div class="menu-item" onclick="window.location.href='riwayat.php?tab=profit'">
            <i class="fas fa-coins"></i><span>Riwayat Profit</span>
        </div>
        <div class="menu-item" onclick="window.location.href='riwayat.php'">
            <i class="fas fa-history"></i><span>Riwayat Keuangan</span>
        </div>
        <div class="menu-item" onclick="window.location.href='produk.php'">
            <i class="fas fa-dragon"></i><span>Naga Aktif</span>
        </div>
        <div class="menu-item" onclick="window.location.href='tim.php'">
            <i class="fas fa-users"></i><span>Tim Referral</span>
        </div>
    </div>

    <div class="bottom-nav">
        <a href="home.php"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php" class="active"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldoDeposit = <?= $user['balance_deposit'] ?>;
saldoWithdraw = <?= $user['balance_withdraw'] ?>;
updateSaldoUI();
setInterval(fetchSaldo, 30000);
</script>
</body>
</html>