<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Profit otomatis
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        foreach ($u['active_products'] as &$p) {
            if ($p['status'] == 'active') {
                $last = strtotime($p['last_profit'] ?? $p['bought_at']);
                $now = time();
                $interval = 3600;
                $bought = strtotime($p['bought_at']);
                $expired = $bought + ($p['duration_days'] * 86400);
                if ($now > $expired) {
                    $p['status'] = 'expired';
                    continue;
                }
                if ($now - $last >= $interval && $p['profit_count'] < $p['total_profit_count']) {
                    $p['profit_count']++;
                    $u['balance_withdraw'] += $p['profit_per_hour'];
                    $u['total_profit'] += $p['profit_per_hour'];
                    $p['last_profit'] = date('Y-m-d H:i:s');
                    $db['transactions']['profits'][] = [
                        'id' => 'PRF' . date('Ymd') . rand(100, 999),
                        'user_id' => $u['id'],
                        'username' => $u['username'],
                        'product_id' => $p['product_id'],
                        'product_name' => $p['name'],
                        'amount' => $p['profit_per_hour'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        $_SESSION['user'] = $u;
        break;
    }
}
file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

$tab = $_GET['tab'] ?? 'all';
$all_history = array_merge(
    $db['transactions']['profits'] ?? [],
    $db['transactions']['deposits'] ?? [],
    $db['transactions']['withdrawals'] ?? []
);
$user_history = array_filter($all_history, function($h) use ($user) {
    return ($h['user_id'] ?? '') == $user['id'];
});
usort($user_history, function($a, $b) {
    return strtotime($b['created_at'] ?? '') - strtotime($a['created_at'] ?? '');
});
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Riwayat - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --bg-card:rgba(255,255,255,0.03);
            --bg-card-hover:rgba(255,255,255,0.06);
            --border:rgba(255,255,255,0.06);
            --border-gold:rgba(255,215,0,0.15);
            --text:#ffffff;
            --text-muted:#888888;
            --primary:#00d4ff;
            --gold:#ffd700;
            --success:#00e676;
            --danger:#ff5252;
            --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc);
            --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00);
            --radius:16px;
            --shadow:0 8px 32px rgba(0,0,0,0.4);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:var(--bg-card); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:var(--border-gold); }
        .user i { font-size:28px; color:var(--text); }

        .section-title { font-size:16px; font-weight:700; margin:20px 0 12px; display:flex; align-items:center; gap:10px; }
        .section-title i { color:var(--gold); font-size:18px; }

        .tabs { display:flex; gap:6px; margin-bottom:16px; overflow-x:auto; padding-bottom:4px; }
        .tabs a { text-decoration:none; padding:6px 16px; border-radius:20px; font-size:12px; font-weight:600; color:var(--text-muted); background:var(--bg-card); border:1px solid var(--border); transition:0.3s; white-space:nowrap; }
        .tabs a.active { background:var(--gradient-gold); color:#000; border-color:var(--gold); }

        .history-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:14px 16px; margin-bottom:10px; transition:0.3s; }
        .history-card:hover { border-color:var(--border-gold); background:var(--bg-card-hover); }
        .history-card .top { display:flex; justify-content:space-between; align-items:center; }
        .history-card .top .type { font-size:14px; font-weight:600; }
        .history-card .top .type i { margin-right:6px; }
        .history-card .top .amount { font-size:15px; font-weight:700; }
        .history-card .top .amount.plus { color:var(--success); }
        .history-card .top .amount.minus { color:var(--danger); }
        .history-card .top .amount.pending { color:var(--gold); }
        .history-card .bottom { display:flex; justify-content:space-between; margin-top:4px; font-size:11px; color:var(--text-muted); }
        .history-card .bottom .status { padding:2px 10px; border-radius:12px; font-weight:600; }
        .history-card .bottom .status.approved { background:rgba(0,230,118,0.1); color:var(--success); }
        .history-card .bottom .status.pending { background:rgba(255,165,0,0.1); color:var(--gold); }
        .history-card .bottom .status.rejected { background:rgba(255,82,82,0.1); color:var(--danger); }

        .empty { text-align:center; color:var(--text-muted); padding:32px 0; font-size:14px; }
        .empty i { font-size:40px; color:var(--text-muted); display:block; margin-bottom:12px; opacity:0.5; }

        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="section-title"><i class="fas fa-history"></i> Riwayat Transaksi</div>

    <div class="tabs">
        <a href="riwayat.php?tab=all" class="<?= $tab == 'all' ? 'active' : '' ?>">Semua</a>
        <a href="riwayat.php?tab=deposit" class="<?= $tab == 'deposit' ? 'active' : '' ?>">Deposit</a>
        <a href="riwayat.php?tab=withdraw" class="<?= $tab == 'withdraw' ? 'active' : '' ?>">Tarik</a>
        <a href="riwayat.php?tab=profit" class="<?= $tab == 'profit' ? 'active' : '' ?>">Profit</a>
    </div>

    <?php
    $filtered = $user_history;
    if ($tab == 'deposit') {
        $filtered = array_filter($user_history, fn($h) => isset($h['bank']) && !isset($h['product_name']));
    } elseif ($tab == 'withdraw') {
        $filtered = array_filter($user_history, fn($h) => isset($h['fee']) || isset($h['payment_method']));
    } elseif ($tab == 'profit') {
        $filtered = array_filter($user_history, fn($h) => isset($h['product_name']));
    }
    $filtered = array_values($filtered);
    ?>

    <?php if (count($filtered) > 0): ?>
        <?php foreach ($filtered as $h): ?>
            <?php
            $type = '';
            $amount = 0;
            $cls = '';
            $status_label = '';
            $status_cls = '';
            $icon = '';
            
            if (isset($h['product_name'])) {
                $type = 'Profit ' . $h['product_name'];
                $amount = $h['amount'];
                $cls = 'plus';
                $label = '+' . formatRupiah($amount);
                $icon = 'fa-coins';
                $status_label = 'Berhasil';
                $status_cls = 'approved';
            } elseif (isset($h['bank']) && isset($h['sender'])) {
                $type = 'Deposit Manual';
                $amount = $h['amount'] ?? 0;
                $cls = $h['status'] == 'approved' ? 'plus' : ($h['status'] == 'pending' ? 'pending' : 'minus');
                $label = $h['status'] == 'approved' ? formatRupiah($amount) : ($h['status'] == 'pending' ? 'Pending' : 'Ditolak');
                $icon = 'fa-arrow-down';
                $status_label = $h['status'] ?? 'pending';
                $status_cls = $h['status'] ?? 'pending';
            } elseif (isset($h['payment_method']) || isset($h['fee'])) {
                $type = 'Penarikan';
                $amount = $h['amount'] ?? 0;
                $cls = $h['status'] == 'approved' ? 'minus' : ($h['status'] == 'pending' ? 'pending' : 'minus');
                $label = $h['status'] == 'approved' ? '-' . formatRupiah($h['net_amount'] ?? $amount) : ($h['status'] == 'pending' ? 'Pending' : 'Ditolak');
                $icon = 'fa-arrow-up';
                $status_label = $h['status'] ?? 'pending';
                $status_cls = $h['status'] ?? 'pending';
            } else {
                $type = 'Transaksi';
                $amount = $h['amount'] ?? 0;
                $cls = 'pending';
                $label = formatRupiah($amount);
                $icon = 'fa-exchange-alt';
                $status_label = 'Unknown';
                $status_cls = 'pending';
            }
            ?>
            <div class="history-card">
                <div class="top">
                    <span class="type"><i class="fas <?= $icon ?>"></i> <?= $type ?></span>
                    <span class="amount <?= $cls ?>"><?= $label ?></span>
                </div>
                <div class="bottom">
                    <span><?= date('d/m/Y H:i', strtotime($h['created_at'] ?? date('Y-m-d H:i:s'))) ?></span>
                    <span class="status <?= $status_cls ?>"><?= ucfirst($status_label) ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="empty"><i class="fas fa-inbox"></i> Belum ada riwayat untuk tab ini</div>
    <?php endif; ?>

    <div class="bottom-nav">
        <a href="home.php"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php" class="active"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldoDeposit = <?= $user['balance_deposit'] ?>;
saldoWithdraw = <?= $user['balance_withdraw'] ?>;
updateSaldoUI();
setInterval(fetchSaldo, 30000);
</script>
</body>
</html>