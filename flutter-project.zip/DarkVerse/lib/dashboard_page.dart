import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- State Variabel ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- Variabel Banner/News ---
  late PageController _newsPageController;
  double _currentNewsPage = 0.0; 
  Timer? _newsTimer;

  // --- TEMA WARNA BIRU HITAM (BLUE-BLACK DEEP) ---
  static const Color bgMain = Color(0xFF00050B);
  static const Color bgSurface = Color(0xFF040D1A);
  static const Color bgCard = Color(0xFF0A1118);
  static const Color textMain = Colors.white;
  static const Color textSub = Color(0xFF78909C); // BlueGrey 400
  static const Color accentWhite = Color(0xFF00E5FF); // Cyan Accent
  static const Color borderLight = Color(0xFF102A43);
  static const Color borderGlass = Color(0xFF00E5FF); // Bright borders for buttons

  @override
  void initState() {
    super.initState();
    
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    // Pastikan Banner di-init SEBELUM halaman dibangun
    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  void _initNewsBanner() {
    _newsPageController = PageController(
      initialPage: 0,
      viewportFraction: 0.9,
    );

    // Listener ini akan memperbarui posisi untuk auto scroll (tanpa setState)
    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });

    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(
            targetIndex,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('wss://ws-dark.http://arss.miuntech.my.id:2006.my.id'),
    );
    channel.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text(
          "⚠️ Session Expired",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(message, style: const TextStyle(color: textSub)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: const Text(
              "OK",
              style: TextStyle(
                color: accentWhite,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    if (index == 1) {
      _showWhatsAppMenu();
      return;
    }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: const BoxDecoration(
            color: const Color(0xFF0A1118),
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                "WHATSAPP TOOLS",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 24),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.redAccent.withOpacity(0.1), shape: BoxShape.circle),
                  child: const Icon(Icons.bug_report, color: Colors.redAccent),
                ),
                title: const Text("WhatsApp Crash", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                subtitle: const Text("Send payloads & crash codes", style: TextStyle(color: Colors.grey, fontSize: 13, fontFamily: 'ShareTechMono')),
                trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 14),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _bottomNavIndex = 1;
                    _selectedPage = HomePage(
                      username: username,
                      password: password,
                      listBug: listBug,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    );
                  });
                },
              ),
              const Divider(color: Colors.white12, height: 24),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.greenAccent.withOpacity(0.1), shape: BoxShape.circle),
                  child: const Icon(Icons.devices, color: Colors.greenAccent),
                ),
                title: const Text("Manage Sender", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                subtitle: const Text("Pair devices & manage sessions", style: TextStyle(color: Colors.grey, fontSize: 13, fontFamily: 'ShareTechMono')),
                trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 14),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 5) {
        _selectedPage = ModeratorPage(
          sessionKey: sessionKey,
          username: username,
        );
      }
    });
    Navigator.pop(context);
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 20),

          // INFO PANEL: Username, Role, Expired
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderLight, width: 1),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Text(
                            username.toUpperCase(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 18,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.white24),
                          ),
                          child: Text(
                            "${role.toUpperCase()} • $expiredDate",
                            style: const TextStyle(
                              color: textSub,
                              fontFamily: 'ShareTechMono',
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 20),

          // NEWS SECTION
          Container(
            width: double.infinity,
            height: 180,
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Stack(
              children: [
                PageView.builder(
                  controller: _newsPageController,
                  itemCount: newsList.length,
                  itemBuilder: (context, index) {
                    final item = newsList[index];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: bgCard,
                        border: Border.all(color: borderLight, width: 1),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            if (item['image'] != null &&
                                item['image'].toString().isNotEmpty)
                              NewsMedia(url: item['image']),
                            if (item['image'] == null)
                               Container(color: bgCard, child: const Icon(Icons.newspaper, color: textSub, size: 50)),
                            
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.black.withOpacity(0.8),
                                    Colors.transparent,
                                  ],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 30,
                              left: 20,
                              right: 16,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['title'] ?? 'No Title',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['desc'] ?? '',
                                    style: const TextStyle(
                                      color: textSub,
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                
                // --- EXPANDING DOTS (Efek Geser Membesar) ---
                Positioned(
                  bottom: 8,
                  left: 0,
                  right: 0,
                  child: AnimatedBuilder(
                    animation: _newsPageController,
                    builder: (context, child) {
                      double currentNewsPage = 0.0;
                      if (_newsPageController.hasClients && _newsPageController.page != null) {
                        currentNewsPage = _newsPageController.page!;
                      } else {
                        currentNewsPage = _currentNewsPage;
                      }

                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(newsList.length, (index) {
                          // Hitung jarak antara halaman scroll saat ini dengan index titik
                          double diff = (index - currentNewsPage).abs();
                          
                          // Atur Ukuran: 
                          // Jika aktif (diff = 0), width = 25.
                          // Jika pasif (diff >= 1), width = 5.
                          // Di antaranya, interpolasi ukuran.
                          double width = 5.0;
                          double opacity = 0.3;

                          if (diff < 1) {
                            width = 25.0 - (diff * 20.0); // 25 -> 5
                            opacity = 1.0 - (diff * 0.7);  // 1.0 -> 0.3
                          }

                          return Container(
                            margin: const EdgeInsets.symmetric(horizontal: 2.5),
                            width: width, // Width berubah saat digeser
                            height: 5,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(opacity),
                              borderRadius: BorderRadius.circular(5),
                            ),
                          );
                        }),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),

          // --- TOMBOL ---
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              width: double.infinity,
              height: 55,
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderGlass, width: 1.5),
              ),
              child: ElevatedButton.icon(
                icon: const Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 20),
                label: const Text("Join Channel", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                onPressed: () => _openUrl("t.me/RenegadeImortalll"),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgMain,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 220,
            decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0A1118), Color(0xFF00050B)])),
            child: SafeArea(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 90, height: 90,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: accentWhite, width: 2), boxShadow: [BoxShadow(color: accentWhite.withOpacity(0.1), blurRadius: 15, spreadRadius: 2)]),
                      child: ClipOval(
                        child: _profileImage != null ? Image.file(_profileImage!, fit: BoxFit.cover) : Icon(FontAwesomeIcons.userAstronaut, size: 40, color: textSub),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(username, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(20)), child: Text(role.toUpperCase(), style: const TextStyle(color: accentWhite, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 1))),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: bgMain,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 10),
                children: [
                  if (role == "reseller") _buildDrawerMenuItem(icon: Icons.storefront, label: "Seller Page", onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin") _buildDrawerMenuItem(icon: Icons.admin_panel_settings, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                  if (role == "partner") _buildDrawerMenuItem(icon: FontAwesomeIcons.handshake, label: "Partner Page", onTap: () => _onSidebarTabSelected(4)),
                  if (role == "moderator") _buildDrawerMenuItem(icon: FontAwesomeIcons.userShield, label: "Moderator Page", onTap: () => _onSidebarTabSelected(5)),
                  if (role == "owner") _buildDrawerMenuItem(icon: Icons.workspace_premium, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                  _buildDrawerMenuItem(icon: Icons.history_rounded, label: "Riwayat Aktivitas", onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))); }),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(icon: Icons.logout, label: "Log Out", isLogout: true, onTap: () async { Navigator.pop(context); final prefs = await SharedPreferences.getInstance(); await prefs.clear(); if (!mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false); }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({required IconData icon, required String label, required VoidCallback onTap, bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(color: isLogout ? Colors.red.withOpacity(0.1) : Colors.transparent, borderRadius: BorderRadius.circular(12), border: isLogout ? Border.all(color: Colors.red.withOpacity(0.3)) : null),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.red : textSub, size: 22),
        title: Text(label, style: TextStyle(color: isLogout ? Colors.red : textMain, fontWeight: FontWeight.w500, fontSize: 15)),
        trailing: const Icon(Icons.arrow_forward_ios, color: Color(0xFF555555), size: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text("XTC APPS v3.1", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20, fontFamily: 'Orbitron', letterSpacing: 2.0)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(icon: const Icon(Icons.headset_mic_outlined, color: Colors.white), tooltip: 'Customer Service', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage()))),
          IconButton(icon: const Icon(FontAwesomeIcons.userCircle, color: Colors.white), tooltip: 'My Profile', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey)))),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [bgMain, Color(0xFF040D1A)])),
        child: SafeArea(child: FadeTransition(opacity: _animation, child: _selectedPage)),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: bgCard, border: Border(top: BorderSide(color: borderLight, width: 0.5))),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: Colors.white,
          unselectedItemColor: textSub,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
            BottomNavigationBarItem(icon: Icon(Icons.notifications_none), label: "Info"),
            BottomNavigationBarItem(icon: Icon(Icons.build_circle_outlined), label: "Tools"),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _newsTimer?.cancel();
    _newsPageController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov")) {
      return Container(color: Colors.black, child: const Center(child: Icon(Icons.videocam_off, color: Colors.grey, size: 50)));
    }
    return Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1C1C1E), child: const Center(child: Icon(Icons.broken_image, color: Colors.grey))));
  }
}