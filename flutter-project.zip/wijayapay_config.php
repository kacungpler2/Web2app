<?php
define('WJ_MERCHANT_CODE', 'WP69cf9cb2a47d4');
define('WJ_API_KEY', '62bfc798078237b9718044da1a');
define('WJ_API_URL', 'https://wijayapay.com/api/transaction/create');
define('WJ_CALLBACK_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/wijayapay_callback.php');
define('WJ_IP_WHITELIST', '45.158.126.118');

function wijayapay_signature($ref_id) {
    return md5(WJ_MERCHANT_CODE . WJ_API_KEY . $ref_id);
}

function wijayapay_verify_signature($signature, $ref_id) {
    return hash_equals(md5(WJ_MERCHANT_CODE . WJ_API_KEY . $ref_id), $signature);
}

function wijayapay_create_payment($amount, $ref_id, $code_payment = 'QRIS') {
    $postData = http_build_query([
        'code_merchant' => WJ_MERCHANT_CODE,
        'api_key' => WJ_API_KEY,
        'ref_id' => $ref_id,
        'code_payment' => $code_payment,
        'nominal' => $amount,
        'callback_url' => WJ_CALLBACK_URL
    ]);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, WJ_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
        'X-Signature: ' . wijayapay_signature($ref_id)
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    if($error) return ['error' => true, 'message' => 'CURL Error: ' . $error];
    $result = json_decode($response, true);
    if($result === null) return ['error' => true, 'message' => 'Invalid JSON response'];
    return $result;
}
?>