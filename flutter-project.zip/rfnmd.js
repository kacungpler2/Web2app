// ========================= Monitor Panel - by RFN MD =========================
// Author      : Rizqi Fadhillah Nursalim
// Contact     : t.me/rizqifadhillahn31 | rizqifadhillah31@gmail.com
// Version     : 1.5.0
// Status      : 100% No error scripts (stable release)
// Node.js     : 20 (recommended)
// Storage     : JSON-based
// Last Update : 04 December 2025
// ========================= DO NOT DELETE THIS CREDIT =========================

const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');
const chalk = require('chalk');

const STATE_FILE = path.resolve(__dirname, 'rfnmd-state.json');
const CONFIG_FILE = path.resolve(__dirname, 'config.json');

if (!fs.existsSync(CONFIG_FILE)) {
  console.error(chalk.redBright('❌ Missing config.json — create one next to this script.'));
  process.exit(1);
}

const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
const {
  panelDomain,
  applicationKey,
  telegramBotToken,
  telegramChatId,
  pollIntervalSec = 60,
  debug = false,
  enableCpuMonitor = true,
  cpuThresholdPercent = 90,
  cpuAlertIntervalSec = 120 // 2 menit nih 🗿
} = config;

if (!panelDomain || !applicationKey || !telegramBotToken || !telegramChatId) {
  console.error(chalk.redBright('❌ Missing required fields in config.json'));
  process.exit(1);
}

const bot = new TelegramBot(telegramBotToken, { polling: true });
const log = (...args) => debug && console.log(chalk.gray(new Date().toISOString()), ...args);

async function apiGet(path) {
  const url = new URL(path, panelDomain).toString();
  const res = await fetch(url, {
    headers: {
      'Authorization': 'Bearer ' + applicationKey,
      'Accept': 'application/vnd.pterodactyl.v1+json'
    },
    timeout: 20000
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '<no body>');
    throw new Error(`${res.status} ${res.statusText} — ${text}`);
  }
  return res.json();
}

async function safeFetch(path, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      return await apiGet(path);
    } catch (err) {
      if (i === retries - 1) throw err;
      console.log(chalk.yellow(`⚠️ Retry ${i + 1}/${retries} for ${path}`));
      await new Promise(r => setTimeout(r, 2000 * (i + 1)));
    }
  }
}

function mapEntities(list, type = 'servers') {
  const result = {};
  for (const item of list) {
    const attr = item.attributes || item;
    result[attr.id] = {
      id: attr.id,
      name: attr.name || attr.username,
      isAdmin: !!(attr.root_admin || attr.admin || attr.is_admin),
      type
    };
  }
  return result;
}

function readState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    }
  } catch (e) {
    console.error(chalk.red('⚠️ Failed to read state:'), e.message);
  }
  return { servers: {}, users: {}, cpuStates: {} };
}

function writeState(state) {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
}

async function sendTelegram(msg, silent = false) {
  try {
    await bot.sendMessage(telegramChatId, msg, { parse_mode: 'Markdown', disable_notification: silent });
  } catch (e) {
    console.error(chalk.red('❌ Failed to send Telegram message:'), e.message);
  }
}

async function detectChanges() {
  const prevState = readState();
  try {
    const [serversRes, usersRes] = await Promise.all([
      safeFetch('/api/application/servers?page=1'),
      safeFetch('/api/application/users?page=1')
    ]);

    const servers = mapEntities(serversRes.data || serversRes, 'servers');
    const users = mapEntities(usersRes.data || usersRes, 'users');

    const prevServers = prevState.servers || {};
    const prevUsers = prevState.users || {};

    const newServers = Object.values(servers).filter(s => !prevServers[s.id]);
    const removedServers = Object.values(prevServers).filter(s => !servers[s.id]);
    const newUsers = Object.values(users).filter(u => !prevUsers[u.id]);
    const removedUsers = Object.values(prevUsers).filter(u => !users[u.id]);
    const newAdmins = Object.values(users).filter(u => u.isAdmin && prevUsers[u.id] && !prevUsers[u.id].isAdmin);

    let msg = '';
    if (newServers.length) msg += `🆕 *New Servers* (${newServers.length})\n${newServers.map(s => `• ${s.name} [${s.id}]`).join('\n')}\n\n`;
    if (removedServers.length) msg += `🗑️ *Removed Servers* (${removedServers.length})\n${removedServers.map(s => `• ${s.name} [${s.id}]`).join('\n')}\n\n`;
    if (newUsers.length) msg += `👤 *New Users* (${newUsers.length})\n${newUsers.map(u => `• ${u.name} [${u.id}]`).join('\n')}\n\n`;
    if (removedUsers.length) msg += `🚫 *Removed Users* (${removedUsers.length})\n${removedUsers.map(u => `• ${u.name} [${u.id}]`).join('\n')}\n\n`;
    if (newAdmins.length) msg += `🔐 *New Admins* (${newAdmins.length})\n${newAdmins.map(u => `• ${u.name} [${u.id}]`).join('\n')}\n\n`;

    if (msg) {
      const header = `🐋 *RFN MD Monitor Update*\n_Panel:_ ${panelDomain}\n\n`;
      await sendTelegram(header + msg);
      console.log(chalk.green('✅ Change detected & notification sent!'));
    }

    const newState = { servers, users, lastPoll: new Date().toISOString() };
    if (enableCpuMonitor) {
        const prevCpuStates = prevState.cpuStates || {};
        const currentCpuStates = JSON.parse(JSON.stringify(prevCpuStates));

        const resourceChecks = Object.values(servers).map(async (server) => {
            try {
                const res = await safeFetch(`/api/application/servers/${server.id}/resources`);
                const serverStatus = res.attributes.current_state;
                const cpuUsage = res.attributes.resources.cpu_absolute;

                if (serverStatus !== 'running') {
                    if (currentCpuStates[server.id]) {
                        log(chalk.gray(`🚮 CPU state for offline server ${server.name} cleared.`));
                        delete currentCpuStates[server.id];
                    }
                    return;
                }

                if (cpuUsage >= cpuThresholdPercent) {
                    const serverCpuState = currentCpuStates[server.id];
                    if (!serverCpuState || !serverCpuState.isHigh) {
                        currentCpuStates[server.id] = { isHigh: true, highSince: Date.now(), notified: false };
                        log(chalk.yellow(`📈 High CPU detected for ${server.name}: ${cpuUsage.toFixed(2)}%`));
                    } else if (!serverCpuState.notified && (Date.now() - serverCpuState.highSince) >= (cpuAlertIntervalSec * 1000)) {
                        const alertMsg = `🔥 *CPU Usage Alert*\n\n` +
                                         `*Server:* \`${server.name}\`\n` +
                                         `*ID:* \`${server.id}\`\n` +
                                         `*CPU Usage:* \`${cpuUsage.toFixed(2)}%\`\n\n` +
                                         `This alert is triggered when CPU usage is consistently above ${cpuThresholdPercent}% for more than ${cpuAlertIntervalSec / 60} minute(s).`;
                        await sendTelegram(alertMsg);
                        console.log(chalk.redBright(`🚨 High CPU alert sent for server: ${server.name}`));
                        currentCpuStates[server.id].notified = true;
                    }
                } else {
                    if (currentCpuStates[server.id] && currentCpuStates[server.id].isHigh) {
                        log(chalk.green(`✅ CPU for ${server.name} is back to normal.`));
                        delete currentCpuStates[server.id];
                    }
                }
            } catch (err) {
                log(chalk.red(`⚠️ Failed to get resources for server ${server.id} (${server.name}): ${err.message}`));
            }
        });

        await Promise.all(resourceChecks);
        newState.cpuStates = currentCpuStates;
    }

    writeState(newState);
  } catch (err) {
    console.error(chalk.red('❌ Polling error:'), err.message);
    await sendTelegram(`⚠️ *RFN MD Monitor Error:*\n${err.message}`, true);
  }
}

bot.on('message', async (msg) => {
    if (String(msg.chat.id) !== String(telegramChatId) || !msg.text || !msg.text.startsWith('/')) {
        return;
    }

    const args = msg.text.slice(1).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    const reply = (text) => bot.sendMessage(telegramChatId, text, { parse_mode: 'Markdown' });
    const m = msg;

    switch (command) {
        case 'status': {
            const s = readState();
            const summary = `📊 *RFN MD Monitor Status*\nServers: ${Object.keys(s.servers || {}).length}\nUsers: ${Object.keys(s.users || {}).length}\nLast check: ${s.lastPoll || 'never'}`;
            reply(summary);
            break;
        }

        case 'force': {
            await reply('⏳ Manual check triggered...');
            await detectChanges();
            break;
        }

        case 'help': {
            const help = `🤖 *RFN MD Monitor Commands*\n/status — show stats\n/force — trigger manual check\n/help — this menu\n/os — check bot host status`;
            reply(help);
            break;
        }

        case 'os': {
            const os = require("os");
            const v8 = require("v8");

            const formatSize = (size) => {
                return `${(size / 1024 / 1024).toFixed(2)} MB`;
            };

            const runtime = (seconds) => {
                seconds = Math.round(seconds);
                let days = Math.floor(seconds / (3600 * 24));
                seconds %= 3600 * 24;
                let hrs = Math.floor(seconds / 3600);
                seconds %= 3600;
                let mins = Math.floor(seconds / 60);
                let secs = seconds % 60;
                return `${days}d ${hrs}h ${mins}m ${secs}s`;
            };

            const fetchJson = async (url) => {
                let res = await fetch(url);
                return await res.json();
            };

            const used = process.memoryUsage();
            const cpus = os.cpus().map(cpu => {
                cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
                return cpu;
            });
            const cpu = cpus.reduce((last, cpu, _, {
                length
            }) => {
                last.total += cpu.total;
                last.speed += cpu.speed / length;
                last.times.user += cpu.times.user;
                last.times.nice += cpu.times.nice;
                last.times.sys += cpu.times.sys;
                last.times.idle += cpu.times.idle;
                last.times.irq += cpu.times.irq;
                return last;
            }, {
                speed: 0,
                total: 0,
                times: {
                    user: 0,
                    nice: 0,
                    sys: 0,
                    idle: 0,
                    irq: 0
                }
            });

            let heapStat = v8.getHeapStatistics();
            const x = "`";
            const myip = await fetchJson("https://ipinfo.io/json");

            function hideIp(ip) {
                const ipSegments = ip.split(".");
                if (ipSegments.length === 4) {
                    ipSegments[2] = "***";
                    ipSegments[3] = "***";
                    return ipSegments.join(".");
                } else {
                    throw new Error("Invalid IP address");
                }
            }

            const ips = hideIp(myip.ip);
            const respTimeInSeconds = (Date.now() - new Date(m.date * 1000)) / 1000;
            const resp = `${respTimeInSeconds.toFixed(3)} second${respTimeInSeconds !== 1 ? 's' : ''}`;

            let teks = `${x}INFO SERVER${x}
- Speed Respons: _${resp}_
- Hostname: _${os.hostname()}_
- CPU Core: _${cpus.length}_
- Platform : _${os.platform()}_
- OS : _${os.version()} / ${os.release()}_
- Arch: _${os.arch()}_
- Ram: _${formatSize(os.totalmem() - os.freemem())}_ / _${formatSize(os.totalmem())}_

${x}PROVIDER INFO${x}
- IP: ${ips}
- Region : _${myip.region} ${myip.country}_
- ISP : _${myip.org}_

${x}RUNTIME OS${x}
- _${runtime(os.uptime())}_

${x}RUNTIME BOT${x}
- _${runtime(process.uptime())}_

${x}NODE MEMORY USAGE${x}
${Object.keys(used).map(
              (key, _, arr) => `*- ${key.padEnd(Math.max(...arr.map(v => v.length)), " ")} :* ${formatSize(used[key])}`
            ).join("\n")}
*- Heap Executable :* ${formatSize(heapStat?.total_heap_size_executable)}
*- Physical Size :* ${formatSize(heapStat?.total_physical_size)}
*- Available Size :* ${formatSize(heapStat?.total_available_size)}
*- Heap Limit :* ${formatSize(heapStat?.heap_size_limit)}
*- Malloced Memory :* ${formatSize(heapStat?.malloced_memory)}
*- Peak Malloced Memory :* ${formatSize(heapStat?.peak_malloced_memory)}
*- Does Zap Garbage :* ${formatSize(heapStat?.does_zap_garbage)}
*- Native Contexts :* ${formatSize(heapStat?.number_of_native_contexts)}
*- Detached Contexts :* ${formatSize(heapStat?.number_of_detached_contexts)}
*- Total Global Handles :* ${formatSize(heapStat?.total_global_handles_size)}
*- Used Global Handles :* ${formatSize(heapStat?.used_global_handles_size)}

${cpus[0] ? `
*_Total CPU Usage_*
${cpus[0].model.trim()} (${cpu.speed} MHZ)
${Object.keys(cpu.times).map(
              type => `*- ${(type + "*").padEnd(6)}: ${((100 * cpu.times[type]) / cpu.total).toFixed(2)}%`
            ).join("\n")}

*_CPU Core(s) Usage (${cpus.length} Core CPU)_*
${cpus.map(
              (cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(
                  type => `*- ${(type + "*").padEnd(6)}: ${((100 * cpu.times[type]) / cpu.total).toFixed(2)}%`
                ).join("\n")}`
            ).join("\n\n")}
` : ""}
`.trim();

            reply(teks);
        }
        break;
    }
});

(async () => {
  console.log(chalk.magentaBright('🚀 RFN MD 🐋 Pterodactyl Monitor Started'));
  const stateExists = fs.existsSync(STATE_FILE);
  if (!stateExists) {
    try {
      console.log(chalk.gray('Creating initial snapshot...'));
      const servers = mapEntities((await safeFetch('/api/application/servers?page=1')).data);
      const users = mapEntities((await safeFetch('/api/application/users?page=1')).data);
      writeState({ servers, users, cpuStates: {}, lastPoll: new Date().toISOString() });
      console.log(chalk.green('✅ Initial snapshot created.'));
    } catch (err) {
      console.error(chalk.red('❌ Initial snapshot failed:'), err.message);
      await sendTelegram(`⚠️ Initial snapshot failed:\n${err.message}`);
    }
  }

  setInterval(() => detectChanges(), Math.max(20, pollIntervalSec) * 1000);
})();