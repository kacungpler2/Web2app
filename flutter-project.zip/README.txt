// ========================= Monitor Panel - by RFN MD =========================
// Author      : Rizqi Fadhillah Nursalim
// Contact     : t.me/rizqifadhillahn31 | rizqifadhillah31@gmail.com
// Version     : 1.5.0
// Status      : 100% No error scripts (stable release)
// Node.js     : 20 (recommended)
// Storage     : JSON-based
// Last Update : 04 December 2025
// ========================= DO NOT DELETE THIS CREDIT =========================

README – RFN MD Pterodactyl Monitor

1. What is rfnmd.js?
rfnmd.js is an automatic monitoring script for the Pterodactyl panel. It monitors:
- New servers added
- Servers removed
- New users added
- Users removed
- Users who become admins

Every detected change is sent to Telegram. The script polls the Pterodactyl API and compares new data with previously saved data.

2. config.json – Storing & Editing Configuration
This file contains the main settings needed by the script:

panelDomain       = Pterodactyl panel URL
applicationKey    = Application API Key
telegramBotToken  = Telegram bot token
telegramChatId    = Chat/group ID for notifications
pollIntervalSec   = Interval for each check (seconds)
debug             = Debug mode (true/false)

The script reads this file at startup. If it is missing or any required fields are empty, the script will stop and show an error.

3. ptero-state.json – Stored Monitoring Data
This file stores the last known state of:
- Servers
- Users
- Admin status
- Last polling time

The script uses this file to detect changes. On each polling cycle it:
1. Reads old state
2. Fetches new API data
3. Detects changes
4. Sends Telegram notifications if needed
5. Updates ptero-state.json

4. How to Run
1. Install Node.js version 20+
2. Create config.json
3. Run:
   node rfnmd.js

If ptero-state.json does not exist, the script automatically creates an initial snapshot.

5. Telegram Bot Commands
/status  – Show summary
/force   – Run an instant check
/help    – Show help menu

Summary:
- rfnmd.js = Monitoring script that sends updates to Telegram
- config.json = Stores configuration & API keys
- ptero-state.json = Stores previous panel state for change detection