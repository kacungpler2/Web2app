<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// ===== PROSES PROFIT OTOMATIS (SETIAP 1 JAM) =====
$profit_added = 0;
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        foreach ($u['active_products'] as &$p) {
            if ($p['status'] == 'active') {
                $last = strtotime($p['last_profit'] ?? $p['bought_at']);
                $now = time();
                $interval = 3600; // 1 jam
                
                // Cek expired
                $bought = strtotime($p['bought_at']);
                $expired = $bought + ($p['duration_days'] * 86400);
                if ($now > $expired) {
                    $p['status'] = 'expired';
                    continue;
                }
                
                // Tambah profit
                if ($now - $last >= $interval && $p['profit_count'] < $p['total_profit_count']) {
                    $p['profit_count']++;
                    $u['balance_withdraw'] += $p['profit_per_hour'];
                    $u['total_profit'] += $p['profit_per_hour'];
                    $p['last_profit'] = date('Y-m-d H:i:s');
                    $profit_added += $p['profit_per_hour'];
                    
                    $db['transactions']['profits'][] = [
                        'id' => 'PRF' . date('Ymd') . rand(100, 999),
                        'user_id' => $u['id'],
                        'username' => $u['username'],
                        'product_id' => $p['product_id'],
                        'product_name' => $p['name'],
                        'amount' => $p['profit_per_hour'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        $_SESSION['user'] = $u;
        break;
    }
}
file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));

// Ambil data terbaru
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

// ===== PROSES BELI PRODUK =====
$buy_error = '';
$buy_success = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_product'])) {
    $product_id = $_POST['product_id'];
    
    foreach ($db['products'] as $product) {
        if ($product['id'] == $product_id && $product['status'] == 'active') {
            // Cek max buy
            $count = 0;
            foreach ($user['active_products'] as $p) {
                if ($p['product_id'] == $product_id && $p['status'] == 'active') {
                    $count++;
                }
            }
            if ($count >= $product['max_buy']) {
                $buy_error = 'Anda sudah mencapai batas maksimal pembelian produk ini (' . $product['max_buy'] . 'x)!';
                break;
            }
            
            if ($user['balance_deposit'] < $product['price']) {
                $buy_error = 'Saldo deposit tidak mencukupi! Butuh ' . formatRupiah($product['price']);
                break;
            }
            
            // Proses beli
            foreach ($db['users'] as &$u) {
                if ($u['id'] == $user['id']) {
                    $u['balance_deposit'] -= $product['price'];
                    $new_product = [
                        'product_id' => $product['id'],
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'profit_per_hour' => $product['profit_per_hour'],
                        'duration_days' => $product['duration_days'],
                        'total_profit' => $product['total_profit'],
                        'total_profit_count' => $product['duration_days'] * 24,
                        'profit_count' => 0,
                        'last_profit' => date('Y-m-d H:i:s'),
                        'bought_at' => date('Y-m-d H:i:s'),
                        'status' => 'active'
                    ];
                    $u['active_products'][] = $new_product;
                    $u['product_history'][] = [
                        'product_id' => $product['id'],
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'bought_at' => date('Y-m-d H:i:s')
                    ];
                    $user = $u;
                    $_SESSION['user'] = $u;
                    break;
                }
            }
            file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
            $buy_success = 'Berhasil membeli ' . $product['name'] . '!';
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root { --bg:#0a0a0f; --bg-card:rgba(255,255,255,0.03); --border:rgba(255,255,255,0.06); --border-gold:rgba(255,215,0,0.2); --text:#ffffff; --text-muted:#888888; --primary:#00d4ff; --gold:#ffd700; --success:#00e676; --danger:#ff5252; --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc); --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00); --radius:16px; }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }
        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:700; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { color:var(--primary); -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; }
        .user i { font-size:28px; color:var(--text); }
        .wallet { background:linear-gradient(135deg,rgba(0,212,255,0.08),rgba(123,47,252,0.08)); border:1px solid rgba(0,212,255,0.15); border-radius:var(--radius); padding:16px 20px; margin:16px 0; }
        .wallet .row { display:flex; justify-content:space-between; align-items:center; padding:4px 0; }
        .wallet .label { font-size:12px; color:var(--text-muted); }
        .wallet .label i { color:var(--gold); margin-right:6px; }
        .wallet .amount { font-size:20px; font-weight:700; }
        .wallet .amount.deposit { color:#00d4ff; }
        .wallet .amount.withdraw { color:#ffd700; }
        .wallet .actions { display:flex; gap:10px; margin-top:8px; }
        .wallet .actions a { text-decoration:none; display:flex; align-items:center; gap:6px; padding:8px 16px; border-radius:10px; font-weight:600; font-size:12px; }
        .wallet .actions .btn-deposit { background:var(--gradient); color:#fff; }
        .wallet .actions .btn-withdraw { background:var(--gradient-gold); color:#000; }
        .section-title { font-size:16px; font-weight:600; margin:20px 0 12px; display:flex; align-items:center; gap:8px; }
        .section-title i { color:var(--gold); }
        .section-title .badge { background:rgba(255,215,0,0.15); color:var(--gold); font-size:10px; padding:2px 10px; border-radius:20px; margin-left:6px; }
        .product-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:16px; margin-bottom:12px; }
        .product-card .header { display:flex; justify-content:space-between; align-items:center; }
        .product-card .header .name { font-size:16px; font-weight:700; }
        .product-card .header .status { font-size:10px; padding:2px 12px; border-radius:12px; }
        .product-card .header .status.active { background:rgba(0,255,0,0.1); color:#51cf66; }
        .product-card .header .status.offline { background:rgba(255,0,0,0.15); color:#ff6b6b; }
        .product-card .detail { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; margin:10px 0; padding:10px 0; border-top:1px solid var(--border); border-bottom:1px solid var(--border); }
        .product-card .detail .item { text-align:center; }
        .product-card .detail .item .lbl { font-size:10px; color:var(--text-muted); }
        .product-card .detail .item .val { font-size:14px; font-weight:600; }
        .product-card .btn-buy { background:var(--gradient); border:none; color:#fff; padding:10px; border-radius:10px; font-weight:600; font-size:14px; cursor:pointer; width:100%; }
        .product-card .btn-buy:active { transform:scale(0.97); }
        .product-card .btn-buy:disabled { opacity:0.5; cursor:not-allowed; }
        .product-card .max-buy { font-size:11px; color:var(--text-muted); text-align:center; margin-top:6px; }
        .active-product { background:rgba(0,212,255,0.05); border:1px solid rgba(0,212,255,0.1); border-radius:var(--radius); padding:12px 16px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center; }
        .active-product .info .name { font-weight:600; font-size:14px; }
        .active-product .info .detail { font-size:11px; color:var(--text-muted); }
        .active-product .info .progress { width:100%; height:4px; background:rgba(255,255,255,0.1); border-radius:2px; margin-top:4px; overflow:hidden; }
        .active-product .info .progress .fill { height:100%; background:linear-gradient(90deg,#00d4ff,#7b2ffc); border-radius:2px; }
        .active-product .profit { font-weight:700; color:var(--success); font-size:14px; }
        .alert { padding:12px 16px; border-radius:12px; margin-bottom:12px; font-size:14px; display:flex; align-items:center; gap:8px; }
        .alert-error { background:rgba(255,82,82,0.15); border:1px solid rgba(255,82,82,0.3); color:var(--danger); }
        .alert-success { background:rgba(0,230,118,0.1); border:1px solid rgba(0,230,118,0.2); color:var(--success); }
        .history-item { display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border); font-size:13px; }
        .bottom-nav { position:fixed; bottom:0; left:50%; transform:translateX(-50%); max-width:430px; width:100%; display:grid; grid-template-columns:repeat(5,1fr); background:rgba(10,10,15,0.95); backdrop-filter:blur(12px); border-top:1px solid var(--border); padding:8px 0; z-index:100; }
        .bottom-nav a { display:flex; flex-direction:column; align-items:center; text-decoration:none; color:var(--text-muted); font-size:10px; padding:4px 0; }
        .bottom-nav a i { font-size:22px; margin-bottom:2px; }
        .bottom-nav a.active { color:var(--gold); }
        @media (max-width:380px) {
            .wallet .amount { font-size:17px; }
            .product-card .detail { grid-template-columns:1fr 1fr; }
        }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <!-- ===== SALDO ===== -->
    <div class="wallet">
        <div class="row">
            <span class="label"><i class="fas fa-coins"></i> Saldo Deposit</span>
            <span class="amount deposit" id="saldoDeposit"><?= formatRupiah($user['balance_deposit']) ?></span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-hand-holding-usd"></i> Saldo Tarik</span>
            <span class="amount withdraw" id="saldoWithdraw"><?= formatRupiah($user['balance_withdraw']) ?></span>
        </div>
        <div class="actions">
            <a href="deposit.php" class="btn-deposit"><i class="fas fa-plus-circle"></i> Deposit</a>
            <a href="withdraw.php" class="btn-withdraw"><i class="fas fa-arrow-up"></i> Tarik</a>
        </div>
    </div>

    <!-- ===== PRODUK AKTIF ===== -->
    <div class="section-title"><i class="fas fa-dragon"></i> Naga Aktif</div>
    <?php if (count($user['active_products']) > 0): ?>
        <?php foreach ($user['active_products'] as $p): ?>
            <?php if ($p['status'] == 'active'): ?>
                <?php 
                $progress = $p['total_profit_count'] > 0 ? round(($p['profit_count'] / $p['total_profit_count']) * 100) : 0;
                ?>
                <div class="active-product">
                    <div class="info">
                        <div class="name">🐉 <?= $p['name'] ?></div>
                        <div class="detail">Profit: <?= formatRupiah($p['profit_per_hour']) ?>/jam (<?= $p['profit_count'] ?>/<?= $p['total_profit_count'] ?>x)</div>
                        <div class="progress"><div class="fill" style="width:<?= $progress ?>%"></div></div>
                    </div>
                    <div class="profit">+<?= formatRupiah($p['profit_per_hour'] * $p['profit_count']) ?></div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color:#555;text-align:center;padding:12px 0;">Belum ada naga aktif. Beli produk di bawah!</p>
    <?php endif; ?>

    <!-- ===== PRODUK ===== -->
    <div class="section-title"><i class="fas fa-store"></i> Beli Naga <span class="badge">Profit otomatis 1 jam</span></div>
    <?php if ($buy_error): ?>
        <div class="alert alert-error"><?= $buy_error ?></div>
    <?php endif; ?>
    <?php if ($buy_success): ?>
        <div class="alert alert-success"><?= $buy_success ?></div>
    <?php endif; ?>

    <?php foreach ($db['products'] as $product): ?>
        <?php if ($product['status'] != 'active') continue; ?>
        <?php
        $count = 0;
        foreach ($user['active_products'] as $p) {
            if ($p['product_id'] == $product['id'] && $p['status'] == 'active') $count++;
        }
        $can_buy = $count < $product['max_buy'];
        ?>
        <div class="product-card">
            <div class="header">
                <span class="name">🐉 <?= $product['name'] ?></span>
                <span class="status active">Tersedia</span>
            </div>
            <div class="detail">
                <div class="item"><span class="lbl">Harga</span><span class="val"><?= formatRupiah($product['price']) ?></span></div>
                <div class="item"><span class="lbl">Profit/Hari</span><span class="val" style="color:var(--success);"><?= formatRupiah($product['profit_per_day']) ?></span></div>
                <div class="item"><span class="lbl">Durasi</span><span class="val"><?= $product['duration_days'] ?> hari</span></div>
                <div class="item"><span class="lbl">Total Profit</span><span class="val" style="color:var(--gold);"><?= formatRupiah($product['total_profit']) ?></span></div>
                <div class="item"><span class="lbl">Profit/Jam</span><span class="val" style="color:#51cf66;"><?= formatRupiah($product['profit_per_hour']) ?></span></div>
                <div class="item"><span class="lbl">Max Beli</span><span class="val"><?= $product['max_buy'] ?>x</span></div>
            </div>
            <form method="POST">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <button type="submit" name="buy_product" class="btn-buy" <?= !$can_buy ? 'disabled' : '' ?>>
                    <i class="fas fa-shopping-cart"></i> <?= $can_buy ? 'Beli Naga' : 'Maksimal ' . $product['max_buy'] . 'x' ?>
                </button>
            </form>
            <div class="max-buy">Dibeli: <?= $count ?> / <?= $product['max_buy'] ?>x</div>
        </div>
    <?php endforeach; ?>

    <!-- ===== RIWAYAT SINGKAT ===== -->
    <div class="section-title" style="margin-top:24px;"><i class="fas fa-history"></i> Riwayat Profit</div>
    <?php
    $profits = array_filter($db['transactions']['profits'] ?? [], fn($p) => ($p['user_id'] ?? '') == $user['id']);
    usort($profits, fn($a, $b) => strtotime($b['created_at'] ?? '') - strtotime($a['created_at'] ?? ''));
    if (count($profits) > 0):
        foreach (array_slice($profits, 0, 5) as $p):
    ?>
        <div class="history-item">
            <span><?= $p['product_name'] ?></span>
            <span style="color:var(--success);">+<?= formatRupiah($p['amount']) ?></span>
        </div>
    <?php endforeach; else: ?>
        <p style="color:#555;text-align:center;padding:12px 0;">Belum ada profit</p>
    <?php endif; ?>

    <!-- ===== BOTTOM NAV ===== -->
    <div class="bottom-nav">
        <a href="dashboard.php" class="active"><i class="fas fa-home"></i> Beranda</a>
        <a href="riwayat.php"><i class="fas fa-history"></i> Riwayat</a>
        <a href="undang.php"><i class="fas fa-users"></i> Undang</a>
        <a href="deposit.php"><i class="fas fa-plus-circle"></i> Deposit</a>
        <a href="profil.php"><i class="fas fa-user"></i> Profil</a>
    </div>

</div>

<script>
let saldoDeposit = <?= $user['balance_deposit'] ?>;
let saldoWithdraw = <?= $user['balance_withdraw'] ?>;

function updateSaldo() {
    const el1 = document.getElementById('saldoDeposit');
    const el2 = document.getElementById('saldoWithdraw');
    if (el1) el1.textContent = 'Rp ' + saldoDeposit.toLocaleString('id-ID');
    if (el2) el2.textContent = 'Rp ' + saldoWithdraw.toLocaleString('id-ID');
}

function fetchSaldo() {
    fetch('api.php?action=saldo')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'success') {
                saldoDeposit = data.balance_deposit;
                saldoWithdraw = data.balance_withdraw;
                updateSaldo();
            }
        })
        .catch(() => {});
}

updateSaldo();
setInterval(fetchSaldo, 30000);
</script>
</body>
</html>