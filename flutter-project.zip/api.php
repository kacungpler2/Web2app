<?php
error_reporting(0);
session_start();

$db_file = 'data/db.json';
if (!file_exists($db_file)) {
    echo json_encode(['status' => 'error', 'message' => 'Database tidak ditemukan']);
    exit();
}

$db = json_decode(file_get_contents($db_file), true);

function updateUser($username, $data) {
    global $db, $db_file;
    foreach ($db['users'] as &$u) {
        if ($u['username'] == $username) {
            foreach ($data as $key => $value) {
                $u[$key] = $value;
            }
            file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
            return true;
        }
    }
    return false;
}

function addTransaction($type, $data) {
    global $db, $db_file;
    if (!isset($db['transactions'][$type])) {
        $db['transactions'][$type] = [];
    }
    $db['transactions'][$type][] = $data;
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action == 'saldo') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
        exit();
    }
    $user = $_SESSION['user'];
    echo json_encode([
        'status' => 'success',
        'balance_deposit' => $user['balance_deposit'],
        'balance_withdraw' => $user['balance_withdraw']
    ]);
    exit();
}

if ($action == 'deposit') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
        exit();
    }
    // QRIS deposit handled by wijayapay_callback.php
    // This endpoint is for manual deposit via admin (legacy)
    $user = $_SESSION['user'];
    $amount = (int) $_POST['amount'] ?? 0;
    $bank = $_POST['bank'] ?? 'BCA';
    $sender = $_POST['sender'] ?? 'Unknown';
    if ($amount < 80000) {
        echo json_encode(['status' => 'error', 'message' => 'Minimal deposit Rp 80.000']);
        exit();
    }
    $deposit = [
        'id' => 'DEP' . date('Ymd') . rand(100, 999),
        'user_id' => $user['id'],
        'username' => $user['username'],
        'amount' => $amount,
        'bank' => $bank,
        'sender' => $sender,
        'status' => 'pending',
        'created_at' => date('Y-m-d H:i:s')
    ];
    addTransaction('deposits', $deposit);
    echo json_encode(['status' => 'success', 'message' => 'Deposit diajukan, menunggu verifikasi admin']);
    exit();
}

if ($action == 'withdraw') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
        exit();
    }
    $user = $_SESSION['user'];
    $amount = (int) $_POST['amount'] ?? 0;
    $payment_method = $_POST['payment_method'] ?? 'BCA';
    $account_number = $_POST['account_number'] ?? '';
    $account_name = $_POST['account_name'] ?? '';
    
    if ($amount < 27000) {
        echo json_encode(['status' => 'error', 'message' => 'Minimal penarikan Rp 27.000']);
        exit();
    }
    if ($amount > $user['balance_withdraw']) {
        echo json_encode(['status' => 'error', 'message' => 'Saldo tarik tidak mencukupi']);
        exit();
    }
    
    $has_active = false;
    foreach ($user['active_products'] as $p) {
        if ($p['status'] == 'active') { $has_active = true; break; }
    }
    if (!$has_active) {
        echo json_encode(['status' => 'error', 'message' => 'Harus memiliki produk aktif untuk penarikan!']);
        exit();
    }
    
    $fee = 2500;
    $net = $amount - $fee;
    
    $withdraw = [
        'id' => 'WD' . date('Ymd') . rand(100, 999),
        'user_id' => $user['id'],
        'username' => $user['username'],
        'amount' => $amount,
        'fee' => $fee,
        'net_amount' => $net,
        'payment_method' => $payment_method,
        'account_number' => $account_number,
        'account_name' => $account_name,
        'status' => 'pending',
        'created_at' => date('Y-m-d H:i:s')
    ];
    addTransaction('withdrawals', $withdraw);
    echo json_encode(['status' => 'success', 'message' => 'Penarikan diajukan, menunggu verifikasi admin']);
    exit();
}

if ($action == 'update_bank') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
        exit();
    }
    // Not used anymore
    echo json_encode(['status' => 'success', 'message' => 'OK']);
    exit();
}

echo json_encode(['status' => 'error', 'message' => 'Action tidak ditemukan']);
?>