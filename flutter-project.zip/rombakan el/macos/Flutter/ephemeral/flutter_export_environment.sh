#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\user\Downloads\flutter_windows_3.38.5-stablep\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\user\Downloads\Telegram Desktop\DorcaFeels\p"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=2.0.0"
export "FLUTTER_BUILD_NUMBER=2.0.0"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
