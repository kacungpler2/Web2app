<?php
require_once 'wijayapay_config.php';
$ref_id = $_GET['ref_id'] ?? '';
if(empty($ref_id)) {
    echo json_encode(['error' => true, 'message' => 'Ref ID required']);
    exit();
}
$temp_file = __DIR__ . '/data/temp_payments/' . $ref_id . '.json';
if(!file_exists($temp_file)) {
    echo json_encode(['status' => 'not_found']);
    exit();
}
$temp_data = json_decode(file_get_contents($temp_file), true);
echo json_encode(['status' => $temp_data['status'] ?? 'pending']);
?>