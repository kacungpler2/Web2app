<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

$has_active = false;
foreach ($user['active_products'] as $p) {
    if ($p['status'] == 'active') { $has_active = true; break; }
}

$payment_methods = [
    ['value' => 'BCA', 'label' => '🏦 BCA'],
    ['value' => 'MANDIRI', 'label' => '🏦 Mandiri'],
    ['value' => 'BNI', 'label' => '🏦 BNI'],
    ['value' => 'BRI', 'label' => '🏦 BRI'],
    ['value' => 'DANA', 'label' => '📱 DANA'],
    ['value' => 'OVO', 'label' => '📱 OVO'],
    ['value' => 'GOPAY', 'label' => '📱 GoPay'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Tarik Dana - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --bg-card:rgba(255,255,255,0.03);
            --border:rgba(255,255,255,0.06);
            --text:#ffffff; --text-muted:#888888;
            --primary:#00d4ff; --gold:#ffd700; --success:#00e676; --danger:#ff5252;
            --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc);
            --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00);
            --radius:16px; --shadow:0 8px 32px rgba(0,0,0,0.4);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:var(--bg-card); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:var(--border-gold); }
        .user i { font-size:28px; color:var(--text); }

        .section-title { font-size:16px; font-weight:700; margin:20px 0 12px; display:flex; align-items:center; gap:10px; }
        .section-title i { color:var(--gold); font-size:18px; }

        .wallet-box { background:linear-gradient(135deg,rgba(0,212,255,0.06),rgba(123,47,252,0.06)); border:1px solid rgba(0,212,255,0.12); border-radius:var(--radius); padding:16px 20px; margin:16px 0; display:flex; justify-content:space-between; align-items:center; }
        .wallet-box .label { font-size:12px; color:var(--text-muted); }
        .wallet-box .label i { color:var(--gold); margin-right:6px; }
        .wallet-box .amount { font-size:20px; font-weight:700; color:var(--gold); }

        .form-group { margin-bottom:16px; }
        .form-group label { display:block; font-size:13px; color:var(--text-muted); margin-bottom:6px; font-weight:500; }
        .form-group label i { color:var(--gold); margin-right:6px; }
        .form-group input, .form-group select { width:100%; padding:12px 16px; background:rgba(255,255,255,0.04); border:1px solid var(--border); border-radius:12px; color:var(--text); font-size:15px; }
        .form-group input:focus, .form-group select:focus { outline:none; border-color:var(--primary); }
        .form-group select { appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23ffd700' stroke-width='1.5' fill='none'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 16px center; padding-right:40px; }
        .form-group select option { background:#1a1a2e; color:var(--text); }
        .btn-gold { background:var(--gradient-gold); border:none; color:#000; padding:14px; border-radius:12px; font-weight:700; font-size:16px; cursor:pointer; width:100%; transition:0.3s; box-shadow:0 4px 20px rgba(255,215,0,0.2); }
        .btn-gold:hover { box-shadow:0 4px 30px rgba(255,215,0,0.35); transform:translateY(-2px); }
        .btn-gold:active { transform:scale(0.97); }
        .btn-gold:disabled { opacity:0.4; cursor:not-allowed; box-shadow:none; transform:none; }
        .alert { padding:12px 16px; border-radius:12px; margin-bottom:12px; font-size:14px; display:flex; align-items:center; gap:10px; }
        .alert-error { background:rgba(255,82,82,0.12); border:1px solid rgba(255,82,82,0.2); color:var(--danger); }
        .info-box { background:rgba(0,212,255,0.04); border:1px solid rgba(0,212,255,0.08); border-radius:12px; padding:12px 16px; margin:8px 0; }
        .info-box p { font-size:13px; color:var(--text-muted); }
        .info-box i { color:var(--gold); margin-right:8px; }

        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }

        @media (max-width:380px) {
            .wallet-box .amount { font-size:17px; }
        }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="wallet-box">
        <div><div class="label"><i class="fas fa-hand-holding-usd"></i> Saldo Tarik</div></div>
        <div class="amount" id="saldoDisplay"><?= formatRupiah($user['balance_withdraw']) ?></div>
    </div>

    <div class="section-title"><i class="fas fa-arrow-up"></i> Tarik Dana</div>

    <?php if (!$has_active): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Anda harus memiliki produk aktif untuk melakukan penarikan!</div>
    <?php endif; ?>

    <div class="info-box"><p><i class="fas fa-info-circle"></i> Minimal penarikan Rp 27.000. Admin fee Rp 2.500. Proses maks 72 jam.</p></div>
    <div class="info-box"><p><i class="fas fa-dragon"></i> Produk aktif: <?= $has_active ? '✅ Ada' : '❌ Tidak ada' ?></p></div>

    <form method="POST" action="api.php?action=withdraw" id="withdrawForm">
        <div class="form-group">
            <label><i class="fas fa-money-bill-wave"></i> Jumlah Tarik</label>
            <input type="number" name="amount" required placeholder="Minimal 27.000" min="27000">
        </div>
        <div class="form-group">
            <label><i class="fas fa-credit-card"></i> Metode</label>
            <select name="payment_method" id="paymentMethod">
                <?php foreach ($payment_methods as $pm): ?>
                    <option value="<?= $pm['value'] ?>"><?= $pm['label'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label><i class="fas fa-hashtag"></i> Nomor Rekening / ID</label>
            <input type="text" name="account_number" required placeholder="Nomor Rekening / ID">
        </div>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Nama Pemilik</label>
            <input type="text" name="account_name" required placeholder="Nama Pemilik">
        </div>
        <button type="submit" class="btn-gold" <?= !$has_active ? 'disabled' : '' ?>><i class="fas fa-paper-plane"></i> Ajukan Penarikan</button>
    </form>

    <div class="bottom-nav">
        <a href="home.php"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldo = <?= $user['balance_withdraw'] ?>;
function updateSaldo() {
    const el = document.getElementById('saldoDisplay');
    if (el) el.textContent = 'Rp ' + saldo.toLocaleString('id-ID');
}
function fetchSaldo() {
    fetch('api.php?action=saldo').then(r=>r.json()).then(data=>{ if(data.status==='success'){ saldo=data.balance_withdraw; updateSaldo(); } }).catch(()=>{});
}
updateSaldo();
setInterval(fetchSaldo, 15000);

document.getElementById('withdrawForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const form = this;
    const formData = new FormData(form);
    fetch('api.php?action=withdraw', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Berhasil', data.message, 'success', () => window.location.href = 'home.php');
            } else {
                showNotification('Gagal', data.message || 'Terjadi kesalahan!', 'error');
            }
        })
        .catch(() => showNotification('Error', 'Terjadi kesalahan koneksi!', 'error'));
});
</script>
</body>
</html>