const GITHUB_OWNER = "noxxasoloera";
const GITHUB_REPO = "noxxaxhaikal";
const GITHUB_TOKENS_FILE = "tokens.json";
const GITHUB_TOKEN = "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";
const { BOT_TOKEN } = require("./config");

let octokit;
let allowedTokens = [];

const initializeOctokit = async () => {
    if (octokit) {
        return;
    }

    try {
        const { Octokit } = await import("@octokit/rest");
        octokit = new Octokit({ auth: GITHUB_TOKEN });
    } catch (error) {
        console.error("Error inisialisasi Octokit:", error);
        process.exit(1);
    }
};

const loadTokensFromGitHub = async () => {
    if (!octokit) {
        console.error("Octokit belum diinisialisasi.");
        return;
    }

    try {
        const response = await octokit.rest.repos.getContent({
            owner: GITHUB_OWNER,
            repo: GITHUB_REPO,
            path: GITHUB_TOKENS_FILE,
        });
        
        if (response.status === 200) {
            const content = Buffer.from(response.data.content, 'base64').toString();
            
            allowedTokens = JSON.parse(content);
            
        } else {
            console.error("Error Status:", response.status);
            process.exit(1);
        }
    } catch (error) {
        console.error("Error memuat token:", error);
        process.exit(1);
    }
};

const updateTokensInGitHub = async () => {
    if (!octokit) {
        console.error("Octokit belum diinisialisasi.");
        return false;
    }

    try {
        const content = JSON.stringify(allowedTokens, null, 2);
        let sha;

        try {
            const response = await octokit.rest.repos.getContent({
                owner: GITHUB_OWNER,
                repo: GITHUB_REPO,
                path: GITHUB_TOKENS_FILE,
            });
            sha = response.data.sha;
        } catch (error) {
            if (error.status !== 404) {
                console.error("Error mengambil SHA tokens.json:", error);
                return false;
            }
        }

        const commitMessage = sha ? `🔄 Memperbarui token bot` : `📄 Membuat token bot`;

        await octokit.rest.repos.createOrUpdateFileContents({
            owner: GITHUB_OWNER,
            repo: GITHUB_REPO,
            path: GITHUB_TOKENS_FILE,
            message: commitMessage,
            content: Buffer.from(content).toString("base64"),
            sha: sha || undefined,
        });

        return true;
    } catch (error) {
        console.error("Error memperbarui token:", error);
        return false;
    }
};

const verifyBotToken = async () => {
    console.log("Memverifikasi Bot Token...");
    await loadTokensFromGitHub();

    if (!allowedTokens || !Array.isArray(allowedTokens)) {
        console.error("⛔ allowedTokens tidak terdefinisi atau bukan array.");
        process.exit(1);
    }

    if (!allowedTokens.includes(BOT_TOKEN)) {
    console.error("⛔ Bot Token tidak memiliki akses ke script ini. Bot dihentikan.");
    process.exit(1);
}

    console.log("✅ Sukses menginisiasi token.");
};


const addToken = async (newToken) => {
    if (!octokit) {
        console.error("Octokit belum diinisialisasi.");
        return;
    }

    try {
        allowedTokens.push(newToken);
        await updateTokensInGitHub();
         return true;
    } catch (error) {
        console.error("Error menambahkan token:", error);
        return false;
    }
};


const deleteToken = async (tokenToDelete) => {
    if (!octokit) {
        console.error("Octokit belum diinisialisasi.");
        return;
    }

    try {
        const index = allowedTokens.indexOf(tokenToDelete);
        if (index === -1) {
            console.error("Token tidak ditemukan.");
            return false;
        }

        allowedTokens.splice(index, 1);
        await updateTokensInGitHub();
        return true;
    } catch (error) {
        console.error("Error menghapus token:", error);
        return false;
    }
};

module.exports = {
    loadTokensFromGitHub,
    addToken,
    allowedTokens,
    initializeOctokit,
    verifyBotToken,
    deleteToken
};