module.exports = {
  BOT_TOKEN: "8449659201:AAFLZdKdILcZpn_41CRW3mA5OtkfBpXbiqg",
    allowedDevelopers: ['7579064697'], // ID
};