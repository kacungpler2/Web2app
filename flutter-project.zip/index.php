<?php
error_reporting(0);
session_start();

$db_file = 'data/db.json';
if (!file_exists($db_file)) {
    die('Database tidak ditemukan. Upload db.json ke folder data/');
}

$db = json_decode(file_get_contents($db_file), true);

if (isset($_SESSION['user'])) {
    header('Location: home.php');
    exit();
}

$error = '';
$success = '';
$ref_code = $_GET['ref'] ?? '';
$show_register = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'register') {
        $username = trim($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $ref = trim($_POST['ref_code'] ?? '');
        
        if (strlen($username) < 3) {
            $error = 'Username minimal 3 karakter!';
        } elseif (strlen($_POST['password']) < 6) {
            $error = 'Password minimal 6 karakter!';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Email tidak valid!';
        } elseif (strlen($phone) < 10) {
            $error = 'Nomor WA minimal 10 digit!';
        } else {
            $exists = false;
            foreach ($db['users'] as $u) {
                if ($u['username'] == $username) { $exists = true; $error = 'Username sudah digunakan!'; break; }
                if ($u['email'] == $email) { $exists = true; $error = 'Email sudah terdaftar!'; break; }
            }
            if (!$error) {
                $new_ref = strtoupper(substr($username, 0, 3) . rand(100, 999));
                $ref_user = null;
                if ($ref) {
                    foreach ($db['users'] as $u) {
                        if ($u['referral_code'] == $ref) {
                            $ref_user = $u;
                            break;
                        }
                    }
                }
                $new_user = [
                    'id' => 'USR' . rand(100000, 999999),
                    'username' => $username,
                    'password' => $password,
                    'email' => $email,
                    'phone' => $phone,
                    'referral_code' => $new_ref,
                    'referred_by' => $ref,
                    'balance_deposit' => 2000,
                    'balance_withdraw' => 0,
                    'total_deposit' => 0,
                    'total_withdraw' => 0,
                    'total_profit' => 0,
                    'is_admin' => false,
                    'referral_count' => 0,
                    'referral_list' => [],
                    'active_products' => [],
                    'product_history' => [],
                    'referral_earnings' => ['level1' => 0, 'level2' => 0, 'level3' => 0],
                    'created_at' => date('Y-m-d H:i:s'),
                    'last_login' => date('Y-m-d H:i:s')
                ];
                $db['users'][] = $new_user;
                if ($ref_user) {
                    $ref_user['balance_withdraw'] += 1000;
                    $ref_user['referral_count'] += 1;
                    $ref_user['referral_list'][] = [
                        'username' => $username,
                        'email' => $email,
                        'phone' => $phone,
                        'joined_at' => date('Y-m-d H:i:s')
                    ];
                    foreach ($db['users'] as &$u) {
                        if ($u['id'] == $ref_user['id']) {
                            $u = $ref_user;
                            break;
                        }
                    }
                }
                file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
                $_SESSION['user'] = $new_user;
                $success = 'Daftar berhasil! Selamat datang ' . $username . '!';
                // Auto redirect after 2 seconds, but show notification first
                echo '<script>
                    setTimeout(function() {
                        window.location.href = "home.php";
                    }, 3000);
                </script>';
            }
        }
    }
    
    if ($action == 'login') {
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        foreach ($db['users'] as &$u) {
            if ($u['username'] == $username && password_verify($password, $u['password'])) {
                $u['last_login'] = date('Y-m-d H:i:s');
                $_SESSION['user'] = $u;
                file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
                header('Location: home.php');
                exit();
            }
        }
        $error = 'Username atau password salah!';
    }
}

// Jika ada ref di URL, tampilkan register
if ($ref_code) {
    $show_register = true;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Ternak Naga - Login</title>

<meta name="description" content="Ternak Naga - Platform investasi digital dengan sistem referral dan bonus menarik.">

<meta property="og:title" content="🐉 Ternak Naga">
<meta property="og:description" content="Gabung sekarang dan mulai investasi di Ternak Naga.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://domainkamu.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root { --bg:#0a0a0f; --bg-card:rgba(255,255,255,0.03); --border:rgba(255,255,255,0.06); --border-gold:rgba(255,215,0,0.15); --text:#ffffff; --text-muted:#888888; --primary:#00d4ff; --gold:#ffd700; --gold-dark:#f59f00; --success:#00e676; --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc); --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00); --radius:16px; --shadow:0 8px 32px rgba(0,0,0,0.4); }
        body { background:var(--bg); color:var(--text); min-height:100vh; }
        .auth-container { max-width:430px; margin:0 auto; padding:40px 20px; min-height:100vh; display:flex; align-items:center; justify-content:center; }
        .auth-card { background:var(--bg-card); border:1px solid var(--border-gold); border-radius:24px; padding:32px 24px; width:100%; box-shadow:var(--shadow); position:relative; overflow:hidden; }
        .auth-card::before { content:''; position:absolute; top:-50%; right:-50%; width:100%; height:100%; background:radial-gradient(circle,rgba(255,215,0,0.03),transparent 70%); pointer-events:none; }
        .auth-header { text-align:center; margin-bottom:28px; position:relative; z-index:1; }
        .auth-header i { font-size:52px; color:var(--gold); filter:drop-shadow(0 0 30px rgba(255,215,0,0.15)); }
        .auth-header h2 { font-size:26px; font-weight:800; margin-top:8px; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .auth-header p { color:var(--text-muted); font-size:14px; margin-top:4px; }
        .form-group { margin-bottom:16px; position:relative; z-index:1; }
        .form-group label { display:block; font-size:13px; color:var(--text-muted); margin-bottom:6px; font-weight:500; }
        .form-group label i { color:var(--gold); margin-right:6px; }
        .form-group input { width:100%; padding:12px 16px; background:rgba(255,255,255,0.04); border:1px solid var(--border); border-radius:12px; color:var(--text); font-size:15px; transition:0.3s; }
        .form-group input:focus { outline:none; border-color:var(--primary); box-shadow:0 0 0 3px rgba(0,212,255,0.1); }
        .btn-primary { background:var(--gradient); border:none; color:#fff; padding:14px; border-radius:12px; font-weight:700; font-size:16px; cursor:pointer; width:100%; transition:0.3s; box-shadow:0 4px 20px rgba(0,212,255,0.2); position:relative; z-index:1; }
        .btn-primary:hover { box-shadow:0 4px 30px rgba(0,212,255,0.35); transform:translateY(-2px); }
        .btn-primary:active { transform:scale(0.97); }
        .btn-gold { background:var(--gradient-gold); border:none; color:#000; padding:14px; border-radius:12px; font-weight:700; font-size:16px; cursor:pointer; width:100%; transition:0.3s; box-shadow:0 4px 20px rgba(255,215,0,0.2); position:relative; z-index:1; }
        .btn-gold:hover { box-shadow:0 4px 30px rgba(255,215,0,0.35); transform:translateY(-2px); }
        .btn-gold:active { transform:scale(0.97); }
        .btn-secondary { background:rgba(255,255,255,0.06); border:1px solid var(--border); color:var(--text); padding:12px; border-radius:12px; font-weight:600; font-size:15px; cursor:pointer; width:100%; transition:0.3s; position:relative; z-index:1; }
        .btn-secondary:hover { background:rgba(255,255,255,0.1); border-color:var(--border-gold); }
        .btn-secondary:active { transform:scale(0.97); }
        .alert { padding:14px 18px; border-radius:12px; margin-bottom:14px; font-size:14px; display:flex; align-items:center; gap:10px; border:1px solid transparent; position:relative; z-index:1; }
        .alert-error { background:rgba(255,82,82,0.12); border-color:rgba(255,82,82,0.25); color:#ff5252; }
        .alert-success { background:rgba(0,230,118,0.08); border-color:rgba(0,230,118,0.2); color:var(--success); }
        .hidden { display:none !important; }
        .auth-divider { display:flex; align-items:center; gap:12px; margin:16px 0; position:relative; z-index:1; }
        .auth-divider::before, .auth-divider::after { content:''; flex:1; height:1px; background:var(--border); }
        .auth-divider span { font-size:12px; color:var(--text-muted); white-space:nowrap; }

        /* ===== NOTIFIKASI DAFTAR BERHASIL ===== */
        .register-success {
            text-align:center;
            padding:20px 0;
            position:relative;
            z-index:1;
        }
        .register-success .icon {
            font-size:64px;
            color:var(--success);
            margin-bottom:12px;
            display:block;
        }
        .register-success h3 {
            font-size:22px;
            font-weight:700;
            color:var(--text);
        }
        .register-success p {
            color:var(--text-muted);
            font-size:14px;
            margin-top:4px;
        }
        .register-success .btn-join {
            background:linear-gradient(135deg, #25D366, #128C7E);
            border:none;
            color:#fff;
            padding:14px 32px;
            border-radius:30px;
            font-weight:700;
            font-size:16px;
            cursor:pointer;
            transition:0.3s;
            margin-top:16px;
            box-shadow:0 4px 20px rgba(37,211,102,0.3);
            display:inline-flex;
            align-items:center;
            gap:8px;
        }
        .register-success .btn-join:hover {
            box-shadow:0 4px 30px rgba(37,211,102,0.45);
            transform:translateY(-2px);
        }
        .register-success .btn-join:active { transform:scale(0.95); }
        .register-success .redirect-note {
            font-size:12px;
            color:var(--text-muted);
            margin-top:12px;
        }

        @media (max-width:380px) {
            .auth-card { padding:24px 16px; }
            .auth-header i { font-size:40px; }
            .auth-header h2 { font-size:22px; }
        }
    </style>
</head>
<body>
<div class="auth-container">
    <div class="auth-card">

        <!-- ===== AUTH HEADER ===== -->
        <div class="auth-header">
            <i class="fas fa-dragon"></i>
            <h2>Ternak Naga</h2>
            <p>Investasi ternak naga, profit otomatis setiap jam!</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <!-- ===== NOTIFIKASI DAFTAR BERHASIL ===== -->
            <div class="register-success">
                <span class="icon"><i class="fas fa-check-circle"></i></span>
                <h3>✅ Daftar Berhasil!</h3>
                <p>Selamat datang, <?= htmlspecialchars($username ?? '') ?>! Akun Anda sudah aktif.</p>
                <a href="https://chat.whatsapp.com/yourgroup" target="_blank" class="btn-join">
                    <i class="fab fa-whatsapp"></i> JOIN GRUP WA
                </a>
                <div class="redirect-note">⏳ Mengalihkan ke dashboard dalam 3 detik...</div>
            </div>
            <script>
                setTimeout(function() {
                    window.location.href = "home.php";
                }, 3000);
            </script>
        <?php else: ?>

            <!-- ===== LOGIN FORM ===== -->
            <form method="POST" id="loginForm" class="<?= $show_register ? 'hidden' : '' ?>">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Username</label>
                    <input type="text" name="username" required placeholder="Masukkan username">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" required placeholder="Masukkan password">
                </div>
                <button type="submit" class="btn-primary"><i class="fas fa-arrow-right"></i> Login</button>
                <div class="auth-divider"><span>atau</span></div>
                <button type="button" class="btn-secondary" onclick="showRegister()">
                    <i class="fas fa-user-plus"></i> DAFTAR
                </button>
            </form>

            <!-- ===== REGISTER FORM ===== -->
            <form method="POST" id="registerForm" class="<?= $show_register ? '' : 'hidden' ?>">
                <input type="hidden" name="action" value="register">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Username</label>
                    <input type="text" name="username" required placeholder="Minimal 3 karakter">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" required placeholder="Minimal 6 karakter">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" required placeholder="Email aktif">
                </div>
                <div class="form-group">
                    <label><i class="fab fa-whatsapp"></i> Nomor WA</label>
                    <input type="text" name="phone" required placeholder="08123456789">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-gift"></i> Kode Referral</label>
                    <input type="text" name="ref_code" placeholder="Masukkan kode referral" value="<?= htmlspecialchars($ref_code) ?>">
                </div>
                <button type="submit" class="btn-gold"><i class="fas fa-check"></i> Daftar</button>
                <div class="auth-divider"><span>atau</span></div>
                <button type="button" class="btn-secondary" onclick="showLogin()">
                    <i class="fas fa-arrow-left"></i> Login
                </button>
            </form>

            <?php if ($ref_code): ?>
                <script>
                    document.getElementById('loginForm').classList.add('hidden');
                    document.getElementById('registerForm').classList.remove('hidden');
                </script>
            <?php endif; ?>

        <?php endif; ?>

    </div>
</div>

<script>
function showRegister() {
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('registerForm').classList.remove('hidden');
}

function showLogin() {
    document.getElementById('registerForm').classList.add('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
}
</script>
</body>
</html>