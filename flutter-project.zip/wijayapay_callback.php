<?php
error_reporting(0);
require_once 'wijayapay_config.php';

$json = file_get_contents('php://input');
$data = json_decode($json, true);
$log_dir = __DIR__ . '/data/callback_logs';
if(!is_dir($log_dir)) mkdir($log_dir, 0777, true);
file_put_contents($log_dir . '/' . date('Y-m-d_H-i-s') . '.json', $json);

$signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
$ref_id = $data['data']['ref_id'] ?? '';

if(!empty($ref_id) && !wijayapay_verify_signature($signature, $ref_id)) {
    http_response_code(403);
    echo json_encode(['status' => false, 'message' => 'Invalid signature']);
    exit();
}

if(isset($data['status']) && $data['status'] == 'paid') {
    $ref_id = $data['data']['ref_id'] ?? '';
    $trx_reference = $data['data']['trx_reference'] ?? '';
    if(!empty($ref_id)) {
        $temp_file = __DIR__ . '/data/temp_payments/' . $ref_id . '.json';
        if(file_exists($temp_file)) {
            $temp_data = json_decode(file_get_contents($temp_file), true);
            if($temp_data['status'] != 'success') {
                $temp_data['status'] = 'success';
                $temp_data['paid_at'] = date('Y-m-d H:i:s');
                file_put_contents($temp_file, json_encode($temp_data, JSON_PRETTY_PRINT));
                $db_file = __DIR__ . '/data/db.json';
                $db = json_decode(file_get_contents($db_file), true);
                foreach($db['users'] as &$u) {
                    if($u['id'] == $temp_data['user_id']) {
                        $u['balance_deposit'] += $temp_data['amount'];
                        break;
                    }
                }
                $db['transactions']['deposits'][] = [
                    'id' => 'DEP' . date('Ymd') . rand(100, 999),
                    'user_id' => $temp_data['user_id'],
                    'username' => $temp_data['username'],
                    'amount' => $temp_data['amount'],
                    'method' => 'wijayapay_qris',
                    'ref_id' => $ref_id,
                    'trx_reference' => $trx_reference,
                    'status' => 'approved',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
            }
        }
    }
}
http_response_code(200);
echo json_encode(['status' => true]);
?>