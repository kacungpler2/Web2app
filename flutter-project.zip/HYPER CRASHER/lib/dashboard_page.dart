// dashboard_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import '.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // === TEMA WARNA ABU-ABU ===
  final Color bgDark = Colors.black;
  final Color primaryDark = const Color(0xFF1A1A1A); // Diubah dari merah ke abu-abu gelap
  final Color accentDark = const Color(0xFF2A2A2A); // Diubah dari merah ke abu-abu
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = const Color(0xFF2A2A2A); // Diubah dari merah ke abu-abu
  final Color borderGlass = const Color(0xFF4A4A4A); // Diubah dari merah ke abu-abu
  final Color primaryGray = const Color(0xFF616161); // Diubah dari merah ke abu-abu
  final Color grayGlow = const Color(0x554A4A4A); // Diubah dari merah ke abu-abu
  final Color lightGray = const Color(0xFF9E9E9E); // Diubah dari merah ke abu-abu
  final Color liveGreen = const Color(0xFF22C55E);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('$apiBaseUrl'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: primaryDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired",
            style: TextStyle(color: lightGray, fontWeight: FontWeight.bold)), // Diubah dari lightRed ke lightGray
        content: Text(message, style: TextStyle(color: accentGrey)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK",
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      }
    });
    Navigator.pop(context);
  }

  // ===================== NEWS PAGE =====================
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),

          // === STATS CARD: Online & Koneksi + LIVE ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderGlass, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: grayGlow, // Diubah dari redGlow ke grayGlow
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(child: _buildStatItem(icon: Icons.people_alt_outlined, label: "Online", value: "$onlineUsers")),
                  Container(width: 1, height: 36, color: borderGlass),
                  Expanded(child: _buildStatItem(icon: Icons.wifi_rounded, label: "Koneksi", value: "$activeConnections")),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: liveGreen.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: liveGreen.withOpacity(0.5), width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            color: liveGreen,
                            shape: BoxShape.circle,
                            boxShadow: [BoxShadow(color: liveGreen, blurRadius: 6)],
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text("LIVE", style: TextStyle(color: liveGreen, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 22),

          // === BERITA TERBARU ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(width: 3, height: 18, decoration: BoxDecoration(color: primaryGray, borderRadius: BorderRadius.circular(4), boxShadow: [BoxShadow(color: grayGlow, blurRadius: 8)])), // Diubah dari primaryRed ke primaryGray
                    const SizedBox(width: 8),
                    const Text("Berita Terbaru", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                  ],
                ),
                Text("${newsList.length} artikel", style: TextStyle(color: accentGrey, fontSize: 12, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // News Slider
          SizedBox(
            height: 200,
            child: newsList.isEmpty
                ? Center(child: Text("Tidak ada berita", style: TextStyle(color: accentGrey)))
                : PageView.builder(
                    controller: PageController(viewportFraction: 0.92),
                    itemCount: newsList.length,
                    itemBuilder: (context, index) {
                      final item = newsList[index];
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: cardGlass,
                          border: Border.all(color: borderGlass),
                          boxShadow: [BoxShadow(color: grayGlow, blurRadius: 12, offset: const Offset(0, 5))], // Diubah dari redGlow ke grayGlow
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (item['image'] != null && item['image'].toString().isNotEmpty) NewsMedia(url: item['image']),
                              Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black.withOpacity(0.7), Colors.transparent], begin: Alignment.bottomCenter, end: Alignment.topCenter))),
                              Positioned(
                                top: 12,
                                left: 12,
                                child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: primaryGray, borderRadius: BorderRadius.circular(6)), child: const Text("NEWS", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1))), // Diubah dari primaryRed ke primaryGray
                              ),
                              Positioned(
                                top: 12,
                                right: 12,
                                child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(6)), child: Text("${index + 1}/${newsList.length}", style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'ShareTechMono'))),
                              ),
                              Positioned(
                                bottom: 14,
                                left: 14,
                                right: 14,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item['title'] ?? 'No Title', style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                                    const SizedBox(height: 3),
                                    Text(item['desc'] ?? '', style: TextStyle(color: Colors.white.withOpacity(0.7), fontFamily: "ShareTechMono", fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),

          const SizedBox(height: 24),

          // === AKSI CEPAT ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Container(width: 3, height: 18, decoration: BoxDecoration(color: primaryGray, borderRadius: BorderRadius.circular(4), boxShadow: [BoxShadow(color: grayGlow, blurRadius: 8)])), // Diubah dari primaryRed ke primaryGray
                const SizedBox(width: 8),
                const Text("Aksi Cepat", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Info Channel Card
          _buildAksiCepatCard(
            icon: FontAwesomeIcons.telegram,
            iconColor: const Color(0xFF29B6F6),
            iconBg: const Color(0xFF0D1A2E),
            title: "Info Channel",
            subtitle: "Join Info Channel",
            buttonLabel: "Join",
            onTap: () => _openUrl("https://t.me/denzeer"),
          ),

          const SizedBox(height: 10),

          // Bug Sender Card
          _buildAksiCepatCard(
            icon: Icons.wifi_tethering_rounded,
            iconColor: lightGray, // Diubah dari lightRed ke lightGray
            iconBg: const Color(0xFF2A2A2A), // Diubah dari merah ke abu-abu
            title: "Bug Sender",
            subtitle: "Kelola WhatsApp sender aktif",
            buttonLabel: "Buka",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BugSenderPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 10),

          // === CARD UCAPAN ===
          _buildAksiCepatCard(
            icon: Icons.card_giftcard_rounded,
            iconColor: const Color(0xFFFFB74D),
            iconBg: const Color(0xFF2D1F0A),
            title: "Ucapan",
            subtitle: "Kirim ucapan spesial untuk teman",
            buttonLabel: "Buka",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const UcapanPage(),
                ),
              );
            },
          ),

          const SizedBox(height: 10),

          // === CARD TOKO (BARU) ===
          _buildAksiCepatCard(
            icon: Icons.shopping_bag_rounded,
            iconColor: const Color(0xFF4CAF50),
            iconBg: const Color(0xFF0A2E1A),
            title: "Toko",
            subtitle: "Belanja produk eksklusif",
            buttonLabel: "Lihat",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const TokoPage(),
                ),
              );
            },
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }

  // ===================== AKSI CEPAT CARD =====================
  Widget _buildAksiCepatCard({
    required IconData icon,
    required Color iconColor,
    required Color iconBg,
    required String title,
    required String subtitle,
    required String buttonLabel,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderGlass, width: 1),
          boxShadow: [BoxShadow(color: grayGlow, blurRadius: 10, offset: const Offset(0, 4))], // Diubah dari redGlow ke grayGlow
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(14), border: Border.all(color: borderGlass)),
              child: Icon(icon, color: iconColor, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                  const SizedBox(height: 3),
                  Text(subtitle, style: TextStyle(color: accentGrey, fontSize: 12, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: onTap,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                decoration: BoxDecoration(
                  color: primaryGray.withOpacity(0.2), // Diubah dari primaryRed ke primaryGray
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: primaryGray.withOpacity(0.5)), // Diubah dari primaryRed ke primaryGray
                ),
                child: Text(buttonLabel, style: TextStyle(color: lightGray, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')), // Diubah dari lightRed ke lightGray
              ),
            ),
          ],
        ),
      ),
    );
  }
}