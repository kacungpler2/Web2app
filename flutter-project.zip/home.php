<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db_file = 'data/db.json';
$db = json_decode(file_get_contents($db_file), true);
$user = $_SESSION['user'];

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Profit otomatis setiap 1 jam
foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        foreach ($u['active_products'] as &$p) {
            if ($p['status'] == 'active') {
                $last = strtotime($p['last_profit'] ?? $p['bought_at']);
                $now = time();
                $interval = 3600;
                $bought = strtotime($p['bought_at']);
                $expired = $bought + ($p['duration_days'] * 86400);
                if ($now > $expired) {
                    $p['status'] = 'expired';
                    continue;
                }
                if ($now - $last >= $interval && $p['profit_count'] < $p['total_profit_count']) {
                    $p['profit_count']++;
                    $u['balance_withdraw'] += $p['profit_per_hour'];
                    $u['total_profit'] += $p['profit_per_hour'];
                    $p['last_profit'] = date('Y-m-d H:i:s');
                    $db['transactions']['profits'][] = [
                        'id' => 'PRF' . date('Ymd') . rand(100, 999),
                        'user_id' => $u['id'],
                        'username' => $u['username'],
                        'product_id' => $p['product_id'],
                        'product_name' => $p['name'],
                        'amount' => $p['profit_per_hour'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        $_SESSION['user'] = $u;
        break;
    }
}
file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));

foreach ($db['users'] as &$u) {
    if ($u['id'] == $user['id']) {
        $user = $u;
        $_SESSION['user'] = $u;
        break;
    }
}

$active_products = 0;
$total_profit_per_day = 0;
$total_profit_per_hour = 0;
foreach ($user['active_products'] as $p) {
    if ($p['status'] == 'active') {
        $active_products++;
        $total_profit_per_day += $p['profit_per_hour'] * 24;
        $total_profit_per_hour += $p['profit_per_hour'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Home - Ternak Naga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',system-ui,sans-serif; }
        :root {
            --bg:#0a0a0f;
            --bg-card:rgba(255,255,255,0.04);
            --border:rgba(255,255,255,0.06);
            --border-gold:rgba(255,215,0,0.15);
            --text:#ffffff;
            --text-muted:#888888;
            --primary:#00d4ff;
            --gold:#ffd700;
            --gold-dark:#f59f00;
            --success:#00e676;
            --gradient:linear-gradient(135deg,#00d4ff,#7b2ffc);
            --gradient-gold:linear-gradient(135deg,#ffd700,#f59f00);
            --radius:16px;
            --shadow:0 8px 32px rgba(0,0,0,0.4);
        }
        body { background:var(--bg); color:var(--text); min-height:100vh; padding-bottom:80px; }
        .app { max-width:430px; margin:0 auto; padding:0 16px 80px; }

        .header { display:flex; justify-content:space-between; align-items:center; padding:16px 0; border-bottom:1px solid var(--border); }
        .logo { display:flex; align-items:center; gap:10px; }
        .logo i { font-size:24px; color:var(--gold); }
        .logo h1 { font-size:20px; font-weight:800; background:var(--gradient-gold); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .logo h1 span { -webkit-text-fill-color:var(--primary); }
        .user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--text-muted); cursor:pointer; padding:6px 12px; border-radius:30px; background:var(--bg-card); border:1px solid var(--border); }
        .user:hover { color:var(--text); border-color:var(--border-gold); }
        .user i { font-size:28px; color:var(--text); }

        .wallet { background:linear-gradient(135deg,rgba(0,212,255,0.06),rgba(123,47,252,0.06)); border:1px solid rgba(0,212,255,0.12); border-radius:var(--radius); padding:16px 20px; margin:16px 0; }
        .wallet .row { display:flex; justify-content:space-between; align-items:center; padding:4px 0; }
        .wallet .label { font-size:12px; color:var(--text-muted); display:flex; align-items:center; gap:6px; }
        .wallet .label i { color:var(--gold); font-size:14px; }
        .wallet .amount { font-size:18px; font-weight:700; }
        .wallet .amount.deposit { color:var(--primary); }
        .wallet .amount.withdraw { color:var(--gold); }
        .wallet .actions { display:flex; gap:10px; margin-top:8px; }
        .wallet .actions a { text-decoration:none; display:flex; align-items:center; justify-content:center; gap:6px; padding:8px 16px; border-radius:12px; font-weight:600; font-size:12px; transition:0.3s; flex:1; }
        .wallet .actions a:active { transform:scale(0.96); }
        .wallet .actions .btn-deposit { background:var(--gradient); color:#fff; }
        .wallet .actions .btn-withdraw { background:var(--gradient-gold); color:#000; }

        .hero { text-align:center; padding:20px 0 10px; }
        .hero .icon { font-size:56px; color:var(--gold); margin-bottom:8px; animation:float 3s ease-in-out infinite; display:block; }
        @keyframes float { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-10px); } }
        .hero h2 { font-size:20px; font-weight:700; }
        .hero p { color:var(--text-muted); font-size:13px; margin-top:4px; line-height:1.6; }

        .stats-row { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin:12px 0; }
        .stats-row .stat { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:14px; text-align:center; transition:0.3s; }
        .stats-row .stat:hover { border-color:var(--border-gold); }
        .stats-row .stat .num { font-size:20px; font-weight:700; color:var(--gold); }
        .stats-row .stat .lbl { font-size:10px; color:var(--text-muted); margin-top:2px; }

        .profit-box { background:var(--bg-card); border:1px solid var(--border-gold); border-radius:var(--radius); padding:16px; margin:12px 0; }
        .profit-box .row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid var(--border); }
        .profit-box .row:last-child { border-bottom:none; }
        .profit-box .row .label { color:var(--text-muted); font-size:13px; }
        .profit-box .row .label i { color:var(--gold); margin-right:6px; }
        .profit-box .row .value { font-weight:700; font-size:15px; color:var(--success); }
        .profit-box .total-row { display:flex; justify-content:space-between; padding:8px 0 0; border-top:2px solid var(--border-gold); margin-top:4px; }
        .profit-box .total-row .label { font-weight:700; color:var(--gold); font-size:14px; }
        .profit-box .total-row .value { font-weight:700; font-size:16px; color:var(--gold); }

        .bottom-nav {
            position:fixed; bottom:0; left:50%; transform:translateX(-50%);
            max-width:430px; width:100%;
            display:grid; grid-template-columns:repeat(5,1fr);
            background:rgba(10,10,15,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(255,215,0,0.08);
            padding:8px 0 env(safe-area-inset-bottom,8px);
            z-index:100;
        }
        .bottom-nav a {
            display:flex; flex-direction:column; align-items:center;
            text-decoration:none; color:var(--text-muted); font-size:9px;
            padding:4px 0; transition:0.3s; position:relative;
            text-transform:uppercase; letter-spacing:0.3px;
        }
        .bottom-nav a i { font-size:20px; margin-bottom:2px; transition:0.3s; }
        .bottom-nav a span { transition:0.3s; font-weight:600; }
        .bottom-nav a .dot { width:4px; height:4px; border-radius:50%; background:var(--gold); margin-top:2px; opacity:0; transition:0.3s; }
        .bottom-nav a.active { color:var(--gold); }
        .bottom-nav a.active i { transform:scale(1.15); text-shadow:0 0 20px rgba(255,215,0,0.3); }
        .bottom-nav a.active span { color:var(--gold); }
        .bottom-nav a.active .dot { opacity:1; }

        @media (max-width:380px) {
            .wallet .amount { font-size:16px; }
            .stats-row { grid-template-columns:1fr; }
        }
    </style>
</head>
<body>
<div class="app">

    <div class="header">
        <div class="logo"><i class="fas fa-dragon"></i><h1>Ternak<span>Naga</span></h1></div>
        <div class="user" onclick="window.location.href='profil.php'">
            <span><?= htmlspecialchars($user['username']) ?></span>
            <i class="fas fa-user-circle"></i>
        </div>
    </div>

    <div class="wallet">
        <div class="row">
            <span class="label"><i class="fas fa-coins"></i> Saldo Deposit</span>
            <span class="amount deposit" id="saldoDeposit"><?= formatRupiah($user['balance_deposit']) ?></span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-hand-holding-usd"></i> Saldo Tarik</span>
            <span class="amount withdraw" id="saldoWithdraw"><?= formatRupiah($user['balance_withdraw']) ?></span>
        </div>
        <div class="actions">
            <a href="deposit.php" class="btn-deposit"><i class="fas fa-plus-circle"></i> Deposit</a>
            <a href="withdraw.php" class="btn-withdraw"><i class="fas fa-arrow-up"></i> Tarik</a>
        </div>
    </div>

    <div class="hero">
        <span class="icon">🐉</span>
        <h2>Selamat Datang, <?= htmlspecialchars($user['username']) ?>!</h2>
        <p>Profit otomatis setiap jam. Kelola naga Anda dengan bijak.</p>
    </div>

    <div class="stats-row">
        <div class="stat"><div class="num"><?= $active_products ?></div><div class="lbl">Naga Aktif</div></div>
        <div class="stat"><div class="num"><?= formatRupiah($user['total_profit']) ?></div><div class="lbl">Total Profit</div></div>
    </div>

    <div class="profit-box">
        <div class="row">
            <span class="label"><i class="fas fa-clock"></i> Profit Per Jam</span>
            <span class="value"><?= formatRupiah($total_profit_per_hour) ?></span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-calendar-day"></i> Profit Per Hari</span>
            <span class="value"><?= formatRupiah($total_profit_per_day) ?></span>
        </div>
        <div class="total-row">
            <span class="label"><i class="fas fa-dragon"></i> Total Naga Aktif</span>
            <span class="value"><?= $active_products ?> ekor</span>
        </div>
    </div>

    <div class="bottom-nav">
        <a href="home.php" class="active"><i class="fas fa-home"></i><span>Home</span><div class="dot"></div></a>
        <a href="produk.php"><i class="fas fa-dragon"></i><span>Produk</span><div class="dot"></div></a>
        <a href="riwayat.php"><i class="fas fa-history"></i><span>Riwayat</span><div class="dot"></div></a>
        <a href="tim.php"><i class="fas fa-users"></i><span>Tim</span><div class="dot"></div></a>
        <a href="profil.php"><i class="fas fa-user"></i><span>Profil</span><div class="dot"></div></a>
    </div>

</div>
<script src="script.js"></script>
<script>
saldoDeposit = <?= $user['balance_deposit'] ?>;
saldoWithdraw = <?= $user['balance_withdraw'] ?>;
updateSaldoUI();
setInterval(fetchSaldo, 30000);
</script>
</body>
</html>