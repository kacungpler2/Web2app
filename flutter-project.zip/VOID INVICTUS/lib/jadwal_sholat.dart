import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart'; // PENTING: Diimport untuk fix crash

class JadwalSholatPage extends StatefulWidget {
  const JadwalSholatPage({super.key});

  @override
  State<JadwalSholatPage> createState() => _JadwalSholatPageState();
}

class _JadwalSholatPageState extends State<JadwalSholatPage> {
  DateTime selectedDate = DateTime.now();
  bool isLocaleInitialized = false; // Flag penanda locale sudah siap
  
  // Jadwal sholat FIXED (contoh jam untuk wilayah Indonesia)
  final Map<String, String> jadwalSholat = {
    "Subuh": "04:30",
    "Dzuhur": "12:00",
    "Ashar": "15:30",
    "Maghrib": "18:00",
    "Isya": "19:30",
  };
  
  // --- BLACKENED BLUE HD ULTRA THEME ---
  static const Color bgDark = Color(0xFF808080);           // Blackened Abyss Background
  static const Color accentBlue = Color(0xFF00E5FF);       // Cyber Neon Cyan
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFFA0A0A0);
  static const Color successGreen = Color(0xFF4CAF50);

  @override
  void initState() {
    super.initState();
    // FIX CRASH: Inisialisasi locale Indonesia
    initializeDateFormatting('id_ID', null).then((_) {
      if (mounted) {
        setState(() {
          isLocaleInitialized = true;
        });
      }
    });
  }

  String getCurrentTime() {
    return DateFormat('HH : mm : ss').format(DateTime.now());
  }
  
  String getCurrentTimeStatus() {
    final hour = DateTime.now().hour;
    if (hour >= 3 && hour < 11) return "Pagi";
    if (hour >= 11 && hour < 15) return "Siang";
    if (hour >= 15 && hour < 18) return "Sore";
    return "Malam";
  }
  
  String getNextPrayer() {
    final now = DateTime.now();
    final currentHour = now.hour;
    final currentMinute = now.minute;
    final currentTime = currentHour * 60 + currentMinute;
    
    final List<Map<String, dynamic>> prayers = [
      {"name": "Subuh", "time": _parseTime(jadwalSholat["Subuh"]!)},
      {"name": "Dzuhur", "time": _parseTime(jadwalSholat["Dzuhur"]!)},
      {"name": "Ashar", "time": _parseTime(jadwalSholat["Ashar"]!)},
      {"name": "Maghrib", "time": _parseTime(jadwalSholat["Maghrib"]!)},
      {"name": "Isya", "time": _parseTime(jadwalSholat["Isya"]!)},
    ];
    
    for (var prayer in prayers) {
      if (prayer["time"] > currentTime) {
        return prayer["name"];
      }
    }
    return "Subuh";
  }
  
  String getNextPrayerTime() {
    final now = DateTime.now();
    final currentHour = now.hour;
    final currentMinute = now.minute;
    final currentTime = currentHour * 60 + currentMinute;
    
    final List<Map<String, dynamic>> prayers = [
      {"name": "Subuh", "time": _parseTime(jadwalSholat["Subuh"]!)},
      {"name": "Dzuhur", "time": _parseTime(jadwalSholat["Dzuhur"]!)},
      {"name": "Ashar", "time": _parseTime(jadwalSholat["Ashar"]!)},
      {"name": "Maghrib", "time": _parseTime(jadwalSholat["Maghrib"]!)},
      {"name": "Isya", "time": _parseTime(jadwalSholat["Isya"]!)},
    ];
    
    for (var prayer in prayers) {
      if (prayer["time"] > currentTime) {
        return prayer["name"] == "Subuh" 
            ? jadwalSholat["Subuh"]! 
            : jadwalSholat[prayer["name"]]!;
      }
    }
    return jadwalSholat["Subuh"]!;
  }
  
  int _parseTime(String time) {
    final parts = time.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);
    return hour * 60 + minute;
  }
  
  String getFormattedDate() {
    // Aman karena sudah diinisialisasi di initState
    return DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(selectedDate);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text(
          "Jadwal Sholat",
          style: TextStyle(
            color: primaryWhite,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: accentBlue, size: 20), // Cyber Neon Cyan
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Tanggal (Tunggu locale siap untuk menghindari crash)
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: accentBlue.withOpacity(0.1), // Cyan tint
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: accentBlue.withOpacity(0.3)), // Cyan border
                  ),
                  child: Text(
                    isLocaleInitialized ? getFormattedDate() : "Loading date...",
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 30),
              
              // Jam sekarang
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [accentBlue.withOpacity(0.15), Colors.transparent], // Cyan aura
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: accentBlue.withOpacity(0.2)), // Cyan border
                ),
                child: Column(
                  children: [
                    StreamBuilder(
                      stream: Stream.periodic(const Duration(seconds: 1)),
                      builder: (context, snapshot) {
                        return Text(
                          getCurrentTime(),
                          style: const TextStyle(
                            color: primaryWhite,
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: successGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        "Waktu ${getCurrentTimeStatus()}",
                        style: TextStyle(
                          color: successGreen,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 30),
              
              // Jadwal Sholat
              const Text(
                "JADWAL SHOLAT",
                style: TextStyle(
                  color: softGrey,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.5,
                ),
              ),
              
              const SizedBox(height: 15),
              
              // List 5 Waktu Sholat
              _buildPrayerItem("Subuh", jadwalSholat["Subuh"]!, Icons.wb_twilight, Colors.green),
              _buildPrayerItem("Dzuhur", jadwalSholat["Dzuhur"]!, Icons.wb_sunny, Colors.orange),
              _buildPrayerItem("Ashar", jadwalSholat["Ashar"]!, Icons.sunny, Colors.deepOrange),
              _buildPrayerItem("Maghrib", jadwalSholat["Maghrib"]!, Icons.nights_stay, Colors.purple),
              _buildPrayerItem("Isya", jadwalSholat["Isya"]!, Icons.nightlight_round, Colors.indigo),
              
              const SizedBox(height: 30),
              
              // Waktu Sholat Berikutnya
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF0277BD), Color(0xFF00E5FF)], // Deep Blue to Cyber Neon Cyan
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: accentBlue.withOpacity(0.4), // Neon Cyan glow
                      blurRadius: 20,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Text(
                      "WAKTU SHOLAT BERIKUTNYA",
                      style: TextStyle(
                        color: Colors.black54, // Hitam untuk kontras di atas Cyan terang
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      "Next Prayer", // Atau pakai getNextPrayer() jika ingin dinamis
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      getNextPrayerTime(),
                      style: const TextStyle(
                        color: primaryWhite,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 30),
              
              // Hadits
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.green.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.menu_book_rounded, color: Colors.green, size: 28),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Keutamaan Sholat",
                            style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: 5),
                          Text(
                            "Sholat adalah tiang agama, barang siapa mendirikannya maka tegaklah agamanya.",
                            style: TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildPrayerItem(String name, String time, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: const Color(0x1A00E5FF), // Cyber Neon Cyan Glass
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x0D0D47A1)), // Deep Ocean Blue Border
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Text(
            name,
            style: const TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.w600,
              fontSize: 16,
            ),
          ),
          const Spacer(),
          Text(
            time,
            style: TextStyle(
              color: accentBlue, // Cyber Neon Cyan
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ],
      ),
    );
  }
}