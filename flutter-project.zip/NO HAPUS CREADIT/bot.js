// SCRIPT SERU SERUAN BY ZAKKNEV
// JANGAN HAPUS CREDITS NYA YA BROK
// HARGAIN YANG BUAT SCRIT 
// #SCRIPT INI FREE JANGAN DI JUAL
// = TELE : t.me/ZAKKNEVERLUS
// ALL SUPPORT ME 
// RANDY TANK YOU BRO
// AKBAR TANK YOU BRO
// CECE TANK YOU BRO
// TANKYOU FOR YOU ALL SUPPORT ME
// DI LARANG KERAS HAPUS CREADIT
// HARGAI PEMBUAT SCRIPT NYA BRE 

const TelegramBot = require('node-telegram-bot-api');

// ==================== KONFIGURASI ====================
// Ganti dengan token bot kamu dari @BotFather
const TOKEN = '8837274451:AAH2jNS-4k7Ffn6XmSq4Xl-tdhNeuQGb5Os';

// Ganti dengan ID grup yang diizinkan (opsional, kosongkan jika untuk semua grup)
const ALLOWED_GROUP_IDS = [
 -1003842234099,// Ganti dengan ID grup 1
  , // Ganti dengan ID grup 2 (jika ada)
];

// Kata-kata toxic yang akan dideteksi
const TOXIC_WORDS = [
  'anjing', 'babi', 'kontol', 'memek', 'jembut', 'ngentot', 
  'tolol', 'goblok', 'bodoh', 'bego', 'idiot', 'kampret',
  'keparat', 'setan', 'iblis', 'sialan', 'brengsek', 'bangsat'
];

// Kata-kata promosi yang akan dideteksi
const PROMO_WORDS = [
  'promo', 'diskon', 'gratis', 'murah', 'jual', 'beli',
  'shopee', 'tokopedia', 'lazada', 'bukalapak', 'olx',
  'open order', 'pre order', 'ready stock', 'cod'
];

// ==================== INISIALISASI BOT ====================
const bot = new TelegramBot(TOKEN, { polling: true });

// ==================== FUNGSI UTILITY ====================

// Cek apakah pesan dari grup yang diizinkan
function isAllowedGroup(chatId) {
  if (ALLOWED_GROUP_IDS.length === 0) return true; // Jika tidak ada filter grup
  return ALLOWED_GROUP_IDS.includes(chatId);
}

// Cek apakah user adalah admin grup
async function isUserAdmin(chatId, userId) {
  try {
    const chatMember = await bot.getChatMember(chatId, userId);
    return ['administrator', 'creator'].includes(chatMember.status);
  } catch (error) {
    console.log('Error cek admin:', error.message);
    return false;
  }
}

// Hapus pesan dengan aman
async function safeDeleteMessage(chatId, messageId) {
  try {
    await bot.deleteMessage(chatId, messageId);
    return true;
  } catch (error) {
    console.log('Gagal hapus pesan:', error.message);
    return false;
  }
}

// Kirim peringatan dengan delay
async function sendWarning(chatId, text, deleteAfter = 5000) {
  try {
    const sentMessage = await bot.sendMessage(chatId, text);
    setTimeout(() => {
      safeDeleteMessage(chatId, sentMessage.message_id);
    }, deleteAfter);
  } catch (error) {
    console.log('Gagal kirim peringatan:', error.message);
  }
}

// ==================== COMMAND HANDLER ====================

// Handler untuk semua pesan
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const messageId = msg.message_id;
  const userId = msg.from.id;
  const userName = msg.from.username || msg.from.first_name;
  const text = msg.text || '';
  const lowerText = text.toLowerCase();

  // Skip jika bukan di grup atau bukan pesan teks
  if (chatId > 0) return; // Bukan grup
  if (!text) return; // Bukan pesan teks

  // Cek apakah di grup yang diizinkan
  if (!isAllowedGroup(chatId)) return;

  // Cek apakah user admin
  const isAdmin = await isUserAdmin(chatId, userId);

  // ===== CEK TOXIC =====
  for (const toxicWord of TOXIC_WORDS) {
    if (lowerText.includes(toxicWord)) {
      // Hapus pesan toxic
      await safeDeleteMessage(chatId, messageId);
      
      // Kirim peringatan (kecuali admin)
      if (!isAdmin) {
        await sendWarning(chatId, 
          `⚠️ @${userName} *JANGAN BAHASA TOXIC!*\n` +
          `Kata *"${toxicWord}"* tidak diperbolehkan di grup ini.`,
          5000
        );
      }
      break;
    }
  }

  // ===== CEK LINK =====
  // Regex untuk mendeteksi link
  const linkRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\/[^\s]*)?)/gi;
  const hasLink = linkRegex.test(text) && 
                  !text.includes('t.me/') && // Kecualikan link telegram
                  !text.includes('telegram.org');

  if (hasLink && !isAdmin) {
    // Hapus pesan yang mengandung link
    await safeDeleteMessage(chatId, messageId);
    
    // Kirim peringatan
    await sendWarning(chatId,
      `🔗 @${userName} *DILARANG SHARE LINK!*\n` +
      `Maaf, sharing link tidak diperbolehkan di grup ini.`,
      5000
    );
  }

  // ===== CEK PROMOSI =====
  for (const promoWord of PROMO_WORDS) {
    if (lowerText.includes(promoWord) && !isAdmin) {
      // Hapus pesan promosi
      await safeDeleteMessage(chatId, messageId);
      
      // Kirim peringatan
      await sendWarning(chatId,
        `📢 @${userName} *DILARANG PROMOSI!*\n` +
        `Promosi tidak diperbolehkan di grup ini.`,
        5000
      );
      break;
    }
  }
});

// ==================== COMMAND: /CEKGANTENG ====================
bot.onText(/\/cekganteng(@\w+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userName = msg.from.username || msg.from.first_name;

  // Hitung persentasi kegantengan
  const persentase = Math.floor(Math.random() * 101);
  
  // Tentukan keterangan
  let keterangan = '';
  if (persentase >= 80) {
    keterangan = '🔥 GANTENG BANGET COY!';
  } else if (persentase >= 60) {
    keterangan = '😎 Cukup Ganteng';
  } else if (persentase >= 40) {
    keterangan = '🤔 Lumayan Ganteng';
  } else if (persentase >= 20) {
    keterangan = '😅 Kurang Ganteng';
  } else {
    keterangan = '🥲 Mending Minta Wd Sama Allah';
  }

  // Kirim hasil
  bot.sendMessage(chatId, 
    `🤵 *CEK KEGANTENGAN*\n\n` +
    `Nama: @${userName}\n` +
    `Tingkat Kegantengan: *${persentase}%*\n` +
    `Keterangan: ${keterangan}`,
    { parse_mode: 'Markdown' }
  );
});

// ==================== COMMAND: /CEKCANTIK ====================
bot.onText(/\/cekcantik(@\w+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userName = msg.from.username || msg.from.first_name;

  // Hitung persentasi kecantikan
  const persentase = Math.floor(Math.random() * 101);
  
  // Tentukan keterangan
  let keterangan = '';
  if (persentase >= 80) {
    keterangan = '👑 CANTIK BANGET BOS!';
  } else if (persentase >= 60) {
    keterangan = '💃 Cukup Cantik';
  } else if (persentase >= 40) {
    keterangan = '👗 Lumayan Cantik';
  } else if (persentase >= 20) {
    keterangan = '😐 Kurang Cantik';
  } else {
    keterangan = '🥺 Sabar Ya Cantik Belum Keliatan';
  }

  // Kirim hasil
  bot.sendMessage(chatId, 
    `👸 *CEK KECANTIKAN*\n\n` +
    `Nama: @${userName}\n` +
    `Tingkat Kecantikan: *${persentase}%*\n` +
    `Keterangan: ${keterangan}`,
    { parse_mode: 'Markdown' }
  );
});

// ==================== COMMAND: /CEKMEMEK ====================
bot.onText(/\/cekmemek(@\w+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userName = msg.from.username || msg.from.first_name;

  // Array respons random
  const responses = [
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **WET** 💦 (Banyak Jusnya)',
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **SEMPOYAN** 🌬️ (Empuk)',
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **SEMPIT** 🔒 (Rapat Banget)',
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **LONGGAR** 🕳️ (Minta Ampun)',
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **BUNTET** 🐱 (Montok)',
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **BELEK** 🤢 (Jorok)',
    '🍩 *HASIL CEK MEMEK*\n\nMemek @' + userName + ' **SEGAR** 🍑 (Fresh)'
  ];

  const randomResponse = responses[Math.floor(Math.random() * responses.length)];
  bot.sendMessage(chatId, randomResponse, { parse_mode: 'Markdown' });
});

// ==================== COMMAND: /CEKKONTOL ====================
bot.onText(/\/cekkontol(@\w+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userName = msg.from.username || msg.from.first_name;

  // Array respons random
  const responses = [
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **PANJANG** 📏 (15cm+)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **PENDEK** 📐 (Di bawah 10cm)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **BESAR** 🏋️ (Seperti Botol)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **KECIL** 🥜 (Seperti Kacang)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **BENGKOK** ↪️ (Melengkung)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **LURUS** 📏 (Seperti Bambu)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **HITAM** ⚫ (Legam)',
    '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + ' **PUTIH** ⚪ (Pucat)'
  ];

  // Tambah random ukuran
  const ukuran = Math.floor(Math.random() * 20) + 3; // 3-23 cm
  const specialResponse = '🍆 *HASIL CEK KONTOL*\n\nKontol @' + userName + 
                         ' *' + ukuran + 'cm* 📏\n' +
                         'Keterangan: ' + (ukuran > 15 ? 'Wah Gede Banget' : ukuran > 10 ? 'Standar' : 'Maaf Ya Masih Mini');

  const useSpecial = Math.random() > 0.5; // 50% chance pake special atau random
  
  if (useSpecial) {
    bot.sendMessage(chatId, specialResponse, { parse_mode: 'Markdown' });
  } else {
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    bot.sendMessage(chatId, randomResponse, { parse_mode: 'Markdown' });
  }
});

// ==================== COMMAND: /ANTILINK ====================
bot.onText(/\/antilink(@\w+)?(?:\s+(on|off))?$/i, async (msg, match, action) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const commandAction = match[2] || action;

  // Cek apakah user admin
  const isAdmin = await isUserAdmin(chatId, userId);
  if (!isAdmin) {
    bot.sendMessage(chatId, '❌ Maaf, hanya admin yang bisa menggunakan command ini.');
    return;
  }

  if (!commandAction) {
    bot.sendMessage(chatId, 
      '🔧 *ANTI LINK SETTINGS*\n\n' +
      'Gunakan:\n' +
      '/antilink on - Aktifkan anti link\n' +
      '/antilink off - Nonaktifkan anti link',
      { parse_mode: 'Markdown' }
    );
    return;
  }

  if (commandAction.toLowerCase() === 'on') {
    // Di sini Anda bisa menyimpan status ke file/database
    bot.sendMessage(chatId, '✅ Fitur anti link telah *DIAKTIFKAN*', { parse_mode: 'Markdown' });
  } else if (commandAction.toLowerCase() === 'off') {
    bot.sendMessage(chatId, '❌ Fitur anti link telah *DINONAKTIFKAN*', { parse_mode: 'Markdown' });
  }
});

// ==================== COMMAND: /ANTIPROMOSI ====================
bot.onText(/\/antipromosi(@\w+)?(?:\s+(on|off))?$/i, async (msg, match, action) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const commandAction = match[2] || action;

  // Cek apakah user admin
  const isAdmin = await isUserAdmin(chatId, userId);
  if (!isAdmin) {
    bot.sendMessage(chatId, '❌ Maaf, hanya admin yang bisa menggunakan command ini.');
    return;
  }

  if (!commandAction) {
    bot.sendMessage(chatId, 
      '🔧 *ANTI PROMOSI SETTINGS*\n\n' +
      'Gunakan:\n' +
      '/antipromosi on - Aktifkan anti promosi\n' +
      '/antipromosi off - Nonaktifkan anti promosi',
      { parse_mode: 'Markdown' }
    );
    return;
  }

  if (commandAction.toLowerCase() === 'on') {
    bot.sendMessage(chatId, '✅ Fitur anti promosi telah *DIAKTIFKAN*', { parse_mode: 'Markdown' });
  } else if (commandAction.toLowerCase() === 'off') {
    bot.sendMessage(chatId, '❌ Fitur anti promosi telah *DINONAKTIFKAN*', { parse_mode: 'Markdown' });
  }
});

// ==================== COMMAND: /ANTITOXIC ====================
bot.onText(/\/antitoxic(@\w+)?(?:\s+(on|off))?$/i, async (msg, match, action) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const commandAction = match[2] || action;

  // Cek apakah user admin
  const isAdmin = await isUserAdmin(chatId, userId);
  if (!isAdmin) {
    bot.sendMessage(chatId, '❌ Maaf, hanya admin yang bisa menggunakan command ini.');
    return;
  }

  if (!commandAction) {
    bot.sendMessage(chatId, 
      '🔧 *ANTI TOXIC SETTINGS*\n\n' +
      'Gunakan:\n' +
      '/antitoxic on - Aktifkan anti toxic\n' +
      '/antitoxic off - Nonaktifkan anti toxic',
      { parse_mode: 'Markdown' }
    );
    return;
  }

  if (commandAction.toLowerCase() === 'on') {
    bot.sendMessage(chatId, '✅ Fitur anti toxic telah *DIAKTIFKAN*', { parse_mode: 'Markdown' });
  } else if (commandAction.toLowerCase() === 'off') {
    bot.sendMessage(chatId, '❌ Fitur anti toxic telah *DINONAKTIFKAN*', { parse_mode: 'Markdown' });
  }
});

// ==================== COMMAND: /HELP ====================
bot.onText(/\/help(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, 
    '📚 *LIST COMMAND BOT*\n\n' +
    '*🎮 FUN COMMAND:*\n' +
    '/cekganteng - Cek tingkat kegantengan\n' +
    '/cekcantik - Cek tingkat kecantikan\n' +
    '/cekmemek - Cek kondisi memek\n' +
    '/cekkontol - Cek kondisi kontol\n\n' +
    '*👑 COMMAND KHUSUS ADMIN:*\n' +
    '/antilink [on/off] - Atur anti link\n' +
    '/antipromosi [on/off] - Atur anti promosi\n' +
    '/antitoxic [on/off] - Atur anti toxic\n\n' +
    '*🤖 FITUR AUTO DELETE:*\n' +
    '• Anti Toxic: Hapus kata kasar\n' +
    '• Anti Link: Hapus pesan berisi link\n' +
    '• Anti Promosi: Hapus pesan promosi\n\n' +
    '*Catatan:* Fitur otomatis hanya untuk non-admin',
    { parse_mode: 'Markdown' }
  );
});

// ==================== ERROR HANDLER ====================
bot.on('polling_error', (error) => {
  console.log('Polling error:', error.message);
});

bot.on('error', (error) => {
  console.log('Bot error:', error.message);
});

console.log('Bot Telegram sedang berjalan...');
console.log('Gunakan /help untuk melihat daftar command');