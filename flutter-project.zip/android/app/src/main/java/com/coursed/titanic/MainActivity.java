package com.kaito.nul;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
