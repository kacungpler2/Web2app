package com.impact.sunov;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
